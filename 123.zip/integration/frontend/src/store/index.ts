import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// ── Types ────────────────────────────────────────────────────────────────────
export interface User {
  id: string; username: string; email: string;
  firstName: string; lastName: string; fullName: string;
  role: number; branchId?: string; branchName?: string;
  twoFactorEnabled: boolean; language: string;
}

export interface CartItem {
  productId: string; productName: string; barcode?: string;
  quantity: number; unitPrice: number; vatRate: number;
  vatAmount: number; discountAmount: number; lineTotal: number;
}

// ── Auth Store ────────────────────────────────────────────────────────────────
interface AuthStore {
  user: User | null;
  token: string | null;
  refresh: string | null;
  login: (user: User, token: string, refresh: string) => void;
  logout: () => void;
}

export const useAuth = create<AuthStore>()(
  persist(
    (set) => ({
      user: null, token: null, refresh: null,
      login: (user, token, refresh) => {
        if (typeof window !== 'undefined') {
          localStorage.setItem('mx:token',   token)
          localStorage.setItem('mx:refresh', refresh)
        }
        set({ user, token, refresh })
      },
      logout: () => {
        if (typeof window !== 'undefined') {
          localStorage.removeItem('mx:token')
          localStorage.removeItem('mx:refresh')
        }
        set({ user: null, token: null, refresh: null })
      },
    }),
    { name: 'mx:auth', partialize: s => ({ user: s.user, token: s.token, refresh: s.refresh }) }
  )
)

// ── Cart Store ────────────────────────────────────────────────────────────────
interface CartStore {
  items:           CartItem[];
  customerId?:     string;
  customerName?:   string;
  paymentMethod:   number;
  discountAmount:  number;
  discountType:    'amount' | 'percent';
  loyaltyRedeem:   number;
  amountPaid:      string;

  // Computed
  subtotal:     () => number;
  vatTotal:     () => number;
  discountTotal:() => number;
  total:        () => number;
  change:       () => number;

  // Actions
  addItem:          (p: any, qty?: number) => void;
  updateQty:        (productId: string, qty: number) => void;
  removeItem:       (productId: string) => void;
  setCustomer:      (id: string, name: string) => void;
  clearCustomer:    () => void;
  setPayment:       (method: number) => void;
  setDiscount:      (amount: number, type: 'amount' | 'percent') => void;
  setLoyaltyRedeem: (pts: number) => void;
  setAmountPaid:    (v: string) => void;
  clear:            () => void;
}

export const useCart = create<CartStore>()((set, get) => ({
  items: [], customerId: undefined, customerName: undefined,
  paymentMethod: 0, discountAmount: 0, discountType: 'amount',
  loyaltyRedeem: 0, amountPaid: '',

  subtotal: () => get().items.reduce((s, i) => s + i.unitPrice * i.quantity, 0),

  vatTotal: () => get().items.reduce((s, i) => s + i.vatAmount * i.quantity, 0),

  discountTotal: () => {
    const { discountAmount, discountType, items } = get()
    const base = items.reduce((s, i) => s + i.unitPrice * i.quantity, 0)
    return discountType === 'percent' ? base * discountAmount / 100 : discountAmount
  },

  total: () => {
    const s = get()
    return Math.max(0, s.subtotal() + s.vatTotal() - s.discountTotal() - s.loyaltyRedeem / 10)
  },

  change: () => {
    const paid = parseFloat(get().amountPaid || '0')
    return Math.max(0, paid - get().total())
  },

  addItem: (p, qty = 1) => set(s => {
    const existing = s.items.find(i => i.productId === p.id)
    if (existing) {
      return {
        items: s.items.map(i => i.productId !== p.id ? i : {
          ...i,
          quantity: i.quantity + qty,
          vatAmount: p.hasVat ? (i.unitPrice * (i.quantity + qty)) * (i.vatRate) / (i.quantity + qty) : 0,
          lineTotal: i.unitPrice * (i.quantity + qty) * (1 + i.vatRate),
        })
      }
    }
    const vatRate    = p.hasVat ? (p.vatRate ?? 0.14) : 0
    const vatAmount  = p.salePrice * qty * vatRate
    return {
      items: [...s.items, {
        productId: p.id, productName: p.name, barcode: p.barcode,
        quantity: qty, unitPrice: p.salePrice,
        vatRate, vatAmount: vatAmount / qty,
        discountAmount: 0,
        lineTotal: p.salePrice * qty + vatAmount,
      }]
    }
  }),

  updateQty: (id, qty) => set(s => ({
    items: qty <= 0
      ? s.items.filter(i => i.productId !== id)
      : s.items.map(i => i.productId !== id ? i : {
          ...i, quantity: qty,
          vatAmount: i.unitPrice * i.vatRate,
          lineTotal: i.unitPrice * qty * (1 + i.vatRate),
        })
  })),

  removeItem: id => set(s => ({ items: s.items.filter(i => i.productId !== id) })),
  setCustomer: (id, name) => set({ customerId: id, customerName: name }),
  clearCustomer: () => set({ customerId: undefined, customerName: undefined }),
  setPayment: method => set({ paymentMethod: method }),
  setDiscount: (amount, type) => set({ discountAmount: amount, discountType: type }),
  setLoyaltyRedeem: pts => set({ loyaltyRedeem: pts }),
  setAmountPaid: v => set({ amountPaid: v }),
  clear: () => set({
    items: [], customerId: undefined, customerName: undefined,
    paymentMethod: 0, discountAmount: 0, discountType: 'amount',
    loyaltyRedeem: 0, amountPaid: '',
  }),
}))

// ── UI Store ──────────────────────────────────────────────────────────────────
export const useUI = create<{
  sidebar: boolean;
  toggle:  () => void;
  collapse:() => void;
}>()(set => ({
  sidebar: true,
  toggle:   () => set(s => ({ sidebar: !s.sidebar })),
  collapse: () => set({ sidebar: false }),
}))
