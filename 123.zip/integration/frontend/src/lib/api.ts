import axios, { AxiosError, type AxiosInstance } from 'axios'

const BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:5000/api'

// ── Create axios instance with base config ──────────────────────────────────
export const api: AxiosInstance = axios.create({
  baseURL: BASE,
  headers: { 'Content-Type': 'application/json', 'Accept-Language': 'ar' },
  timeout: 15_000,
})

// ── Request interceptor: attach JWT ────────────────────────────────────────
api.interceptors.request.use(cfg => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('mx:token')
    if (token) cfg.headers.Authorization = `Bearer ${token}`
  }
  return cfg
})

// ── Response interceptor: auto-refresh on 401 ──────────────────────────────
let refreshing = false
let waitQueue: Array<(token: string) => void> = []

api.interceptors.response.use(
  r => r,
  async (err: AxiosError) => {
    const originalRequest = err.config as any
    if (err.response?.status !== 401 || originalRequest._retry) return Promise.reject(err)

    if (refreshing) {
      return new Promise(resolve =>
        waitQueue.push(token => {
          originalRequest.headers.Authorization = `Bearer ${token}`
          resolve(api(originalRequest))
        })
      )
    }

    refreshing = true
    originalRequest._retry = true

    try {
      const refreshToken = localStorage.getItem('mx:refresh')
      if (!refreshToken) throw new Error('No refresh token')

      const { data } = await axios.post(`${BASE}/auth/refresh`, { refreshToken })
      const newToken  = data.data.accessToken
      localStorage.setItem('mx:token', newToken)

      waitQueue.forEach(cb => cb(newToken))
      waitQueue = []

      originalRequest.headers.Authorization = `Bearer ${newToken}`
      return api(originalRequest)
    } catch {
      localStorage.clear()
      window.location.href = '/login'
      return Promise.reject(err)
    } finally {
      refreshing = false
    }
  }
)

// ── Typed API modules ────────────────────────────────────────────────────────
export const authAPI = {
  register:    (d: any) => api.post('/auth/register', d),
  login:       (d: any) => api.post('/auth/login', d),
  refresh:     (token: string) => api.post('/auth/refresh', { refreshToken: token }),
  logout:      (token: string) => api.post('/auth/logout', { refreshToken: token }),
  me:          () => api.get('/auth/me'),
  changePwd:   (d: any) => api.post('/auth/change-password', d),
  mfaSetup:    () => api.post('/auth/mfa/setup'),
  mfaVerify:   (code: string) => api.post('/auth/mfa/verify', { code }),
  mfaDisable:  (code: string) => api.post('/auth/mfa/disable', { code }),
}

export const posAPI = {
  products:    (branchId: string, search?: string) =>
    api.get(`/pos/products?branchId=${branchId}${search ? `&search=${encodeURIComponent(search)}` : ''}`),
  barcode:     (code: string, branchId: string) =>
    api.get(`/pos/barcode/${code}?branchId=${branchId}`),
  sale:        (d: any) => api.post('/pos/sale', d),
  sales:       (branchId: string, from?: string, to?: string, page = 1, pageSize = 20) =>
    api.get(`/pos/sales?branchId=${branchId}&page=${page}&pageSize=${pageSize}${from ? `&from=${from}` : ''}${to ? `&to=${to}` : ''}`),
  saleById:    (id: string) => api.get(`/pos/sales/${id}`),
  refund:      (id: string, d: any) => api.post(`/pos/sales/${id}/refund`, d),
}

export const inventoryAPI = {
  products:    (page = 1, pageSize = 20, search?: string, catId?: string) =>
    api.get(`/inventory/products?page=${page}&pageSize=${pageSize}${search ? `&search=${encodeURIComponent(search)}` : ''}${catId ? `&categoryId=${catId}` : ''}`),
  product:     (id: string) => api.get(`/inventory/products/${id}`),
  create:      (d: any) => api.post('/inventory/products', d),
  update:      (id: string, d: any) => api.put(`/inventory/products/${id}`, d),
  delete:      (id: string) => api.delete(`/inventory/products/${id}`),
  stock:       (branchId?: string, lowOnly = false) =>
    api.get(`/inventory/stock?lowOnly=${lowOnly}${branchId ? `&branchId=${branchId}` : ''}`),
  adjust:      (d: any) => api.post('/inventory/stock/adjust', d),
  transfer:    (d: any) => api.post('/inventory/stock/transfer', d),
}

export const customersAPI = {
  list:        (search?: string, page = 1, pageSize = 20) =>
    api.get(`/customers?page=${page}&pageSize=${pageSize}${search ? `&search=${encodeURIComponent(search)}` : ''}`),
  get:         (id: string) => api.get(`/customers/${id}`),
  byPhone:     (phone: string) => api.get(`/customers/by-phone/${encodeURIComponent(phone)}`),
  create:      (d: any) => api.post('/customers', d),
  update:      (id: string, d: any) => api.put(`/customers/${id}`, d),
  addLoyalty:  (id: string, points: number, reason?: string) =>
    api.post(`/customers/${id}/loyalty`, { points, reason }),
}

export const dashboardAPI = {
  stats:       (branchId?: string) => api.get(`/dashboard${branchId ? `?branchId=${branchId}` : ''}`),
  report:      (d: any) => api.post('/dashboard/sales-report', d),
}

export const syncAPI = {
  push:        (d: any) => api.post('/sync/push', d),
  pull:        (branchId: string, since: string) =>
    api.get(`/sync/pull?branchId=${branchId}&since=${since}`),
}

export const licenseAPI = {
  status:       () => api.get('/license/status'),
  plans:        () => api.get('/license/plans'),
  activate:     (key: string, fp: string) => api.post('/license/activate', { licenseKey: key, deviceFingerprint: fp }),
  activateSync: (key: string) => api.post('/license/activate-sync', { syncKey: key }),
}
