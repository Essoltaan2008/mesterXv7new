'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { authAPI } from '@/lib/api'
import { useAuth, useUI } from '@/store'
import toast from 'react-hot-toast'

const NAV = [
  { href: '/', icon: '📊', label: 'الرئيسية' },
  { href: '/pos', icon: '🛒', label: 'نقطة البيع' },
  { href: '/inventory', icon: '📦', label: 'المخزون' },
  { href: '/customers', icon: '👥', label: 'العملاء' },
]

const ROLE_LABELS: Record<number, string> = {
  0: 'مالك المنصة',
  1: 'مدير عام',
  2: 'صاحب شركة',
  3: 'مدير نظام',
  4: 'مدير فرع',
  5: 'كاشير',
  6: 'مشاهد',
}

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout } = useAuth()
  const { sidebar, toggle } = useUI()

  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname.startsWith(href)

  const handleLogout = async () => {
    const refresh = typeof window !== 'undefined' ? localStorage.getItem('mx:refresh') : null
    if (refresh) {
      try {
        await authAPI.logout(refresh)
      } catch {
      }
    }

    logout()
    toast.success('تم تسجيل الخروج')
    router.push('/login')
  }

  return (
    <aside
      className={`
        ${sidebar ? 'w-56' : 'w-16'}
        flex h-full flex-shrink-0 flex-col border-l border-slate-700/50 bg-slate-800
        transition-all duration-200
      `}
    >
      <div className="flex min-h-[64px] items-center gap-3 border-b border-slate-700/50 px-4 py-4">
        <span className="text-2xl flex-shrink-0">⚡</span>
        {sidebar && (
          <div className="overflow-hidden">
            <p className="text-sm font-bold leading-tight text-amber-400">MesterX</p>
            <p className="text-xs leading-tight text-slate-500">Core MVP</p>
          </div>
        )}
      </div>

      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 py-3">
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`nav-link ${isActive(item.href) ? 'active' : ''}`}
            title={!sidebar ? item.label : undefined}
          >
            <span className="text-base flex-shrink-0">{item.icon}</span>
            {sidebar && <span className="truncate">{item.label}</span>}
          </Link>
        ))}
      </nav>

      <div className="border-t border-slate-700/50 p-3">
        {sidebar ? (
          <>
            <div className="mb-2.5 flex items-center gap-2.5">
              <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-sm font-bold text-amber-400">
                {user?.firstName?.[0] ?? '?'}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-semibold text-slate-200">
                  {user ? `${user.firstName} ${user.lastName}` : '...'}
                </p>
                <p className="truncate text-xs text-slate-500">
                  {ROLE_LABELS[user?.role ?? 5] ?? 'مستخدم'}
                </p>
              </div>
            </div>

            <div className="mb-2.5 flex flex-wrap gap-1.5">
              {user?.branchName && (
                <span className="badge-slate max-w-full truncate text-xs">
                  🏢 {user.branchName}
                </span>
              )}
            </div>
          </>
        ) : (
          <div className="mx-auto mb-2.5 flex h-9 w-9 items-center justify-center rounded-full bg-amber-500/20 text-sm font-bold text-amber-400">
            {user?.firstName?.[0] ?? '?'}
          </div>
        )}

        <button
          onClick={toggle}
          className="mb-1 flex w-full items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs text-slate-500 transition-colors hover:bg-slate-700/40 hover:text-slate-300"
          title="طي / فتح القائمة"
        >
          <span>{sidebar ? '◀' : '▶'}</span>
          {sidebar && <span>طي</span>}
        </button>

        <button
          onClick={handleLogout}
          className="flex w-full items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs text-slate-500 transition-colors hover:bg-red-500/10 hover:text-red-400"
        >
          <span>🚪</span>
          {sidebar && <span>تسجيل الخروج</span>}
        </button>
      </div>
    </aside>
  )
}
