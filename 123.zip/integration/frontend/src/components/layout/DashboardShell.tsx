'use client'
import type { ReactNode } from 'react'
import { useAuth } from '@/store'
import Sidebar from '@/components/layout/Sidebar'

interface DashboardShellProps {
  children: ReactNode
  title?: string
}

export default function DashboardShell({ children, title }: DashboardShellProps) {
  const { user } = useAuth()

  if (!user) return null

  return (
    <div className="flex h-screen overflow-hidden bg-slate-900" dir="rtl">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-14 bg-slate-800/80 backdrop-blur border-b border-slate-700/50 px-6 flex items-center gap-4 flex-shrink-0">
          {title && <h1 className="text-sm font-semibold text-slate-200">{title}</h1>}
          <div className="flex-1" />
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse-dot" />
            <span>متصل</span>
          </div>
          {user.branchName && (
            <span className="text-xs text-slate-500 border-r border-slate-700 pr-3">
              {user.branchName}
            </span>
          )}
          <div className="flex items-center gap-2 text-sm text-slate-300">
            <div className="w-7 h-7 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 text-xs font-bold">
              {user.firstName[0]}
            </div>
            <span className="hidden md:inline text-xs">{user.fullName}</span>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  )
}
