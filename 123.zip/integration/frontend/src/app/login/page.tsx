'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/store'
import { authAPI } from '@/lib/api'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const router    = useRouter()
  const { user, login } = useAuth()

  const [username,   setUsername]   = useState('')
  const [password,   setPassword]   = useState('')
  const [mfaCode,    setMfaCode]    = useState('')
  const [needsMfa,   setNeedsMfa]   = useState(false)
  const [loading,    setLoading]    = useState(false)
  const [showPwd,    setShowPwd]    = useState(false)

  // Already logged in → redirect
  useEffect(() => { if (user) router.replace('/') }, [user, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim() || !password.trim()) {
      toast.error('يرجى إدخال اسم المستخدم وكلمة المرور')
      return
    }
    setLoading(true)
    try {
      const { data } = await authAPI.login({
        username, password, mfaCode: needsMfa ? mfaCode : undefined,
      })
      if (!data.success) { toast.error(data.message || 'بيانات خاطئة'); return }

      if (data.data?.requiresMfa) {
        setNeedsMfa(true)
        toast('أدخل كود التحقق من تطبيقك', { icon: '🔐' })
        return
      }

      login(data.data.user, data.data.accessToken, data.data.refreshToken)
      toast.success(`مرحباً ${data.data.user.firstName}! 👋`)
      router.replace('/')
    } catch (err: any) {
      const msg = err?.response?.data?.message ?? 'خطأ في الاتصال'
      toast.error(msg)
      if (msg.includes('مقفول')) setPassword('')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="min-h-screen bg-slate-900 flex items-center justify-center p-4"
      dir="rtl"
      style={{
        backgroundImage: 'radial-gradient(ellipse at 20% 50%, rgba(59,130,246,0.06) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(217,119,6,0.06) 0%, transparent 60%)',
      }}
    >
      <div className="w-full max-w-sm animate-fade-up">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 mb-4">
            <span className="text-3xl">⚡</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-100">MesterX</h1>
          <p className="text-slate-400 text-sm mt-1">نظام إدارة الأعمال المتكامل</p>
        </div>

        {/* Card */}
        <div className="card p-8">
          <h2 className="text-lg font-semibold text-slate-100 mb-6">
            {needsMfa ? '🔐 التحقق الثنائي' : 'تسجيل الدخول'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!needsMfa ? (
              <>
                <div>
                  <label className="label">اسم المستخدم أو البريد الإلكتروني</label>
                  <input
                    type="text"
                    className="input"
                    placeholder="username أو email@example.com"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    autoComplete="username"
                    autoFocus
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="label">كلمة المرور</label>
                  <div className="relative">
                    <input
                      type={showPwd ? 'text' : 'password'}
                      className="input pl-10"
                      placeholder="••••••••"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      autoComplete="current-password"
                      disabled={loading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPwd(v => !v)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 transition text-sm"
                    >
                      {showPwd ? '🙈' : '👁️'}
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div>
                <label className="label">كود التحقق (6 أرقام)</label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]{6}"
                  maxLength={6}
                  className="input text-center font-mono text-xl tracking-[0.5em]"
                  placeholder="000000"
                  value={mfaCode}
                  onChange={e => setMfaCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  autoFocus
                  disabled={loading}
                />
                <p className="text-xs text-slate-500 mt-2 text-center">
                  افتح تطبيق Google Authenticator وأدخل الكود المعروض
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-3 mt-2"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" />
                  جاري التحقق...
                </span>
              ) : needsMfa ? 'تأكيد الكود' : 'دخول'}
            </button>

            {needsMfa && (
              <button
                type="button"
                onClick={() => { setNeedsMfa(false); setMfaCode('') }}
                className="btn-ghost w-full text-xs"
              >
                ← رجوع لتسجيل الدخول
              </button>
            )}
          </form>
        </div>

        {/* Demo credentials hint */}
        <div className="mt-4 card-sm p-3 text-center">
          <p className="text-xs text-slate-500 mb-1">بيانات تجريبية</p>
          <p className="text-xs text-slate-400 font-mono">
            nile_owner / nile_cashier / farha_owner
          </p>
          <p className="text-xs text-slate-500 font-mono mt-0.5">Admin@MesterX2025!</p>
        </div>

        <p className="text-center text-xs text-slate-600 mt-4">
          MesterX Enterprise v7.0 · 🇪🇬 صُنع في مصر
        </p>
      </div>
    </div>
  )
}
