'use client'
import { useEffect, useState, useRef, useCallback } from 'react'
import DashboardLayout from '@/components/layout/DashboardShell'
import { useAuth, useCart } from '@/store'
import { posAPI, customersAPI } from '@/lib/api'
import toast from 'react-hot-toast'

// ── Types ────────────────────────────────────────────────────────────────────
interface Product {
  id: string; name: string; nameAr?: string; barcode?: string
  salePrice: number; hasVat: boolean; vatRate: number; imageUrl?: string
  available: number; isLowStock: boolean
}
interface Customer { id: string; name: string; phone?: string; loyaltyPoints: number }

const PAY_METHODS = [
  { v: 0, l: 'نقدي',   i: '💵' },
  { v: 1, l: 'كارت',   i: '💳' },
  { v: 2, l: 'محفظة',  i: '📱' },
  { v: 4, l: 'مختلط',  i: '🔀' },
]
const EGP = (n = 0) => n.toLocaleString('ar-EG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export default function PosPage() {
  const { user } = useAuth()
  const cart     = useCart()
  const scanRef  = useRef<HTMLInputElement>(null)

  const [products,  setProducts]  = useState<Product[]>([])
  const [filtered,  setFiltered]  = useState<Product[]>([])
  const [search,    setSearch]    = useState('')
  const [customer,  setCustomer]  = useState<Customer | null>(null)
  const [phoneQ,    setPhoneQ]    = useState('')
  const [loading,   setLoading]   = useState(false)
  const [receipt,   setReceipt]   = useState<any>(null)

  const branchId = user?.branchId ?? ''

  // ── Load products ──────────────────────────────────────────────────────────
  const loadProducts = useCallback(async () => {
    if (!branchId) return
    try {
      const { data } = await posAPI.products(branchId)
      if (data.success) setProducts(data.data ?? [])
    } catch { toast.error('فشل تحميل المنتجات') }
  }, [branchId])

  useEffect(() => { loadProducts(); scanRef.current?.focus() }, [loadProducts])

  // Filter by search
  useEffect(() => {
    if (!search.trim()) { setFiltered(products); return }
    const q = search.toLowerCase()
    setFiltered(products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      (p.nameAr ?? '').includes(search) ||
      p.barcode?.includes(search)
    ))
  }, [products, search])

  // ── Barcode scan (Enter key) ───────────────────────────────────────────────
  const handleScan = async (code: string) => {
    if (!code.trim()) return
    try {
      const { data } = await posAPI.barcode(code, branchId)
      if (data.success && data.data) {
        cart.addItem(data.data)
        toast.success(data.data.name, { duration: 1000 })
      } else { toast.error('الباركود غير موجود') }
    } catch { toast.error('خطأ في الباركود') }
    setSearch('')
    scanRef.current?.focus()
  }

  // ── Customer lookup ────────────────────────────────────────────────────────
  const findCustomer = async () => {
    if (!phoneQ.trim()) return
    try {
      const { data } = await customersAPI.byPhone(phoneQ)
      if (data.success) {
        setCustomer(data.data)
        cart.setCustomer(data.data.id, data.data.name)
        toast.success(`العميل: ${data.data.name}`)
      } else { toast.error('لا يوجد عميل بهذا الرقم') }
    } catch { toast.error('فشل البحث') }
  }

  // ── Complete sale ──────────────────────────────────────────────────────────
  const completeSale = async () => {
    if (!cart.items.length) { toast.error('السلة فارغة'); return }
    if (cart.paymentMethod === 0) {
      const paid = parseFloat(cart.amountPaid || '0')
      if (isNaN(paid) || paid < cart.total()) { toast.error('المبلغ المدفوع أقل من الإجمالي'); return }
    }
    setLoading(true)
    try {
      const { data } = await posAPI.sale({
        branchId,
        customerId:        cart.customerId ?? null,
        paymentMethod:     cart.paymentMethod,
        amountPaid:        cart.paymentMethod === 0 ? parseFloat(cart.amountPaid) : cart.total(),
        discountAmount:    cart.discountAmount,
        discountType:      cart.discountType === 'percent' ? 1 : 0,
        loyaltyPointsToRedeem: cart.loyaltyRedeem,
        items: cart.items.map(i => ({
          productId:     i.productId,
          quantity:      i.quantity,
          unitPrice:     i.unitPrice,
          discountAmount:i.discountAmount,
        })),
        clientIdempotencyKey: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        isOffline: false,
      })
      if (data.success) {
        setReceipt(data.data)
        cart.clear()
        setCustomer(null)
        setPhoneQ('')
        loadProducts()
        toast.success('✅ تمت عملية البيع!')
      } else { toast.error(data.message ?? 'فشلت عملية البيع') }
    } catch (e: any) {
      toast.error(e?.response?.data?.message ?? 'فشلت عملية البيع')
    } finally { setLoading(false) }
  }

  const subtotal   = cart.subtotal()
  const vatTotal   = cart.vatTotal()
  const discTotal  = cart.discountTotal()
  const total      = cart.total()
  const changeAmt  = cart.change()

  return (
    <DashboardLayout title="نقطة البيع">
      <div className="flex h-[calc(100vh-3.5rem)] overflow-hidden no-print">

        {/* ── Products panel ────────────────────────────────── */}
        <div className="flex-1 flex flex-col overflow-hidden border-l border-slate-700/50">

          {/* Search / scan bar */}
          <div className="px-4 py-2.5 bg-slate-800/50 border-b border-slate-700/50 flex gap-2">
            <input
              ref={scanRef}
              className="input flex-1 text-sm"
              placeholder="🔍 ابحث أو امسح الباركود..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && search.trim()) {
                  const exact = products.find(p => p.barcode === search || p.id === search)
                  if (exact) { cart.addItem(exact); setSearch(''); scanRef.current?.focus() }
                  else handleScan(search)
                }
              }}
            />
            <button onClick={() => { setSearch(''); scanRef.current?.focus() }}
              className="btn-ghost px-3 text-xs">✕</button>
          </div>

          {/* Product grid */}
          <div className="flex-1 overflow-y-auto p-3">
            {!branchId ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-500">
                <p className="text-4xl mb-3">⚠️</p>
                <p className="text-sm">يجب تعيين فرع لحسابك أولاً</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-2">
                {filtered.map(p => (
                  <button
                    key={p.id}
                    onClick={() => { cart.addItem(p); toast.success(p.name, { duration: 700 }) }}
                    disabled={p.isLowStock && p.available <= 0}
                    className={`pos-key group ${p.isLowStock && p.available <= 0 ? 'opacity-40 cursor-not-allowed' : ''}`}
                  >
                    <span className="text-xl mb-1">{p.imageUrl ? '🖼️' : '📦'}</span>
                    <p className="text-[11px] font-semibold text-slate-200 leading-tight line-clamp-2">{p.name}</p>
                    <p className="text-sm font-bold text-amber-400 mt-1">{EGP(p.salePrice)}</p>
                    {p.isLowStock && (
                      <p className="text-[10px] text-red-400 mt-0.5">متبقي: {p.available}</p>
                    )}
                  </button>
                ))}
                {filtered.length === 0 && (
                  <div className="col-span-full text-center py-16 text-slate-500">
                    <p className="text-3xl mb-2">📭</p>
                    <p className="text-sm">لا توجد منتجات</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* ── Cart panel ────────────────────────────────────── */}
        <div className="w-80 xl:w-96 flex flex-col bg-slate-800 border-l border-slate-700/50">

          {/* Customer search */}
          <div className="px-4 py-2.5 border-b border-slate-700/50">
            {customer ? (
              <div className="flex items-center gap-2 bg-teal-500/10 border border-teal-500/30 rounded-lg px-3 py-2">
                <span className="text-teal-400 text-sm">👤</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-teal-300 truncate">{customer.name}</p>
                  <p className="text-[10px] text-slate-400">{customer.loyaltyPoints.toLocaleString()} نقطة</p>
                </div>
                <button onClick={() => { setCustomer(null); cart.clearCustomer() }}
                  className="text-slate-400 hover:text-red-400 transition text-xs">✕</button>
              </div>
            ) : (
              <div className="flex gap-2">
                <input className="input flex-1 text-xs" placeholder="رقم موبايل العميل..."
                  value={phoneQ} onChange={e => setPhoneQ(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && findCustomer()} />
                <button onClick={findCustomer} className="btn-ghost px-3 text-xs">بحث</button>
              </div>
            )}
          </div>

          {/* Cart items */}
          <div className="flex-1 overflow-y-auto">
            {cart.items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 text-slate-600">
                <p className="text-4xl">🛒</p>
                <p className="text-sm mt-2">السلة فارغة</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-700/40">
                {cart.items.map(item => (
                  <div key={item.productId} className="flex items-center gap-2 px-4 py-2.5">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-slate-200 truncate">{item.productName}</p>
                      <p className="text-[10px] text-slate-500">{EGP(item.unitPrice)} × {item.quantity}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {['-', item.quantity, '+'].map((v, i) => (
                        <button key={i}
                          onClick={() => i === 0
                            ? cart.updateQty(item.productId, item.quantity - 1)
                            : i === 2
                              ? cart.updateQty(item.productId, item.quantity + 1)
                              : undefined}
                          className={`w-6 h-6 rounded text-xs flex items-center justify-center ${typeof v === 'number' ? 'font-bold text-slate-200 cursor-default' : 'bg-slate-700 text-slate-300 hover:bg-slate-600 transition'}`}
                        >{v}</button>
                      ))}
                    </div>
                    <p className="text-xs font-bold text-amber-400 w-16 text-left">{EGP(item.lineTotal)}</p>
                    <button onClick={() => cart.removeItem(item.productId)}
                      className="text-slate-600 hover:text-red-400 transition text-xs ml-1">✕</button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Totals + Payment */}
          <div className="border-t border-slate-700/50 p-4 space-y-3">

            {/* Discount */}
            <div className="flex gap-2">
              <input className="input flex-1 text-xs" placeholder="خصم..." type="number" min="0"
                value={cart.discountAmount || ''}
                onChange={e => cart.setDiscount(parseFloat(e.target.value) || 0, cart.discountType)} />
              <select className="select text-xs w-20"
                value={cart.discountType}
                onChange={e => cart.setDiscount(cart.discountAmount, e.target.value as 'amount' | 'percent')}>
                <option value="amount">ج.م</option>
                <option value="percent">%</option>
              </select>
            </div>

            {/* Summary */}
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>قبل الضريبة</span><span className="font-mono">{EGP(subtotal)} ج.م</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>ضريبة 14%</span><span className="font-mono">{EGP(vatTotal)} ج.م</span>
              </div>
              {discTotal > 0 && (
                <div className="flex justify-between text-green-400">
                  <span>الخصم</span><span className="font-mono">- {EGP(discTotal)} ج.م</span>
                </div>
              )}
              <div className="flex justify-between text-slate-100 font-bold text-sm pt-1 border-t border-slate-700">
                <span>الإجمالي</span>
                <span className="text-amber-400 font-mono">{EGP(total)} ج.م</span>
              </div>
            </div>

            {/* Payment method */}
            <div className="grid grid-cols-4 gap-1">
              {PAY_METHODS.map(m => (
                <button key={m.v} onClick={() => cart.setPayment(m.v)}
                  className={`py-1.5 rounded text-xs font-semibold border transition-all ${cart.paymentMethod === m.v ? 'bg-amber-500 border-amber-500 text-slate-900' : 'border-slate-600 text-slate-400 hover:border-amber-500/40'}`}>
                  {m.i} {m.l}
                </button>
              ))}
            </div>

            {/* Amount paid (cash only) */}
            {cart.paymentMethod === 0 && (
              <div>
                <input className="input text-sm font-mono" placeholder="المبلغ المدفوع..."
                  type="number" value={cart.amountPaid} onChange={e => cart.setAmountPaid(e.target.value)} />
                {changeAmt > 0 && (
                  <p className="text-xs text-teal-400 mt-1 font-mono">الباقي: {EGP(changeAmt)} ج.م</p>
                )}
              </div>
            )}

            {/* Complete sale button */}
            <button onClick={completeSale} disabled={loading || !cart.items.length}
              className="btn-primary w-full py-3 text-base font-bold">
              {loading
                ? <span className="flex items-center gap-2 justify-center"><span className="w-4 h-4 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin"/>جاري...</span>
                : '✅ إتمام البيع'}
            </button>

            {cart.items.length > 0 && (
              <button onClick={() => { cart.clear(); setCustomer(null) }}
                className="btn-ghost w-full text-xs text-red-400">
                🗑️ إلغاء السلة
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── Receipt modal ────────────────────────────────── */}
      {receipt && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 no-print">
          <div className="bg-white text-black rounded-2xl max-w-xs w-full p-6 shadow-2xl animate-fade-up" dir="rtl">
            <div className="text-center mb-4">
              <p className="text-3xl">✅</p>
              <h3 className="text-lg font-bold mt-1">تمت عملية البيع</h3>
              <p className="text-sm text-gray-500 font-mono">{receipt.orderNumber}</p>
            </div>

            <div className="border-t border-dashed border-gray-200 pt-3 space-y-1.5 text-sm">
              {(receipt.items ?? []).map((i: any) => (
                <div key={i.productId} className="flex justify-between">
                  <span className="text-gray-600">{i.productName} × {i.qty}</span>
                  <span>{EGP(i.lineTotal)} ج.م</span>
                </div>
              ))}
              <div className="border-t border-dashed border-gray-200 pt-2 font-bold flex justify-between">
                <span>الإجمالي</span>
                <span className="text-amber-600">{EGP(receipt.totalAmount)} ج.م</span>
              </div>
              {(receipt.changeGiven ?? 0) > 0 && (
                <div className="flex justify-between text-green-600 text-xs">
                  <span>الباقي</span><span>{EGP(receipt.changeGiven)} ج.م</span>
                </div>
              )}
            </div>

            <div className="flex gap-2 mt-4">
              <button onClick={() => window.print()}
                className="flex-1 bg-slate-800 text-white py-2 rounded-lg text-sm font-semibold hover:bg-slate-700 transition">
                🖨️ طباعة
              </button>
              <button onClick={() => setReceipt(null)}
                className="flex-1 bg-amber-500 text-slate-900 py-2 rounded-lg text-sm font-semibold hover:bg-amber-400 transition">
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
