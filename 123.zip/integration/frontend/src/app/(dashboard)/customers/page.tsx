'use client'
import { useState, useEffect, useCallback } from 'react'
import DashboardLayout from '@/components/layout/DashboardShell'
import { customersAPI } from '@/lib/api'
import toast from 'react-hot-toast'

const SEG: Record<number, [string, string]> = {
  0: ['جديد', 'badge-slate'], 1: ['منتظم', 'badge-teal'],
  2: ['VIP', 'badge-gold'],   3: ['غير نشط', 'badge-red'], 4: ['محظور', 'badge-red'],
}
const EGP = (n = 0) => n.toLocaleString('ar-EG', { minimumFractionDigits: 0 }) + ' ج.م'

export default function CustomersPage() {
  const [customers, setCustomers] = useState<any[]>([])
  const [search,    setSearch]    = useState('')
  const [page,      setPage]      = useState(1)
  const [total,     setTotal]     = useState(0)
  const [loading,   setLoading]   = useState(false)
  const [showForm,  setShowForm]  = useState(false)
  const [form,      setForm]      = useState({ name: '', phone: '', email: '', city: '' })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await customersAPI.list(search || undefined, page, 20)
      setCustomers(data.data?.items ?? [])
      setTotal(data.data?.totalCount ?? 0)
    } catch { toast.error('فشل التحميل') }
    finally { setLoading(false) }
  }, [search, page])

  useEffect(() => { load() }, [load])

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await customersAPI.create(form)
      toast.success('تم إضافة العميل')
      setShowForm(false)
      setForm({ name: '', phone: '', email: '', city: '' })
      load()
    } catch (e: any) { toast.error(e?.response?.data?.message ?? 'فشل الإضافة') }
  }

  return (
    <DashboardLayout title="إدارة العملاء">
      <div className="p-6 animate-fade-up">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <p className="text-sm text-slate-400">إجمالي: <span className="font-bold text-slate-200">{total.toLocaleString()}</span> عميل</p>
          <div className="flex gap-2">
            <input className="input w-48 text-xs" placeholder="🔍 اسم أو رقم موبايل..."
              value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} />
            <button onClick={() => setShowForm(true)} className="btn-primary text-xs">+ إضافة عميل</button>
          </div>
        </div>

        <div className="card overflow-hidden">
          <table className="w-full">
            <thead><tr>
              {['العميل', 'الموبايل', 'المدينة', 'Segment', 'نقاط الولاء', 'إجمالي الشراء', 'آخر شراء'].map(h => (
                <th key={h} className="table-hd">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="table-td text-center py-12">
                  <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
                </td></tr>
              ) : customers.length === 0 ? (
                <tr><td colSpan={7} className="table-td text-center text-slate-500 py-12">
                  <p className="text-3xl mb-2">👥</p>
                  <p className="text-sm">{search ? 'لا توجد نتائج' : 'لا يوجد عملاء بعد'}</p>
                </td></tr>
              ) : customers.map((c: any) => {
                const [segLabel, segClass] = SEG[c.segment] ?? ['—', 'badge-slate']
                return (
                  <tr key={c.id} className="table-tr">
                    <td className="table-td">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 text-xs font-bold flex-shrink-0">
                          {c.name[0]}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-200">{c.name}</p>
                          {c.email && <p className="text-xs text-slate-500">{c.email}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="table-td font-mono text-xs text-slate-300">{c.phone ?? '—'}</td>
                    <td className="table-td text-slate-400 text-xs">{c.city ?? '—'}</td>
                    <td className="table-td"><span className={segClass}>{segLabel}</span></td>
                    <td className="table-td text-teal-400 font-mono text-xs">{c.loyaltyPoints?.toLocaleString() ?? 0} نقطة</td>
                    <td className="table-td font-semibold text-amber-400 text-xs">{EGP(c.totalPurchases)}</td>
                    <td className="table-td text-slate-400 text-xs">
                      {c.lastPurchaseAt ? new Date(c.lastPurchaseAt).toLocaleDateString('ar-EG') : 'لم يشتر'}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          {total > 20 && (
            <div className="px-4 py-3 border-t border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
              <span>{total} عميل</span>
              <div className="flex gap-1">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-sm btn-ghost">السابق</button>
                <span className="px-3 py-1.5">صفحة {page} من {Math.ceil(total / 20)}</span>
                <button onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / 20)} className="btn-sm btn-ghost">التالي</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="card max-w-md w-full p-6 animate-fade-up" dir="rtl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-slate-100">إضافة عميل جديد</h3>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-slate-200">✕</button>
            </div>
            <form onSubmit={save} className="space-y-4">
              <div><label className="label">الاسم *</label>
                <input className="input" required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">الموبايل</label>
                  <input className="input" type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
                <div><label className="label">المدينة</label>
                  <input className="input" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
              </div>
              <div><label className="label">البريد الإلكتروني</label>
                <input className="input" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
              <div className="flex gap-3">
                <button type="submit" className="btn-primary flex-1">✅ حفظ</button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
