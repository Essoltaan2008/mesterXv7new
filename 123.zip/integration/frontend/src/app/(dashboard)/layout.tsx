'use client'
import { useEffect, type ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/store'

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const router = useRouter()
  const { user } = useAuth()

  useEffect(() => {
    if (user === null) router.replace('/login')
  }, [user, router])

  if (!user) return null

  return <>{children}</>
}
