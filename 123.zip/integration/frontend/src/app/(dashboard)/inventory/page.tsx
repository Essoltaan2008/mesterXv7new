'use client'
import { useState, useEffect, useCallback } from 'react'
import DashboardLayout from '@/components/layout/DashboardShell'
import { inventoryAPI } from '@/lib/api'
import toast from 'react-hot-toast'

const EGP = (n = 0) => n.toLocaleString('ar-EG', { minimumFractionDigits: 2 }) + ' ج.م'

export default function InventoryPage() {
  const [tab, setTab]           = useState<'products' | 'stock'>('products')
  const [products, setProducts] = useState<any[]>([])
  const [stock, setStock]       = useState<any[]>([])
  const [search, setSearch]     = useState('')
  const [page, setPage]         = useState(1)
  const [total, setTotal]       = useState(0)
  const [loading, setLoading]   = useState(false)
  const [lowOnly, setLowOnly]   = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm]         = useState({ name: '', sku: '', barcode: '', salePrice: '', costPrice: '', hasVat: true })

  const loadProducts = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await inventoryAPI.products(page, 20, search || undefined)
      setProducts(data.data?.items ?? [])
      setTotal(data.data?.totalCount ?? 0)
    } catch { toast.error('فشل تحميل المنتجات') }
    finally { setLoading(false) }
  }, [page, search])

  const loadStock = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await inventoryAPI.stock(undefined, lowOnly)
      setStock(data.data ?? [])
    } catch { toast.error('فشل تحميل المخزون') }
    finally { setLoading(false) }
  }, [lowOnly])

  useEffect(() => { tab === 'products' ? loadProducts() : loadStock() }, [tab, loadProducts, loadStock])

  const deleteProduct = async (id: string) => {
    if (!confirm('حذف هذا المنتج؟')) return
    try {
      await inventoryAPI.delete(id)
      toast.success('تم الحذف')
      loadProducts()
    } catch { toast.error('فشل الحذف') }
  }

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await inventoryAPI.create({
        name: form.name, sku: form.sku || undefined, barcode: form.barcode || undefined,
        salePrice: parseFloat(form.salePrice) || 0, costPrice: parseFloat(form.costPrice) || 0,
        hasVat: form.hasVat,
      })
      toast.success('تم إضافة المنتج')
      setShowForm(false)
      setForm({ name: '', sku: '', barcode: '', salePrice: '', costPrice: '', hasVat: true })
      loadProducts()
    } catch (e: any) { toast.error(e?.response?.data?.message ?? 'فشل الإضافة') }
  }

  return (
    <DashboardLayout title="إدارة المخزون">
      <div className="p-6 animate-fade-up">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex gap-2">
            {(['products', 'stock'] as const).map(t => (
              <button key={t} onClick={() => { setTab(t); setPage(1) }}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition ${tab === t ? 'bg-amber-500 text-slate-900' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}>
                {t === 'products' ? '📦 المنتجات' : '📊 المخزون'}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <input className="input w-48 text-xs" placeholder="بحث..." value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }} />
            {tab === 'products' && (
              <button onClick={() => setShowForm(true)} className="btn-primary text-xs">+ إضافة منتج</button>
            )}
            {tab === 'stock' && (
              <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer bg-slate-700 px-3 rounded-lg">
                <input type="checkbox" checked={lowOnly} onChange={e => setLowOnly(e.target.checked)} className="accent-amber-500" />
                النافذ فقط
              </label>
            )}
          </div>
        </div>

        {/* Products table */}
        {tab === 'products' && (
          <div className="card overflow-hidden">
            <table className="w-full">
              <thead><tr>
                {['المنتج', 'الباركود/SKU', 'سعر البيع', 'التكلفة', 'الحالة', ''].map(h => (
                  <th key={h} className="table-hd">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={6} className="table-td text-center py-10">
                    <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
                  </td></tr>
                ) : products.length === 0 ? (
                  <tr><td colSpan={6} className="table-td text-center text-slate-500 py-12">
                    <p className="text-3xl mb-2">📭</p><p className="text-sm">لا توجد منتجات</p>
                  </td></tr>
                ) : products.map((p: any) => (
                  <tr key={p.id} className="table-tr">
                    <td className="table-td">
                      <p className="font-medium text-slate-100">{p.name}</p>
                      {p.nameAr && <p className="text-xs text-slate-500">{p.nameAr}</p>}
                    </td>
                    <td className="table-td font-mono text-xs text-slate-400">{p.barcode ?? p.sku ?? '—'}</td>
                    <td className="table-td font-semibold text-amber-400">{EGP(p.salePrice)}</td>
                    <td className="table-td text-slate-400 text-xs">{EGP(p.costPrice)}</td>
                    <td className="table-td">
                      <span className={p.isActive ? 'badge-teal' : 'badge-red'}>{p.isActive ? 'نشط' : 'معطّل'}</span>
                    </td>
                    <td className="table-td">
                      <button onClick={() => deleteProduct(p.id)} className="btn-sm btn-danger">حذف</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {total > 20 && (
              <div className="px-4 py-3 border-t border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
                <span>{total} منتج</span>
                <div className="flex gap-1">
                  <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-sm btn-ghost">السابق</button>
                  <span className="px-3 py-1.5">صفحة {page} من {Math.ceil(total / 20)}</span>
                  <button onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / 20)} className="btn-sm btn-ghost">التالي</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Stock table */}
        {tab === 'stock' && (
          <div className="card overflow-hidden">
            <table className="w-full">
              <thead><tr>
                {['المنتج', 'الفرع', 'المتاح', 'المحجوز', 'الإجمالي', 'الحالة'].map(h => (
                  <th key={h} className="table-hd">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={6} className="table-td text-center py-10">
                    <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
                  </td></tr>
                ) : stock.length === 0 ? (
                  <tr><td colSpan={6} className="table-td text-center text-slate-500 py-12">لا توجد بيانات</td></tr>
                ) : stock.map((s: any, i: number) => (
                  <tr key={i} className="table-tr">
                    <td className="table-td font-medium">{s.productName}</td>
                    <td className="table-td text-slate-400 text-xs">{s.branchName}</td>
                    <td className="table-td font-bold text-teal-400">{s.available}</td>
                    <td className="table-td text-slate-400 text-xs">{s.reserved}</td>
                    <td className="table-td">{s.quantity}</td>
                    <td className="table-td">
                      <span className={s.isLowStock ? 'badge-red' : 'badge-teal'}>{s.isLowStock ? 'نفذ' : 'كافٍ'}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add product modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="card max-w-md w-full p-6 animate-fade-up" dir="rtl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-slate-100">إضافة منتج جديد</h3>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-slate-200">✕</button>
            </div>
            <form onSubmit={saveProduct} className="space-y-4">
              <div><label className="label">الاسم *</label>
                <input className="input" required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">SKU</label>
                  <input className="input" value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} /></div>
                <div><label className="label">باركود</label>
                  <input className="input" value={form.barcode} onChange={e => setForm(f => ({ ...f, barcode: e.target.value }))} /></div>
                <div><label className="label">سعر البيع</label>
                  <input className="input" type="number" min="0" step="0.01" value={form.salePrice} onChange={e => setForm(f => ({ ...f, salePrice: e.target.value }))} /></div>
                <div><label className="label">سعر التكلفة</label>
                  <input className="input" type="number" min="0" step="0.01" value={form.costPrice} onChange={e => setForm(f => ({ ...f, costPrice: e.target.value }))} /></div>
              </div>
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                <input type="checkbox" checked={form.hasVat} onChange={e => setForm(f => ({ ...f, hasVat: e.target.checked }))} className="accent-amber-500" />
                تطبيق ضريبة VAT 14%
              </label>
              <div className="flex gap-3">
                <button type="submit" className="btn-primary flex-1">✅ حفظ</button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
