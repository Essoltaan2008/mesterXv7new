'use client'
import { useState } from 'react'
import DashboardLayout from '@/components/layout/DashboardShell'
import { useAuth } from '@/store'
import { authAPI } from '@/lib/api'
import toast from 'react-hot-toast'

export default function SettingsPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState<'profile'|'security'|'license'>('profile')
  const [oldPwd,  setOldPwd]  = useState('')
  const [newPwd,  setNewPwd]  = useState('')
  const [confPwd, setConfPwd] = useState('')
  const [saving,  setSaving]  = useState(false)
  const [mfaSetupData, setMfaSetupData] = useState<any>(null)
  const [mfaCode, setMfaCode] = useState('')

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (newPwd !== confPwd) { toast.error('كلمتا المرور غير متطابقتين'); return }
    setSaving(true)
    try {
      const { data } = await authAPI.changePwd({ oldPassword: oldPwd, newPassword: newPwd, confirmPassword: confPwd })
      if (data.success) { toast.success('تم تغيير كلمة المرور'); setOldPwd(''); setNewPwd(''); setConfPwd('') }
      else toast.error(data.message ?? 'فشل التغيير')
    } catch (e: any) { toast.error(e?.response?.data?.message ?? 'خطأ') }
    finally { setSaving(false) }
  }

  const setupMfa = async () => {
    try {
      const { data } = await authAPI.mfaSetup()
      if (data.success) setMfaSetupData(data.data)
    } catch { toast.error('فشل إعداد MFA') }
  }

  const confirmMfa = async () => {
    if (!mfaCode || mfaCode.length !== 6) { toast.error('أدخل كوداً صحيحاً'); return }
    try {
      const { data } = await authAPI.mfaVerify(mfaCode)
      if (data.success) { toast.success('تم تفعيل التحقق الثنائي! 🔐'); setMfaSetupData(null); setMfaCode('') }
      else toast.error(data.message ?? 'كود خاطئ')
    } catch { toast.error('خطأ في التحقق') }
  }

  return (
    <DashboardLayout title="الإعدادات">
      <div className="p-6 max-w-2xl animate-fade-up">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {([['profile','👤 الملف الشخصي'], ['security','🔐 الأمان'], ['license','📄 الترخيص']] as [string,string][]).map(([t, l]) => (
            <button key={t} onClick={() => setActiveTab(t as any)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition ${activeTab === t ? 'bg-amber-500 text-slate-900' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}>
              {l}
            </button>
          ))}
        </div>

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="card p-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/20 flex items-center justify-center text-amber-400 text-2xl font-bold">
                {user?.firstName?.[0] ?? '?'}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-100">{user?.fullName}</h3>
                <p className="text-sm text-slate-400">{user?.email}</p>
                <span className="badge-teal mt-1 inline-block">{user?.role}</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              {[['اسم المستخدم', user?.username], ['الفرع', user?.branchName ?? 'كل الفروع'], ['اللغة', user?.language === 'ar' ? 'العربية' : 'English']].map(([l, v]) => (
                <div key={l} className="card-sm p-3">
                  <p className="text-xs text-slate-500 mb-1">{l}</p>
                  <p className="text-slate-200 font-medium">{v}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Security Tab */}
        {activeTab === 'security' && (
          <div className="space-y-6">
            {/* Change Password */}
            <div className="card p-6">
              <h3 className="font-semibold text-slate-100 mb-4">تغيير كلمة المرور</h3>
              <form onSubmit={changePassword} className="space-y-4">
                {[['كلمة المرور الحالية', oldPwd, setOldPwd], ['كلمة المرور الجديدة', newPwd, setNewPwd], ['تأكيد كلمة المرور الجديدة', confPwd, setConfPwd]].map(([l, v, s]: any) => (
                  <div key={l}>
                    <label className="label">{l}</label>
                    <input className="input" type="password" value={v} onChange={e => s(e.target.value)} required minLength={8} />
                  </div>
                ))}
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving ? '⏳ جاري التغيير...' : 'تغيير كلمة المرور'}
                </button>
              </form>
            </div>

            {/* MFA */}
            <div className="card p-6">
              <h3 className="font-semibold text-slate-100 mb-2">التحقق الثنائي (MFA)</h3>
              <p className="text-xs text-slate-400 mb-4">يضيف طبقة أمان إضافية باستخدام Google Authenticator أو Microsoft Authenticator</p>
              {user?.twoFactorEnabled ? (
                <div className="flex items-center gap-3 p-3 bg-teal-500/10 border border-teal-500/20 rounded-lg">
                  <span className="text-teal-400 text-xl">✅</span>
                  <div>
                    <p className="text-sm font-semibold text-teal-300">التحقق الثنائي مفعّل</p>
                    <p className="text-xs text-slate-400">حسابك محمي بطبقة إضافية</p>
                  </div>
                </div>
              ) : mfaSetupData ? (
                <div className="space-y-4">
                  <p className="text-xs text-slate-400">امسح هذا الكود بتطبيق المصادقة ثم أدخل الكود المكوّن من 6 أرقام:</p>
                  <div className="bg-white inline-block p-4 rounded-xl">
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(mfaSetupData.qrCodeUrl)}&size=160x160`} alt="QR Code" className="w-40 h-40" />
                  </div>
                  <p className="text-xs font-mono text-slate-400 bg-slate-700/50 px-3 py-1.5 rounded">{mfaSetupData.secret}</p>
                  <div className="flex gap-2">
                    <input className="input flex-1 text-center font-mono tracking-widest" placeholder="000000" maxLength={6}
                      value={mfaCode} onChange={e => setMfaCode(e.target.value.replace(/\D/g,'').slice(0,6))} />
                    <button onClick={confirmMfa} className="btn-teal">تأكيد</button>
                  </div>
                </div>
              ) : (
                <button onClick={setupMfa} className="btn-ghost">🔐 إعداد التحقق الثنائي</button>
              )}
            </div>
          </div>
        )}

        {/* License Tab */}
        {activeTab === 'license' && (
          <div className="card p-6">
            <h3 className="font-semibold text-slate-100 mb-4">معلومات الترخيص</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b border-slate-700/50">
                <span className="text-slate-400">الخطة الحالية</span>
                <span className="badge-gold">Pro Monthly</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-700/50">
                <span className="text-slate-400">تاريخ الانتهاء</span>
                <span className="text-slate-200">يتجدد تلقائياً</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-400">المزامنة السحابية</span>
                <span className="badge-teal">مفعّلة</span>
              </div>
            </div>
            <a href="/license/plans" className="btn-primary mt-4 block text-center text-sm">🚀 ترقية الخطة</a>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
