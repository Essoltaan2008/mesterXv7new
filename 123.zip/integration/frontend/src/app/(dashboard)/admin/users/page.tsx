'use client'
import { useState, useEffect, useCallback } from 'react'
import DashboardLayout from '@/components/layout/DashboardShell'
import { api } from '@/lib/api'
import { useAuth } from '@/store'
import toast from 'react-hot-toast'

// User roles — numeric values match the UserRole enum on the backend
const ROLES: Record<number, { label: string; color: string; description: string }> = {
  0: { label: 'مالك المنصة',  color: 'badge-gold',  description: 'صلاحية كاملة على كل شيء' },
  1: { label: 'مدير عام',     color: 'badge-gold',  description: 'إدارة جميع الشركات' },
  2: { label: 'صاحب شركة',    color: 'badge-teal',  description: 'إدارة الشركة وكل فروعها' },
  3: { label: 'مدير نظام',    color: 'badge-teal',  description: 'إدارة المستخدمين والإعدادات' },
  4: { label: 'مدير فرع',     color: 'badge-green', description: 'إدارة فرع محدد' },
  5: { label: 'كاشير',        color: 'badge-slate', description: 'إجراء عمليات البيع فقط' },
  6: { label: 'مشاهد',        color: 'badge-slate', description: 'قراءة التقارير فقط' },
}

export default function AdminUsersPage() {
  const { user: currentUser } = useAuth()
  const [users, setUsers]       = useState<any[]>([])
  const [search, setSearch]     = useState('')
  const [page, setPage]         = useState(1)
  const [total, setTotal]       = useState(0)
  const [loading, setLoading]   = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving]     = useState(false)
  const [editUser, setEditUser] = useState<any>(null)

  const [form, setForm] = useState({
    firstName: '', lastName: '', username: '', email: '',
    password: '', phone: '', role: '5', branchId: '',
  })

  const PAGE_SIZE = 20

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(page),
        pageSize: String(PAGE_SIZE),
        ...(search && { search }),
      })
      const { data } = await api.get(`/admin/users?${params}`)
      setUsers(data.data?.items ?? [])
      setTotal(data.data?.totalCount ?? 0)
    } catch { toast.error('فشل تحميل المستخدمين') }
    finally { setLoading(false) }
  }, [page, search])

  useEffect(() => { load() }, [load])

  const openCreate = () => {
    setEditUser(null)
    setForm({ firstName: '', lastName: '', username: '', email: '', password: '', phone: '', role: '5', branchId: '' })
    setShowForm(true)
  }

  const openEdit = (u: any) => {
    setEditUser(u)
    setForm({ firstName: u.firstName, lastName: u.lastName, username: u.username, email: u.email, password: '', phone: u.phone ?? '', role: String(u.role), branchId: u.branchId ?? '' })
    setShowForm(true)
  }

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const payload = {
        ...form,
        role: parseInt(form.role),
        branchId: form.branchId || null,
        ...(editUser ? {} : { password: form.password }),
      }
      const { data } = editUser
        ? await api.put(`/admin/users/${editUser.id}`, payload)
        : await api.post('/admin/users', payload)

      if (data.success) {
        toast.success(editUser ? 'تم تحديث المستخدم' : 'تم إضافة المستخدم')
        setShowForm(false)
        load()
      } else toast.error(data.message || 'فشل الحفظ')
    } catch (e: any) {
      toast.error(e?.response?.data?.message ?? 'فشل الحفظ')
    } finally { setSaving(false) }
  }

  const toggleActive = async (u: any) => {
    try {
      const { data } = await api.patch(`/admin/users/${u.id}/toggle-active`)
      if (data.success) { toast.success(`تم ${u.isActive ? 'تعطيل' : 'تفعيل'} الحساب`); load() }
    } catch { toast.error('فشل التغيير') }
  }

  const resetPassword = async (userId: string) => {
    const newPwd = prompt('كلمة المرور الجديدة (8 أحرف على الأقل، حرف كبير + رقم + رمز):')
    if (!newPwd || newPwd.length < 8) { toast.error('كلمة المرور قصيرة جداً'); return }
    try {
      const { data } = await api.post(`/admin/users/${userId}/reset-password`, { newPassword: newPwd })
      if (data.success) toast.success('تم تغيير كلمة المرور')
      else toast.error(data.message ?? 'فشل التغيير')
    } catch { toast.error('فشل التغيير') }
  }

  const totalPages = Math.ceil(total / PAGE_SIZE)

  // Only managers+ can access this page
  if (currentUser && currentUser.role > 3) {
    return (
      <DashboardLayout title="إدارة المستخدمين">
        <div className="flex flex-col items-center justify-center h-64 text-slate-500">
          <p className="text-4xl mb-3">🔒</p>
          <p className="text-sm">ليس لديك صلاحية للوصول إلى هذه الصفحة</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout title="إدارة المستخدمين">
      <div className="p-6 space-y-6 animate-fade-up">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100">المستخدمون</h2>
            <p className="text-sm text-slate-400 mt-0.5">{total.toLocaleString()} مستخدم مسجّل</p>
          </div>
          <div className="flex gap-2">
            <input className="input w-52" placeholder="🔍 بحث بالاسم أو البريد..."
              value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} />
            <button onClick={openCreate} className="btn-primary">+ إضافة مستخدم</button>
          </div>
        </div>

        {/* Role distribution */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {Object.entries(ROLES).filter(([k]) => parseInt(k) >= 2).map(([k, v]) => {
            const count = users.filter(u => u.role === parseInt(k)).length
            return (
              <div key={k} className="card-sm p-3 text-center">
                <p className="text-lg font-bold text-slate-100">{count}</p>
                <span className={`${v.color} mt-1 text-xs`}>{v.label}</span>
              </div>
            )
          })}
        </div>

        {/* Users Table */}
        <div className="card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr>
                {['المستخدم', 'اسم المستخدم', 'البريد الإلكتروني', 'الدور', 'الفرع', 'آخر دخول', 'الحالة', ''].map(h => (
                  <th key={h} className="table-hd">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="table-td text-center py-12">
                  <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
                </td></tr>
              ) : users.length === 0 ? (
                <tr><td colSpan={8} className="table-td text-center py-12">
                  <p className="text-3xl mb-2">👥</p>
                  <p className="text-sm text-slate-500">{search ? 'لا توجد نتائج' : 'لا يوجد مستخدمون'}</p>
                </td></tr>
              ) : users.map((u: any) => {
                const role = ROLES[u.role]
                const isCurrentUser = u.id === currentUser?.id
                return (
                  <tr key={u.id} className="table-tr">
                    <td className="table-td">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm flex-shrink-0">
                          {u.firstName?.[0] ?? '?'}
                        </div>
                        <div>
                          <p className="font-medium text-slate-100">
                            {u.fullName ?? `${u.firstName} ${u.lastName}`}
                            {isCurrentUser && <span className="text-xs text-teal-400 mr-2">(أنت)</span>}
                          </p>
                          {u.phone && <p className="text-xs text-slate-500 font-mono">{u.phone}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="table-td font-mono text-sm text-slate-400">{u.username}</td>
                    <td className="table-td text-sm text-slate-400">{u.email}</td>
                    <td className="table-td">
                      {role ? <span className={role.color}>{role.label}</span> : <span className="badge-slate">—</span>}
                    </td>
                    <td className="table-td text-slate-400 text-sm">{u.branchName ?? 'كل الفروع'}</td>
                    <td className="table-td text-slate-500 text-xs">
                      {u.lastLoginAt
                        ? new Date(u.lastLoginAt).toLocaleDateString('ar-EG', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
                        : 'لم يدخل بعد'}
                    </td>
                    <td className="table-td">
                      <span className={u.isActive ? 'badge-green' : 'badge-red'}>
                        {u.isActive ? 'نشط' : 'معطّل'}
                      </span>
                      {u.twoFactorEnabled && <span className="badge-teal mr-1">🔐 MFA</span>}
                    </td>
                    <td className="table-td">
                      {!isCurrentUser && (
                        <div className="flex gap-1">
                          <button onClick={() => openEdit(u)} className="btn-sm btn-ghost">تعديل</button>
                          <button onClick={() => toggleActive(u)}
                            className={`btn-sm ${u.isActive ? 'btn-danger' : 'btn-teal'}`}>
                            {u.isActive ? 'تعطيل' : 'تفعيل'}
                          </button>
                          <button onClick={() => resetPassword(u.id)} className="btn-sm btn-ghost" title="إعادة ضبط كلمة المرور">
                            🔑
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>

          {totalPages > 1 && (
            <div className="px-4 py-3 border-t border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
              <span>{total} مستخدم</span>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-sm btn-ghost">السابق</button>
                <span className="px-3 py-1.5 bg-slate-700/50 rounded-lg">{page} / {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="btn-sm btn-ghost">التالي</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* User Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="card max-w-lg w-full p-6 animate-fade-up" dir="rtl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-slate-100 text-base">
                {editUser ? 'تعديل مستخدم' : 'إضافة مستخدم جديد'}
              </h3>
              <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-slate-200 transition text-xl leading-none">&times;</button>
            </div>
            <form onSubmit={save} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">الاسم الأول *</label>
                  <input className="input" required value={form.firstName}
                    onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} />
                </div>
                <div>
                  <label className="label">اسم العائلة *</label>
                  <input className="input" required value={form.lastName}
                    onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} />
                </div>
                <div>
                  <label className="label">اسم المستخدم *</label>
                  <input className="input" dir="ltr" required value={form.username}
                    onChange={e => setForm(f => ({ ...f, username: e.target.value }))} />
                </div>
                <div>
                  <label className="label">البريد الإلكتروني *</label>
                  <input className="input" type="email" dir="ltr" required value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
                {!editUser && (
                  <div className="col-span-2">
                    <label className="label">كلمة المرور *</label>
                    <input className="input" type="password" dir="ltr" required minLength={8}
                      placeholder="8 أحرف على الأقل + حرف كبير + رقم + رمز"
                      value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
                  </div>
                )}
                <div>
                  <label className="label">رقم الهاتف</label>
                  <input className="input" type="tel" value={form.phone}
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                </div>
                <div>
                  <label className="label">الدور</label>
                  <select className="select" value={form.role}
                    onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                    {Object.entries(ROLES).filter(([k]) => parseInt(k) >= 3).map(([k, v]) => (
                      <option key={k} value={k}>{v.label}</option>
                    ))}
                  </select>
                </div>
              </div>
              {ROLES[parseInt(form.role)]?.description && (
                <p className="text-xs text-slate-500 bg-slate-700/30 rounded-lg px-3 py-2">
                  💡 {ROLES[parseInt(form.role)].description}
                </p>
              )}
              <div className="flex gap-3 pt-1">
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? '⏳ جاري الحفظ...' : editUser ? '💾 حفظ التغييرات' : '✅ إضافة المستخدم'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
