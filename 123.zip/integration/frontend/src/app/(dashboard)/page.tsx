'use client'
import { useCallback, useEffect, useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import toast from 'react-hot-toast'
import DashboardLayout from '@/components/layout/DashboardShell'
import { dashboardAPI } from '@/lib/api'

interface Stats {
  todayRevenue: number
  todayOrders: number
  monthRevenue: number
  monthOrders: number
  totalCustomers: number
  newThisMonth: number
  totalProducts: number
  lowStockCount: number
  activeBranches: number
  avgOrderValue: number
  grossProfitToday: number
  weekSales: Array<{ date: string; revenue: number; orders: number; profit: number }>
  topProducts: Array<{ productId: string; name: string; quantitySold: number; revenue: number }>
  recentOrders: Array<{ id: string; orderNumber: string; customerName?: string; amount: number; paymentMethod: string; at: string }>
}

const EGP = (value = 0) =>
  value.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' ج.م'

function StatCard(props: { icon: string; label: string; value: string; sub?: string; accent: string }) {
  const { icon, label, value, sub, accent } = props

  return (
    <div className={`card border-r-2 p-5 ${accent}`}>
      <span className="mb-3 block text-2xl">{icon}</span>
      <p className="font-mono text-2xl font-bold tabular-nums text-slate-100">{value}</p>
      <p className="mt-1 text-xs text-slate-400">{label}</p>
      {sub && <p className="mt-0.5 text-xs text-slate-600">{sub}</p>}
    </div>
  )
}

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      const { data } = await dashboardAPI.stats()
      if (data.success) {
        setStats(data.data)
      } else {
        toast.error(data.message ?? 'فشل تحميل لوحة التحكم')
      }
    } catch {
      toast.error('فشل تحميل لوحة التحكم')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
    const timer = setInterval(load, 60_000)
    return () => clearInterval(timer)
  }, [load])

  if (loading) {
    return (
      <DashboardLayout title="الرئيسية">
        <div className="flex h-80 items-center justify-center">
          <div className="text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-2 border-amber-500/30 border-t-amber-500" />
            <p className="mt-3 text-sm text-slate-400">جاري تحميل الإحصائيات...</p>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  const s = stats

  return (
    <DashboardLayout title="لوحة التحكم">
      <div className="animate-fade-up space-y-6 p-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard icon="💰" label="مبيعات اليوم" value={EGP(s?.todayRevenue)} sub={`${s?.todayOrders ?? 0} طلب`} accent="border-amber-500" />
          <StatCard icon="📅" label="مبيعات الشهر" value={EGP(s?.monthRevenue)} sub={`${s?.monthOrders ?? 0} طلب`} accent="border-teal-500" />
          <StatCard icon="👥" label="إجمالي العملاء" value={(s?.totalCustomers ?? 0).toLocaleString('ar-EG')} sub={`+${s?.newThisMonth ?? 0} هذا الشهر`} accent="border-blue-500" />
          <StatCard icon="⚠️" label="منخفض المخزون" value={String(s?.lowStockCount ?? 0)} sub={`من ${s?.totalProducts ?? 0} منتج`} accent="border-red-500" />
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <StatCard icon="📊" label="متوسط الطلب" value={EGP(s?.avgOrderValue)} sub="لكل فاتورة" accent="border-purple-500" />
          <StatCard icon="💹" label="ربح اليوم" value={EGP(s?.grossProfitToday)} sub="هامش تقريبي" accent="border-green-500" />
          <StatCard icon="🏢" label="الفروع النشطة" value={String(s?.activeBranches ?? 0)} sub="جاهزة للبيع" accent="border-slate-500" />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="card p-5 lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-200">المبيعات خلال آخر 7 أيام</h3>
              <a href="/pos" className="text-xs text-amber-400 hover:underline">فتح الكاشير ←</a>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={s?.weekSales ?? []}>
                <defs>
                  <linearGradient id="dashboardRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#334155" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(value) => `${Math.round(value / 1000)}K`} />
                <Tooltip
                  contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                  labelStyle={{ color: '#94a3b8', fontSize: 11 }}
                  formatter={(value: number) => [EGP(value), 'المبيعات']}
                />
                <Area type="monotone" dataKey="revenue" stroke="#d97706" strokeWidth={2} fill="url(#dashboardRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="card p-5">
            <h3 className="mb-4 text-sm font-semibold text-slate-200">أفضل المنتجات</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={s?.topProducts ?? []} layout="vertical" margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
                <CartesianGrid stroke="#334155" strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="name" width={90} tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                  formatter={(value: number) => [EGP(value), 'الإيراد']}
                />
                <Bar dataKey="revenue" fill="#14b8a6" radius={[8, 8, 8, 8]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-700/50 px-5 py-3.5">
            <h3 className="text-sm font-semibold text-slate-200">آخر الفواتير</h3>
            <a href="/pos" className="text-xs text-amber-400 hover:underline">عملية بيع جديدة ←</a>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  {['رقم الفاتورة', 'العميل', 'المبلغ', 'الدفع', 'الوقت'].map((heading) => (
                    <th key={heading} className="table-hd">{heading}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(s?.recentOrders ?? []).map((order) => (
                  <tr key={order.id} className="table-tr">
                    <td className="table-td font-mono text-xs text-amber-400">{order.orderNumber}</td>
                    <td className="table-td">{order.customerName ?? <span className="text-slate-500">زائر</span>}</td>
                    <td className="table-td font-semibold">{EGP(order.amount)}</td>
                    <td className="table-td">
                      <span className="badge-slate">{order.paymentMethod}</span>
                    </td>
                    <td className="table-td text-xs text-slate-400">
                      {new Date(order.at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
                {!s?.recentOrders?.length && (
                  <tr>
                    <td colSpan={5} className="table-td py-10 text-center text-slate-500">
                      لا توجد فواتير بعد
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
