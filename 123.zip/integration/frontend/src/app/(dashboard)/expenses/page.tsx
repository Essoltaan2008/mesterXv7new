'use client'
import { useState, useEffect, useCallback } from 'react'
import DashboardLayout from '@/components/layout/DashboardShell'
import { api } from '@/lib/api'
import toast from 'react-hot-toast'

// Expenses page — tracks all business expenses with categorization
// Egyptian businesses need VAT-inclusive expense tracking for tax compliance

const EGP = (n = 0) => n.toLocaleString('ar-EG', { minimumFractionDigits: 2 }) + ' ج.م'

const CATEGORIES: Record<number, { label: string; icon: string }> = {
  0:  { label: 'إيجار',        icon: '🏢' },
  1:  { label: 'رواتب',        icon: '👥' },
  2:  { label: 'مرافق',        icon: '💡' },
  3:  { label: 'تسويق',        icon: '📣' },
  4:  { label: 'مستلزمات',     icon: '📦' },
  5:  { label: 'صيانة',        icon: '🔧' },
  6:  { label: 'توصيل',        icon: '🚚' },
  7:  { label: 'تأمين',        icon: '🛡️' },
  8:  { label: 'ضرائب',        icon: '🏦' },
  99: { label: 'أخرى',         icon: '📋' },
}

const PAYMENT_METHODS: Record<number, string> = {
  0: 'نقدي', 1: 'كارت', 2: 'محفظة إلكترونية', 3: 'تحويل بنكي'
}

export default function ExpensesPage() {
  const [expenses, setExpenses]   = useState<any[]>([])
  const [search, setSearch]       = useState('')
  const [catFilter, setCatFilter] = useState<string>('all')
  const [dateFrom, setDateFrom]   = useState('')
  const [dateTo, setDateTo]       = useState('')
  const [page, setPage]           = useState(1)
  const [total, setTotal]         = useState(0)
  const [loading, setLoading]     = useState(false)
  const [showForm, setShowForm]   = useState(false)
  const [saving, setSaving]       = useState(false)
  const [summary, setSummary]     = useState<Record<number, number>>({})

  const [form, setForm] = useState({
    description: '', category: '0', amount: '',
    expenseDate: new Date().toISOString().split('T')[0],
    paymentMethod: '0', reference: '', notes: ''
  })

  const PAGE_SIZE = 20

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: String(page), pageSize: String(PAGE_SIZE),
        ...(search && { search }),
        ...(catFilter !== 'all' && { category: catFilter }),
        ...(dateFrom && { fromDate: dateFrom }),
        ...(dateTo   && { toDate: dateTo }),
      })
      const { data } = await api.get(`/expenses?${params}`)
      const items = data.data?.items ?? []
      setExpenses(items)
      setTotal(data.data?.totalCount ?? 0)

      // Build category summary from loaded data
      const s: Record<number, number> = {}
      items.forEach((e: any) => { s[e.category] = (s[e.category] ?? 0) + e.amount })
      setSummary(s)
    } catch { toast.error('فشل تحميل المصروفات') }
    finally { setLoading(false) }
  }, [page, search, catFilter, dateFrom, dateTo])

  useEffect(() => { load() }, [load])

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.description.trim()) { toast.error('وصف المصروف مطلوب'); return }
    if (!form.amount || parseFloat(form.amount) <= 0) { toast.error('المبلغ يجب أن يكون أكبر من صفر'); return }
    setSaving(true)
    try {
      const payload = {
        description: form.description,
        category: parseInt(form.category),
        amount: parseFloat(form.amount),
        expenseDate: form.expenseDate,
        paymentMethod: parseInt(form.paymentMethod),
        reference: form.reference || null,
        notes: form.notes || null,
      }
      const { data } = await api.post('/expenses', payload)
      if (data.success) {
        toast.success('تم تسجيل المصروف')
        setShowForm(false)
        resetForm()
        load()
      } else toast.error(data.message || 'فشل التسجيل')
    } catch (e: any) { toast.error(e?.response?.data?.message ?? 'فشل التسجيل') }
    finally { setSaving(false) }
  }

  const resetForm = () => setForm({
    description: '', category: '0', amount: '',
    expenseDate: new Date().toISOString().split('T')[0],
    paymentMethod: '0', reference: '', notes: ''
  })

  const totalExpenses = expenses.reduce((a, e) => a + (e.amount ?? 0), 0)
  const totalPages    = Math.ceil(total / PAGE_SIZE)

  return (
    <DashboardLayout title="المصروفات">
      <div className="p-6 space-y-6 animate-fade-up">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100">إدارة المصروفات</h2>
            <p className="text-sm text-slate-400 mt-0.5">
              إجمالي المعروض: <span className="text-red-400 font-semibold">{EGP(totalExpenses)}</span>
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <input className="input w-40" placeholder="🔍 بحث..." value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }} />
            <select className="select w-36" value={catFilter}
              onChange={e => { setCatFilter(e.target.value); setPage(1) }}>
              <option value="all">كل الفئات</option>
              {Object.entries(CATEGORIES).map(([k, v]) => (
                <option key={k} value={k}>{v.icon} {v.label}</option>
              ))}
            </select>
            <input className="input w-36" type="date" value={dateFrom}
              onChange={e => { setDateFrom(e.target.value); setPage(1) }} />
            <input className="input w-36" type="date" value={dateTo}
              onChange={e => { setDateTo(e.target.value); setPage(1) }} />
            <button onClick={() => setShowForm(true)} className="btn-primary">
              + مصروف جديد
            </button>
          </div>
        </div>

        {/* Category summary cards */}
        {Object.keys(summary).length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {Object.entries(summary).map(([cat, amount]) => {
              const catInfo = CATEGORIES[parseInt(cat)] ?? { label: 'أخرى', icon: '📋' }
              return (
                <button key={cat} onClick={() => setCatFilter(catFilter === cat ? 'all' : cat)}
                  className={`card-sm p-3 text-center transition-all ${catFilter === cat ? 'border-amber-500 bg-amber-500/10' : 'hover:border-slate-600'}`}>
                  <span className="text-2xl block mb-1">{catInfo.icon}</span>
                  <p className="text-xs text-slate-400">{catInfo.label}</p>
                  <p className="text-sm font-bold text-amber-400 font-mono mt-1">{EGP(amount as number)}</p>
                </button>
              )
            })}
          </div>
        )}

        {/* Table */}
        <div className="card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr>
                {['التاريخ', 'الوصف', 'الفئة', 'المبلغ', 'طريقة الدفع', 'المرجع'].map(h => (
                  <th key={h} className="table-hd">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="table-td text-center py-12">
                  <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
                </td></tr>
              ) : expenses.length === 0 ? (
                <tr><td colSpan={6} className="table-td text-center py-12">
                  <p className="text-3xl mb-2">💸</p>
                  <p className="text-sm text-slate-500">{search || catFilter !== 'all' ? 'لا توجد نتائج' : 'لم يُسجّل أي مصروف بعد'}</p>
                </td></tr>
              ) : expenses.map((e: any) => {
                const cat = CATEGORIES[e.category] ?? { label: 'أخرى', icon: '📋' }
                return (
                  <tr key={e.id} className="table-tr">
                    <td className="table-td font-mono text-sm text-slate-400">
                      {new Date(e.expenseDate).toLocaleDateString('ar-EG')}
                    </td>
                    <td className="table-td">
                      <p className="font-medium text-slate-100">{e.description}</p>
                      {e.notes && <p className="text-xs text-slate-500 mt-0.5">{e.notes}</p>}
                    </td>
                    <td className="table-td">
                      <span className="badge-slate">{cat.icon} {cat.label}</span>
                    </td>
                    <td className="table-td font-bold text-red-400 font-mono">{EGP(e.amount)}</td>
                    <td className="table-td text-slate-400 text-sm">
                      {PAYMENT_METHODS[e.paymentMethod] ?? '—'}
                    </td>
                    <td className="table-td font-mono text-xs text-slate-500">{e.reference ?? '—'}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>

          {totalPages > 1 && (
            <div className="px-4 py-3 border-t border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
              <span>{total} مصروف</span>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-sm btn-ghost">السابق</button>
                <span className="px-3 py-1.5 bg-slate-700/50 rounded-lg">{page} / {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="btn-sm btn-ghost">التالي</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Expense Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="card max-w-md w-full p-6 animate-fade-up" dir="rtl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-slate-100 text-base">تسجيل مصروف جديد</h3>
              <button onClick={() => { setShowForm(false); resetForm() }}
                className="text-slate-500 hover:text-slate-200 transition text-xl leading-none">&times;</button>
            </div>
            <form onSubmit={save} className="space-y-4">
              <div>
                <label className="label">وصف المصروف *</label>
                <input className="input" placeholder="مثال: إيجار شهر يونيو..." required
                  value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">الفئة</label>
                  <select className="select" value={form.category}
                    onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                    {Object.entries(CATEGORIES).map(([k, v]) => (
                      <option key={k} value={k}>{v.icon} {v.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">المبلغ (ج.م) *</label>
                  <input className="input" type="number" step="0.01" min="0.01" placeholder="0.00" required
                    value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
                </div>
                <div>
                  <label className="label">التاريخ</label>
                  <input className="input" type="date" value={form.expenseDate}
                    onChange={e => setForm(f => ({ ...f, expenseDate: e.target.value }))} />
                </div>
                <div>
                  <label className="label">طريقة الدفع</label>
                  <select className="select" value={form.paymentMethod}
                    onChange={e => setForm(f => ({ ...f, paymentMethod: e.target.value }))}>
                    {Object.entries(PAYMENT_METHODS).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="label">رقم المرجع / الإيصال</label>
                <input className="input" placeholder="اختياري — رقم الفاتورة أو الإيصال"
                  value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))} />
              </div>
              <div>
                <label className="label">ملاحظات</label>
                <input className="input" placeholder="اختياري..."
                  value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
              </div>
              <div className="flex gap-3 pt-1">
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? '⏳ جاري الحفظ...' : '✅ تسجيل المصروف'}
                </button>
                <button type="button" onClick={() => { setShowForm(false); resetForm() }} className="btn-ghost">
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
