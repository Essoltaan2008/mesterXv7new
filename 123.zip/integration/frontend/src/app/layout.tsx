import type { Metadata } from 'next'
import { Toaster } from 'react-hot-toast'
import './globals.css'

export const metadata: Metadata = {
  title: 'MesterX Enterprise v7',
  description: 'نظام إدارة الأعمال المتكامل — Hybrid Offline-First SaaS',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        {children}
        <Toaster position="top-center" toastOptions={{ className: '!bg-slate-800 !text-slate-100 !border !border-slate-700' }}/>
      </body>
    </html>
  )
}
