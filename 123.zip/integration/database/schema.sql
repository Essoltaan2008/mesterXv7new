-- ══════════════════════════════════════════════════════════════════════════════
-- MesterX Enterprise v7 — PostgreSQL 16 Production Schema
-- Run: psql -U mxuser -d mesterxdb -f schema.sql
-- All tables include: soft-delete, audit timestamps, optimistic concurrency
-- ══════════════════════════════════════════════════════════════════════════════

-- ── Extensions ────────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";   -- uuid_generate_v4()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";     -- Arabic full-text search via GIN index

-- ══════════════════════════════════════════════════════════════════════════════
-- FUNCTIONS
-- ══════════════════════════════════════════════════════════════════════════════

-- Auto-increment version and set updated_at on every UPDATE
CREATE OR REPLACE FUNCTION fn_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = NOW();
    NEW.version    = OLD.version + 1;
    RETURN NEW;
END;
$$;

-- Prevent tamper of audit logs older than 24 hours
CREATE OR REPLACE FUNCTION fn_audit_tamper_guard()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.created_at < NOW() - INTERVAL '24 hours' THEN
        RAISE EXCEPTION 'AUDIT_TAMPER: Cannot modify audit record older than 24h (id=%)', OLD.id;
    END IF;
    RETURN NEW;
END;
$$;

-- ══════════════════════════════════════════════════════════════════════════════
-- CORE TABLES
-- ══════════════════════════════════════════════════════════════════════════════

-- ── Plans (global — no tenant_id) ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS plans (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name                    VARCHAR(100) NOT NULL,
    name_en                 VARCHAR(100) NOT NULL,
    description             TEXT,
    type                    SMALLINT     NOT NULL UNIQUE,
    sort_order              INT          NOT NULL DEFAULT 0,
    monthly_price           DECIMAL(10,2) NOT NULL DEFAULT 0,
    annual_price            DECIMAL(10,2) NOT NULL DEFAULT 0,
    lifetime_price          DECIMAL(10,2) NOT NULL DEFAULT 0,
    max_branches            INT          NOT NULL DEFAULT 1,     -- -1 = unlimited
    max_users               INT          NOT NULL DEFAULT 1,     -- -1 = unlimited
    max_products            INT          NOT NULL DEFAULT 500,   -- -1 = unlimited
    has_sync_engine         BOOLEAN      NOT NULL DEFAULT FALSE,
    has_multi_branch        BOOLEAN      NOT NULL DEFAULT FALSE,
    has_advanced_reports    BOOLEAN      NOT NULL DEFAULT FALSE,
    has_api_access          BOOLEAN      NOT NULL DEFAULT FALSE,
    has_white_label         BOOLEAN      NOT NULL DEFAULT FALSE,
    has_ai                  BOOLEAN      NOT NULL DEFAULT FALSE,
    has_plugin_store        BOOLEAN      NOT NULL DEFAULT FALSE,
    has_marketplace         BOOLEAN      NOT NULL DEFAULT FALSE,
    has_delivery            BOOLEAN      NOT NULL DEFAULT FALSE,
    has_whatsapp            BOOLEAN      NOT NULL DEFAULT FALSE,
    max_whatsapp_numbers    INT          NOT NULL DEFAULT 0,
    has_restaurant_module   BOOLEAN      NOT NULL DEFAULT FALSE,
    max_restaurant_tables   INT          NOT NULL DEFAULT 0,
    has_kds                 BOOLEAN      NOT NULL DEFAULT FALSE,
    has_qr_menu             BOOLEAN      NOT NULL DEFAULT FALSE,
    has_rental_module       BOOLEAN      NOT NULL DEFAULT FALSE,
    max_rental_assets       INT          NOT NULL DEFAULT 0,
    support_level           VARCHAR(50)  NOT NULL DEFAULT 'basic',
    uptime_sla_pct          SMALLINT     NOT NULL DEFAULT 99,
    is_active               BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version                 INT          NOT NULL DEFAULT 1
);

-- ── Tenants ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tenants (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,                              -- mirrors id; kept for BaseEntity compatibility
    name                VARCHAR(200) NOT NULL,
    slug                VARCHAR(100) NOT NULL,
    logo_url            VARCHAR(500),
    business_type       SMALLINT     NOT NULL DEFAULT 2,            -- RetailStore
    description         TEXT,
    contact_email       VARCHAR(256),
    contact_phone       VARCHAR(30),
    whatsapp            VARCHAR(30),
    website             VARCHAR(500),
    address             TEXT,
    city                VARCHAR(100),
    country             CHAR(2)      NOT NULL DEFAULT 'EG',
    tax_number          VARCHAR(50),
    currency            VARCHAR(10)  NOT NULL DEFAULT 'EGP',
    vat_rate            DECIMAL(5,4) NOT NULL DEFAULT 0.14,
    language            VARCHAR(5)   NOT NULL DEFAULT 'ar',
    timezone            VARCHAR(50)  NOT NULL DEFAULT 'Africa/Cairo',
    status              SMALLINT     NOT NULL DEFAULT 0,            -- Trial
    plan                SMALLINT     NOT NULL DEFAULT 0,            -- Trial
    active_modules      INT          NOT NULL DEFAULT 3,            -- POS | Inventory
    is_active           BOOLEAN      NOT NULL DEFAULT TRUE,
    is_verified         BOOLEAN      NOT NULL DEFAULT FALSE,
    verified_at         TIMESTAMPTZ,
    trial_ends_at       TIMESTAMPTZ,
    suspended_at        TIMESTAMPTZ,
    suspend_reason      TEXT,
    loyalty_enabled     BOOLEAN      NOT NULL DEFAULT FALSE,
    loyalty_rate        DECIMAL(10,4) NOT NULL DEFAULT 1,
    loyalty_redeem_min  INT          NOT NULL DEFAULT 100,
    receipt_footer      TEXT,
    -- Soft delete
    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ,
    deleted_by          UUID,
    -- Audit
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by          UUID,
    updated_by          UUID,
    version             INT          NOT NULL DEFAULT 1,
    CONSTRAINT uq_tenants_slug UNIQUE (slug)
);
CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants (status) WHERE NOT is_deleted;
CREATE INDEX IF NOT EXISTS idx_tenants_plan   ON tenants (plan)   WHERE NOT is_deleted;

-- ── Subscriptions ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    plan_id             UUID NOT NULL REFERENCES plans(id)   ON DELETE RESTRICT,
    status              SMALLINT     NOT NULL DEFAULT 0,
    billing_cycle       SMALLINT     NOT NULL DEFAULT 0,
    amount              DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_amount     DECIMAL(10,2) NOT NULL DEFAULT 0,
    start_date          TIMESTAMPTZ  NOT NULL,
    end_date            TIMESTAMPTZ  NOT NULL,
    trial_ends_at       TIMESTAMPTZ,
    cancelled_at        TIMESTAMPTZ,
    cancel_reason       VARCHAR(500),
    auto_renew          BOOLEAN      NOT NULL DEFAULT TRUE,
    next_billing_date   TIMESTAMPTZ,
    payment_gateway     VARCHAR(50),
    external_ref        VARCHAR(200),
    last_payment_ref    VARCHAR(200),
    last_payment_at     TIMESTAMPTZ,
    failed_attempts     SMALLINT     NOT NULL DEFAULT 0,
    sync_addon_active   BOOLEAN      NOT NULL DEFAULT FALSE,
    sync_addon_expires  TIMESTAMPTZ,
    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version             INT          NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant ON subscriptions (tenant_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_renew  ON subscriptions (next_billing_date) WHERE auto_renew AND NOT is_deleted;

-- ── Branches ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS branches (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id)  ON DELETE CASCADE,
    manager_id      UUID,                                              -- FK to users set after
    name            VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200),
    code            VARCHAR(20),
    address         TEXT,
    city            VARCHAR(100),
    country         CHAR(2)      NOT NULL DEFAULT 'EG',
    phone_number    VARCHAR(30),
    email           VARCHAR(256),
    latitude        DECIMAL(10,7),
    longitude       DECIMAL(10,7),
    is_main         BOOLEAN      NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    open_time       TIME,
    close_time      TIME,
    is_deleted      BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at      TIMESTAMPTZ,
    deleted_by      UUID,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by      UUID,
    updated_by      UUID,
    version         INT          NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_branches_tenant ON branches (tenant_id) WHERE NOT is_deleted;

-- ── Users ───────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id               UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    branch_id               UUID REFERENCES branches(id) ON DELETE SET NULL,
    username                VARCHAR(100) NOT NULL,
    email                   VARCHAR(256) NOT NULL,
    password_hash           VARCHAR(100) NOT NULL,                    -- BCrypt $2a$12$ hash
    first_name              VARCHAR(100) NOT NULL,
    last_name               VARCHAR(100) NOT NULL,
    phone                   VARCHAR(30),
    avatar_url              VARCHAR(500),
    role                    SMALLINT     NOT NULL DEFAULT 5,          -- Cashier
    is_active               BOOLEAN      NOT NULL DEFAULT TRUE,
    is_email_verified       BOOLEAN      NOT NULL DEFAULT FALSE,
    email_verified_at       TIMESTAMPTZ,
    last_login_at           TIMESTAMPTZ,
    last_login_ip           VARCHAR(50),
    last_login_device       VARCHAR(250),
    failed_login_attempts   SMALLINT     NOT NULL DEFAULT 0,
    lockout_end             TIMESTAMPTZ,                              -- NULL = not locked
    two_factor_enabled      BOOLEAN      NOT NULL DEFAULT FALSE,
    totp_secret             VARCHAR(512),                             -- AES-256 encrypted in production
    backup_codes            TEXT,                                     -- JSON array of hashed backup codes
    password_changed_at     TIMESTAMPTZ,
    must_change_password    BOOLEAN      NOT NULL DEFAULT FALSE,
    language                VARCHAR(5)   NOT NULL DEFAULT 'ar',
    theme                   VARCHAR(20)  NOT NULL DEFAULT 'dark',
    timezone                VARCHAR(50)  NOT NULL DEFAULT 'Africa/Cairo',
    is_deleted              BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at              TIMESTAMPTZ,
    deleted_by              UUID,
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    version                 INT          NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email    ON users (email)    WHERE NOT is_deleted;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users (username) WHERE NOT is_deleted;
CREATE        INDEX IF NOT EXISTS idx_users_tenant   ON users (tenant_id, role) WHERE NOT is_deleted;

-- Add FK back-reference from branches to users (manager)
ALTER TABLE branches ADD CONSTRAINT fk_branches_manager
    FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL
    NOT VALID;                                                        -- NOT VALID allows deferred validation

-- ── Refresh Tokens ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL,
    user_id         UUID NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
    token_hash      VARCHAR(512) NOT NULL,                            -- SHA-256(raw + salt)
    salt            VARCHAR(100) NOT NULL,                            -- per-token random salt
    device_info     VARCHAR(250),
    ip_address      VARCHAR(50),
    is_revoked      BOOLEAN      NOT NULL DEFAULT FALSE,
    expires_at      TIMESTAMPTZ  NOT NULL,
    revoked_at      TIMESTAMPTZ,
    replaced_by     VARCHAR(512),                                     -- hash of replacement token
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version         INT          NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_rt_user    ON refresh_tokens (user_id);
CREATE INDEX IF NOT EXISTS idx_rt_expires ON refresh_tokens (expires_at) WHERE NOT is_revoked;

-- ── Feature Flags ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feature_flags (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    feature     VARCHAR(100) NOT NULL,
    is_enabled  BOOLEAN      NOT NULL DEFAULT TRUE,
    config      JSONB,
    enabled_at  TIMESTAMPTZ,
    expires_at  TIMESTAMPTZ,
    is_deleted  BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version     INT          NOT NULL DEFAULT 1,
    CONSTRAINT uq_feature_flags UNIQUE (tenant_id, feature)
);

-- ── Categories ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    parent_id   UUID REFERENCES categories(id) ON DELETE SET NULL,
    name        VARCHAR(200) NOT NULL,
    name_ar     VARCHAR(200),
    description TEXT,
    image_url   VARCHAR(500),
    sort_order  INT          NOT NULL DEFAULT 0,
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted  BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at  TIMESTAMPTZ, deleted_by UUID,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by  UUID, updated_by UUID,
    version     INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_categories_tenant ON categories (tenant_id) WHERE NOT is_deleted;

-- ── Products ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    category_id         UUID REFERENCES categories(id)  ON DELETE SET NULL,
    branch_id           UUID REFERENCES branches(id)    ON DELETE SET NULL,  -- NULL = all branches
    name                VARCHAR(300) NOT NULL,
    name_ar             VARCHAR(300),
    description         TEXT,
    barcode             VARCHAR(100),
    sku                 VARCHAR(100),
    type                SMALLINT     NOT NULL DEFAULT 0,  -- Physical
    unit                SMALLINT     NOT NULL DEFAULT 0,  -- Piece
    cost_price          DECIMAL(12,2) NOT NULL DEFAULT 0,
    sale_price          DECIMAL(12,2) NOT NULL DEFAULT 0,
    wholesale_price     DECIMAL(12,2),
    min_sale_price      DECIMAL(12,2),
    has_vat             BOOLEAN      NOT NULL DEFAULT TRUE,
    vat_rate            DECIMAL(5,4) NOT NULL DEFAULT 0.14,
    image_url           VARCHAR(500),
    gallery_urls        TEXT,                                         -- JSON array of image URLs
    is_active           BOOLEAN      NOT NULL DEFAULT TRUE,
    is_available_online BOOLEAN      NOT NULL DEFAULT TRUE,
    is_featured         BOOLEAN      NOT NULL DEFAULT FALSE,
    track_inventory     BOOLEAN      NOT NULL DEFAULT TRUE,
    low_stock_threshold INT          NOT NULL DEFAULT 5,
    reorder_point       DECIMAL(12,4),
    reorder_quantity    DECIMAL(12,4),
    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ, deleted_by UUID,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by  UUID, updated_by UUID,
    version             INT NOT NULL DEFAULT 1
);
-- SKU unique per tenant (partial index excludes soft-deleted)
CREATE UNIQUE INDEX IF NOT EXISTS idx_products_sku     ON products (tenant_id, sku)     WHERE sku IS NOT NULL AND NOT is_deleted;
CREATE        INDEX IF NOT EXISTS idx_products_barcode ON products (barcode)             WHERE barcode IS NOT NULL;
CREATE        INDEX IF NOT EXISTS idx_products_tenant  ON products (tenant_id, is_active) WHERE NOT is_deleted;
-- Arabic full-text search using trigram GIN index
CREATE        INDEX IF NOT EXISTS idx_products_name_trgm ON products USING gin (name    gin_trgm_ops);
CREATE        INDEX IF NOT EXISTS idx_products_ar_trgm   ON products USING gin (name_ar gin_trgm_ops) WHERE name_ar IS NOT NULL;

-- ── Stock Items ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stock_items (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    product_id          UUID NOT NULL REFERENCES products(id)  ON DELETE CASCADE,
    branch_id           UUID NOT NULL REFERENCES branches(id)  ON DELETE CASCADE,
    quantity            DECIMAL(12,4) NOT NULL DEFAULT 0,
    reserved_quantity   DECIMAL(12,4) NOT NULL DEFAULT 0,
    last_cost_price     DECIMAL(12,2),
    last_counted_at     TIMESTAMPTZ,
    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_stock_product_branch UNIQUE (product_id, branch_id),
    CONSTRAINT chk_stock_non_negative  CHECK  (quantity >= 0)
);
CREATE INDEX IF NOT EXISTS idx_stock_tenant_branch ON stock_items (tenant_id, branch_id)  WHERE NOT is_deleted;
-- Partial index to efficiently find low-stock items
CREATE INDEX IF NOT EXISTS idx_stock_low
    ON stock_items (tenant_id)
    WHERE quantity <= 5 AND NOT is_deleted;

-- ── Stock Movements ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stock_movements (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    product_id          UUID NOT NULL REFERENCES products(id)  ON DELETE RESTRICT,
    branch_id           UUID NOT NULL REFERENCES branches(id)  ON DELETE RESTRICT,
    user_id             UUID REFERENCES users(id) ON DELETE SET NULL,
    sale_order_id       UUID,
    purchase_order_id   UUID,
    transfer_to_id      UUID REFERENCES branches(id) ON DELETE SET NULL,
    type                SMALLINT      NOT NULL,
    quantity_before     DECIMAL(12,4) NOT NULL,
    quantity_change     DECIMAL(12,4) NOT NULL,
    quantity_after      DECIMAL(12,4) NOT NULL,
    unit_cost           DECIMAL(12,2),
    reference           VARCHAR(100),
    notes               TEXT,
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1
    -- No soft-delete on movements — they are immutable historical records
);
CREATE INDEX IF NOT EXISTS idx_stock_mov_tenant  ON stock_movements (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stock_mov_product ON stock_movements (product_id, branch_id, created_at DESC);

-- ── Customers ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS customers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id)   ON DELETE CASCADE,
    name                VARCHAR(200) NOT NULL,
    phone               VARCHAR(30),
    email               VARCHAR(256),
    address             TEXT,
    city                VARCHAR(100),
    gender              SMALLINT     NOT NULL DEFAULT 0,
    date_of_birth       DATE,
    segment             SMALLINT     NOT NULL DEFAULT 0,         -- New
    loyalty_points      DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_purchases     DECIMAL(14,2) NOT NULL DEFAULT 0,
    total_orders        INT          NOT NULL DEFAULT 0,
    last_purchase_at    TIMESTAMPTZ,
    first_purchase_at   TIMESTAMPTZ,
    credit_limit        DECIMAL(12,2) NOT NULL DEFAULT 0,
    outstanding_balance DECIMAL(12,2) NOT NULL DEFAULT 0,
    allow_credit        BOOLEAN      NOT NULL DEFAULT FALSE,
    is_active           BOOLEAN      NOT NULL DEFAULT TRUE,
    is_blacklisted      BOOLEAN      NOT NULL DEFAULT FALSE,
    blacklist_reason    TEXT,
    notes               TEXT,
    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ, deleted_by UUID,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by UUID, updated_by UUID,
    version             INT NOT NULL DEFAULT 1
);
-- Phone unique per tenant (partial index)
CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_phone  ON customers (tenant_id, phone) WHERE phone IS NOT NULL AND NOT is_deleted;
CREATE        INDEX IF NOT EXISTS idx_customers_tenant ON customers (tenant_id, segment) WHERE NOT is_deleted;
CREATE        INDEX IF NOT EXISTS idx_customers_search ON customers USING gin (name gin_trgm_ops);

-- ── Suppliers ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS suppliers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id)   ON DELETE CASCADE,
    name                VARCHAR(200) NOT NULL,
    contact_person      VARCHAR(100),
    phone               VARCHAR(30),
    email               VARCHAR(256),
    address             TEXT,
    city                VARCHAR(100),
    tax_number          VARCHAR(50),
    status              SMALLINT     NOT NULL DEFAULT 0,
    credit_limit        DECIMAL(12,2) NOT NULL DEFAULT 0,
    outstanding_balance DECIMAL(12,2) NOT NULL DEFAULT 0,
    payment_terms_days  INT          NOT NULL DEFAULT 30,
    notes               TEXT,
    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ, deleted_by UUID,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by UUID, updated_by UUID,
    version             INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_suppliers_tenant ON suppliers (tenant_id) WHERE NOT is_deleted;

-- ── Expenses ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id)  ON DELETE CASCADE,
    branch_id       UUID REFERENCES branches(id)          ON DELETE SET NULL,
    approved_by_id  UUID REFERENCES users(id)             ON DELETE SET NULL,
    description     VARCHAR(500) NOT NULL,
    category        SMALLINT     NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    expense_date    DATE         NOT NULL,
    payment_method  SMALLINT     NOT NULL DEFAULT 0,
    reference       VARCHAR(100),
    attachment_url  VARCHAR(500),
    notes           TEXT,
    is_recurring    BOOLEAN      NOT NULL DEFAULT FALSE,
    is_deleted      BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at      TIMESTAMPTZ, deleted_by UUID,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by UUID, updated_by UUID,
    version         INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_expenses_tenant ON expenses (tenant_id, expense_date DESC) WHERE NOT is_deleted;

-- ── Sale Orders ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sale_orders (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id               UUID NOT NULL REFERENCES tenants(id)  ON DELETE RESTRICT,
    branch_id               UUID NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    customer_id             UUID REFERENCES customers(id)         ON DELETE SET NULL,
    cashier_id              UUID NOT NULL REFERENCES users(id)    ON DELETE RESTRICT,
    order_number            VARCHAR(50)  NOT NULL,
    status                  SMALLINT     NOT NULL DEFAULT 0,
    payment_method          SMALLINT     NOT NULL DEFAULT 0,
    discount_type           SMALLINT,
    sub_total               DECIMAL(14,2) NOT NULL DEFAULT 0,
    vat_amount              DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount         DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_amount            DECIMAL(14,2) NOT NULL DEFAULT 0,
    amount_paid             DECIMAL(14,2) NOT NULL DEFAULT 0,
    change_given            DECIMAL(12,2) NOT NULL DEFAULT 0,
    loyalty_points_used     DECIMAL(12,2) NOT NULL DEFAULT 0,
    loyalty_points_earned   DECIMAL(12,2) NOT NULL DEFAULT 0,
    is_offline              BOOLEAN      NOT NULL DEFAULT FALSE,
    client_idempotency_key  VARCHAR(200),
    is_printed              BOOLEAN      NOT NULL DEFAULT FALSE,
    printed_at              TIMESTAMPTZ,
    synced_at               TIMESTAMPTZ,
    notes                   TEXT,
    is_deleted              BOOLEAN      NOT NULL DEFAULT FALSE,
    deleted_at              TIMESTAMPTZ, deleted_by UUID,
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_by UUID, updated_by UUID,
    version                 INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_sale_orders_number UNIQUE (order_number)
);
CREATE        INDEX IF NOT EXISTS idx_so_tenant_date  ON sale_orders (tenant_id, created_at DESC) WHERE NOT is_deleted;
CREATE        INDEX IF NOT EXISTS idx_so_branch_date  ON sale_orders (branch_id, created_at DESC) WHERE NOT is_deleted;
CREATE        INDEX IF NOT EXISTS idx_so_customer     ON sale_orders (customer_id)                WHERE customer_id IS NOT NULL;
-- Idempotency key partial unique index (only for non-null keys)
CREATE UNIQUE INDEX IF NOT EXISTS idx_so_idempotency  ON sale_orders (client_idempotency_key)     WHERE client_idempotency_key IS NOT NULL;

-- ── Sale Order Items ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sale_order_items (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    sale_order_id       UUID NOT NULL REFERENCES sale_orders(id)  ON DELETE CASCADE,
    product_id          UUID NOT NULL REFERENCES products(id)     ON DELETE RESTRICT,
    product_name        VARCHAR(300) NOT NULL,
    product_barcode     VARCHAR(100),
    product_sku         VARCHAR(100),
    quantity            DECIMAL(12,4) NOT NULL,
    unit_price          DECIMAL(12,2) NOT NULL,
    cost_price          DECIMAL(12,2) NOT NULL DEFAULT 0,
    vat_rate            DECIMAL(5,4)  NOT NULL DEFAULT 0,
    vat_amount          DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_amount     DECIMAL(12,2) NOT NULL DEFAULT 0,
    line_total          DECIMAL(14,2) NOT NULL,
    notes               TEXT,
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_soi_order   ON sale_order_items (sale_order_id);
CREATE INDEX IF NOT EXISTS idx_soi_product ON sale_order_items (product_id, tenant_id);

-- ── Payments ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    sale_order_id       UUID NOT NULL REFERENCES sale_orders(id)  ON DELETE CASCADE,
    processed_by_id     UUID NOT NULL REFERENCES users(id)        ON DELETE RESTRICT,
    method              SMALLINT      NOT NULL,
    amount              DECIMAL(12,2) NOT NULL,
    status              SMALLINT      NOT NULL DEFAULT 2,           -- Completed
    reference           VARCHAR(200),
    external_ref        VARCHAR(200),
    notes               TEXT,
    paid_at             TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_payments_order  ON payments (sale_order_id);
CREATE INDEX IF NOT EXISTS idx_payments_tenant ON payments (tenant_id, paid_at DESC);

-- ── Sale Refunds ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sale_refunds (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    sale_order_id       UUID NOT NULL REFERENCES sale_orders(id)  ON DELETE CASCADE,
    processed_by_id     UUID NOT NULL REFERENCES users(id)        ON DELETE RESTRICT,
    refund_amount       DECIMAL(12,2) NOT NULL,
    refund_method       SMALLINT      NOT NULL DEFAULT 0,
    reason              TEXT,
    reference           VARCHAR(100),
    is_full_refund      BOOLEAN       NOT NULL DEFAULT FALSE,
    refunded_at         TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_refunds_order  ON sale_refunds (sale_order_id);
CREATE INDEX IF NOT EXISTS idx_refunds_tenant ON sale_refunds (tenant_id);

-- ── Purchase Orders ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS purchase_orders (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id)  ON DELETE CASCADE,
    supplier_id         UUID NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
    branch_id           UUID NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    approved_by_id      UUID REFERENCES users(id) ON DELETE SET NULL,
    po_number           VARCHAR(50)   NOT NULL,
    status              SMALLINT      NOT NULL DEFAULT 0,
    total_amount        DECIMAL(14,2) NOT NULL DEFAULT 0,
    amount_paid         DECIMAL(14,2) NOT NULL DEFAULT 0,
    order_date          TIMESTAMPTZ,
    expected_date       TIMESTAMPTZ,
    received_date       TIMESTAMPTZ,
    payment_method      SMALLINT      NOT NULL DEFAULT 0,
    payment_terms_days  INT           NOT NULL DEFAULT 30,
    notes               TEXT,
    attachment_url      VARCHAR(500),
    is_deleted          BOOLEAN       NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ, deleted_by UUID,
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    created_by UUID, updated_by UUID,
    version             INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_po_number UNIQUE (po_number)
);
CREATE INDEX IF NOT EXISTS idx_po_tenant   ON purchase_orders (tenant_id, status) WHERE NOT is_deleted;
CREATE INDEX IF NOT EXISTS idx_po_supplier ON purchase_orders (supplier_id);

-- ── Purchase Order Items ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS purchase_order_items (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    purchase_order_id   UUID NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id          UUID NOT NULL REFERENCES products(id)        ON DELETE RESTRICT,
    product_name        VARCHAR(300) NOT NULL,
    qty_ordered         DECIMAL(12,4) NOT NULL,
    qty_received        DECIMAL(12,4) NOT NULL DEFAULT 0,
    unit_cost           DECIMAL(12,2) NOT NULL,
    vat_amount          DECIMAL(12,2) NOT NULL DEFAULT 0,
    line_total          DECIMAL(14,2) NOT NULL,
    received_at         TIMESTAMPTZ,
    notes               TEXT,
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_poi_order ON purchase_order_items (purchase_order_id);

-- ── Licenses ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS licenses (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id               UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    license_key_hash        VARCHAR(512) NOT NULL,                    -- SHA-512
    plan_type               SMALLINT     NOT NULL DEFAULT 0,
    status                  SMALLINT     NOT NULL DEFAULT 0,
    activated_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    expires_at              TIMESTAMPTZ,
    sync_addon_active       BOOLEAN      NOT NULL DEFAULT FALSE,
    sync_addon_expires_at   TIMESTAMPTZ,
    device_fingerprint_hash VARCHAR(512),                             -- SHA-256
    max_branches            INT          NOT NULL DEFAULT 1,
    max_users               INT          NOT NULL DEFAULT 1,
    max_products            INT          NOT NULL DEFAULT 500,
    downgraded_at           TIMESTAMPTZ,
    downgrade_reason        TEXT,
    is_deleted              BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version                 INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_license_key UNIQUE (license_key_hash)
);
CREATE INDEX IF NOT EXISTS idx_licenses_tenant  ON licenses (tenant_id) WHERE NOT is_deleted;
CREATE INDEX IF NOT EXISTS idx_licenses_expires ON licenses (expires_at, status) WHERE NOT is_deleted;

-- ── Sync Queue ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sync_queue (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL,
    idempotency_key     VARCHAR(200) NOT NULL,
    entity_type         SMALLINT     NOT NULL,
    operation           SMALLINT     NOT NULL,
    payload             JSONB        NOT NULL,
    client_version      INT          NOT NULL DEFAULT 0,
    conflict_strategy   SMALLINT     NOT NULL DEFAULT 0,
    status              SMALLINT     NOT NULL DEFAULT 0,
    has_conflict        BOOLEAN      NOT NULL DEFAULT FALSE,
    conflict_details    TEXT,
    error_message       TEXT,
    processed_at        TIMESTAMPTZ,
    created_by          UUID,
    created_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version             INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_sync_idempotency UNIQUE (tenant_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_sync_pending ON sync_queue (tenant_id, status) WHERE status IN (0,1);

-- ── Audit Logs ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id       UUID     NOT NULL,
    user_id         UUID,
    action          SMALLINT NOT NULL,
    entity_type     VARCHAR(100) NOT NULL,
    entity_id       UUID,
    old_values      JSONB,
    new_values      JSONB,
    ip_address      VARCHAR(50),
    user_agent      VARCHAR(500),
    is_success      BOOLEAN  NOT NULL DEFAULT TRUE,
    error_message   TEXT,
    integrity_hash  VARCHAR(200) NOT NULL,    -- SHA-256 chained hash
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version         INT NOT NULL DEFAULT 1
    -- No soft-delete — audit records are permanent
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_logs (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_user   ON audit_logs (user_id, created_at DESC) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs (entity_type, entity_id)   WHERE entity_id IS NOT NULL;

-- Tamper prevention: prevent UPDATE/DELETE on audit records older than 24h
CREATE TRIGGER trg_audit_tamper_guard
    BEFORE UPDATE OR DELETE ON audit_logs
    FOR EACH ROW EXECUTE FUNCTION fn_audit_tamper_guard();

-- ── Plugins ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS plugins (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200) NOT NULL,
    slug            VARCHAR(100) NOT NULL,
    description     TEXT,
    developer_name  VARCHAR(200),
    developer_url   VARCHAR(500),
    icon_url        VARCHAR(500),
    version         VARCHAR(20)  NOT NULL DEFAULT '1.0.0',
    category        SMALLINT     NOT NULL DEFAULT 99,
    price           DECIMAL(10,2) NOT NULL DEFAULT 0,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_verified     BOOLEAN      NOT NULL DEFAULT FALSE,
    is_featured     BOOLEAN      NOT NULL DEFAULT FALSE,
    install_count   INT          NOT NULL DEFAULT 0,
    rating          DECIMAL(3,2) NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version_num     INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_plugin_slug UNIQUE (slug)
);

-- ── Plugin Installations (per-tenant) ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS plugin_installations (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id   UUID NOT NULL REFERENCES tenants(id)   ON DELETE CASCADE,
    plugin_id   UUID NOT NULL REFERENCES plugins(id)   ON DELETE CASCADE,
    is_enabled  BOOLEAN NOT NULL DEFAULT TRUE,
    config      JSONB,
    installed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    version     INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_plugin_installation UNIQUE (tenant_id, plugin_id)
);

-- ── Platform Config ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS platform_configs (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key            VARCHAR(100) NOT NULL,
    value          TEXT         NOT NULL,
    description_ar VARCHAR(500),
    is_public      BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    version        INT NOT NULL DEFAULT 1,
    CONSTRAINT uq_platform_config_key UNIQUE (key)
);

-- ══════════════════════════════════════════════════════════════════════════════
-- AUTO-TIMESTAMP TRIGGERS
-- Apply fn_set_updated_at() to every table that has an updated_at column,
-- EXCEPT audit_logs (which has its own tamper-guard trigger).
-- ══════════════════════════════════════════════════════════════════════════════
DO $$
DECLARE
    tbl TEXT;
BEGIN
    FOR tbl IN
        SELECT DISTINCT c.table_name
        FROM information_schema.columns c
        WHERE c.column_name = 'updated_at'
          AND c.table_schema = 'public'
          AND c.table_name   <> 'audit_logs'   -- handled separately
    LOOP
        EXECUTE format($fmt$
            DROP   TRIGGER IF EXISTS trg_set_updated_at ON %I;
            CREATE TRIGGER            trg_set_updated_at
                BEFORE UPDATE ON %I
                FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();
        $fmt$, tbl, tbl);
    END LOOP;
END;
$$;

-- ══════════════════════════════════════════════════════════════════════════════
-- VIEWS — pre-joined, commonly queried aggregations
-- ══════════════════════════════════════════════════════════════════════════════

-- Live stock levels with low-stock flag
CREATE OR REPLACE VIEW v_stock_levels AS
SELECT
    si.tenant_id,
    si.branch_id,
    b.name                                          AS branch_name,
    p.id                                            AS product_id,
    p.name                                          AS product_name,
    p.name_ar,
    p.sku,
    p.barcode,
    p.sale_price,
    p.cost_price,
    si.quantity,
    si.reserved_quantity,
    (si.quantity - si.reserved_quantity)            AS available_qty,
    p.low_stock_threshold,
    (si.quantity - si.reserved_quantity) <= p.low_stock_threshold  AS is_low_stock,
    si.last_cost_price,
    si.last_counted_at
FROM  stock_items si
JOIN  products p  ON p.id  = si.product_id AND NOT p.is_deleted
JOIN  branches b  ON b.id  = si.branch_id
WHERE NOT si.is_deleted;

-- Daily sales summary (Cairo timezone, VAT 14%)
CREATE OR REPLACE VIEW v_daily_sales AS
SELECT
    tenant_id,
    branch_id,
    (created_at AT TIME ZONE 'Africa/Cairo')::DATE  AS sale_date,
    COUNT(*)                                         AS total_orders,
    SUM(total_amount)                                AS total_revenue,
    SUM(vat_amount)                                  AS total_vat,
    SUM(discount_amount)                             AS total_discount,
    AVG(total_amount)                                AS avg_order_value,
    SUM(loyalty_points_earned)                       AS total_loyalty_earned
FROM  sale_orders
WHERE NOT is_deleted
  AND status NOT IN (4)          -- exclude Voided
GROUP BY tenant_id, branch_id, (created_at AT TIME ZONE 'Africa/Cairo')::DATE;

-- License health check (used by LicenseEnforcementJob and dashboard)
CREATE OR REPLACE VIEW v_license_summary AS
SELECT
    t.id                                                                AS tenant_id,
    t.name                                                              AS tenant_name,
    t.slug,
    l.plan_type,
    l.status,
    l.expires_at,
    l.sync_addon_active,
    l.max_branches,
    l.max_users,
    l.max_products,
    l.downgraded_at,
    l.downgrade_reason,
    (l.expires_at IS NOT NULL AND l.expires_at < NOW())                AS is_expired,
    CASE
        WHEN l.expires_at IS NULL THEN NULL
        WHEN l.expires_at > NOW() THEN EXTRACT(DAY FROM l.expires_at - NOW())::INT
        ELSE 0
    END                                                                 AS days_until_expiry
FROM  licenses l
JOIN  tenants  t ON t.id = l.tenant_id
WHERE NOT l.is_deleted
  AND NOT t.is_deleted;

-- ══════════════════════════════════════════════════════════════════════════════
-- SEED DATA
-- ══════════════════════════════════════════════════════════════════════════════

-- Five subscription plans (EGP pricing)
INSERT INTO plans (id, name, name_en, type, sort_order,
    monthly_price, annual_price, lifetime_price,
    max_branches, max_users, max_products,
    has_sync_engine, has_multi_branch, has_advanced_reports,
    has_restaurant_module, max_restaurant_tables, has_kds, has_qr_menu,
    has_rental_module, max_rental_assets,
    has_delivery, has_whatsapp, max_whatsapp_numbers,
    has_plugin_store, support_level)
VALUES
  ('00000000-0000-0000-0000-000000000001','التجريبية','Trial',     0,0, 0,    0,    0,    1,3,50,   TRUE, FALSE,TRUE, TRUE,10,TRUE,TRUE, TRUE,10, FALSE,FALSE,0, TRUE, 'basic'),
  ('00000000-0000-0000-0000-000000000002','الأساسية', 'Basic',     1,1, 0,    0,    0,    1,1,500,  FALSE,FALSE,FALSE,FALSE,0,FALSE,FALSE,FALSE,0, FALSE,FALSE,0, FALSE,'basic'),
  ('00000000-0000-0000-0000-000000000003','المحترفة', 'Pro',       2,2, 499,  4990, 0,    5,20,5000,TRUE, TRUE, TRUE, TRUE,30,TRUE,TRUE, TRUE,50, TRUE,TRUE,1, TRUE, 'priority'),
  ('00000000-0000-0000-0000-000000000004','الدائمة',  'Lifetime',  3,3, 0,    0,    9999, 3,15,2000,FALSE,TRUE, TRUE, TRUE,20,FALSE,TRUE,TRUE,30, TRUE,TRUE,2, TRUE, 'priority'),
  ('00000000-0000-0000-0000-000000000005','المؤسسية', 'Enterprise',4,4, 1999, 19990,0,    -1,-1,-1,TRUE, TRUE, TRUE, TRUE,-1,TRUE,TRUE, TRUE,-1, TRUE,TRUE,10,TRUE, 'dedicated')
ON CONFLICT (type) DO NOTHING;

-- Platform configuration
INSERT INTO platform_configs (key, value, description_ar, is_public)
VALUES
  ('vat_rate',          '0.14',  'نسبة ضريبة القيمة المضافة المصرية',   TRUE),
  ('currency',          'EGP',   'العملة الافتراضية',                   TRUE),
  ('currency_symbol',   'ج.م',   'رمز العملة المصرية',                  TRUE),
  ('trial_days',        '14',    'مدة فترة التجربة المجانية بالأيام',  FALSE),
  ('support_email',     'support@mesterx.com', 'بريد الدعم الفني',    TRUE),
  ('support_phone',     '01000000000', 'هاتف الدعم الفني',            TRUE)
ON CONFLICT (key) DO NOTHING;

-- ══════════════════════════════════════════════════════════════════════════════
-- VERIFICATION
-- ══════════════════════════════════════════════════════════════════════════════
DO $$
BEGIN
    RAISE NOTICE '✅ MesterX v7 Schema applied';
    RAISE NOTICE '   Tables:   %', (SELECT COUNT(*) FROM information_schema.tables   WHERE table_schema = 'public' AND table_type = 'BASE TABLE');
    RAISE NOTICE '   Views:    %', (SELECT COUNT(*) FROM information_schema.views    WHERE table_schema = 'public');
    RAISE NOTICE '   Indexes:  %', (SELECT COUNT(*) FROM pg_indexes                 WHERE schemaname   = 'public');
    RAISE NOTICE '   Triggers: %', (SELECT COUNT(*) FROM information_schema.triggers WHERE trigger_schema = 'public');
END;
$$;
