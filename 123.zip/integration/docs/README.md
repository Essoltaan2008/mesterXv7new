# ⚡ MesterX Enterprise v7

> **Production-Ready · Clean Architecture · CQRS+MediatR · Multi-Tenant · Offline-First · Tiered Licensing**
> 
> 🇪🇬 Built for the Egyptian market — VAT 14% · EGP · Arabic-first UI

---

## 🏗 Architecture

```
Request → Nginx (SSL + Rate Limit)
        → ASP.NET Core 8
        → MediatR Pipeline
           ├── ValidationBehavior (FluentValidation)
           └── LoggingBehavior (Serilog)
        → IRequestHandler (Command/Query)
        → UnitOfWork → PostgreSQL 16
        ↓
     AuditService (SHA-256 Chain — tamper-evident)
     CacheService (IMemoryCache — TTL + prefix invalidation)
     TotpService  (RFC 6238 — MFA)
```

### Clean Architecture Layers

| Layer | Project | Responsibility |
|-------|---------|----------------|
| **Domain** | MesterX.Domain | Entities, Enums, Interfaces — zero dependencies |
| **Application** | MesterX.Application | MediatR Handlers, Validators, DTOs |
| **Infrastructure** | MesterX.Infrastructure | EF Core, PostgreSQL, Services, Jobs |
| **API** | MesterX.API | Controllers (thin), Middleware, Swagger |

---

## 🚀 Quick Start (Docker)

```bash
# 1. Copy and configure environment
cp .env.example .env
# Edit .env — set DB_PASSWORD and JWT_SECRET (min 64 chars)
# Generate secret: openssl rand -hex 64

# 2. Start everything
docker compose up -d --build

# 3. Verify
curl http://localhost:5000/health/live
# → {"status":"Healthy"}

# App:    http://localhost:3000
# API:    http://localhost:5000/swagger
# Health: http://localhost:5000/health
```

---

## 🔑 Licensing Plans (بالجنيه المصري)

| Plan | Price | Branches | Users | Products | Key Features |
|------|-------|----------|-------|----------|-------------|
| **Trial** | Free 14 days | 1 | 3 | 50 | كل المميزات |
| **Basic** | Free forever | 1 | 1 | 500 | POS + Inventory |
| **Pro** | 499 ج.م/month | 5 | 20 | 5,000 | Sync + Reports + Restaurant |
| **Lifetime** | 9,999 ج.م once | 3 | 15 | 2,000 | Offline permanent |
| **Enterprise** | 1,999 ج.م/month | ∞ | ∞ | ∞ | API + White-label + AI |

Auto-downgrade runs every **30 minutes** — no manual action needed.

---

## 🔐 Security

- **BCrypt** cost 12 (~250ms) — resists brute force
- **JWT** HMAC-SHA256, 60-min expiry, 128-char secret
- **Refresh Tokens** — salted SHA-256 hash (never stored plain), 7-day rotation
- **MFA/TOTP** — RFC 6238, Google/Microsoft Authenticator compatible
- **Account Lockout** — 5 failures → 15-minute lock
- **Audit Chain** — every log entry has a SHA-256 hash linking to the previous
- **Rate Limiting** — auth: 10/min, API: 300/min
- **Tenant Isolation** — `TenantId` on every query via EF Core global filters
- **Security Headers** — HSTS, X-Frame, X-Content-Type, CSP, Referrer-Policy

---

## 🔄 Offline-First Sync

```
Client (IndexedDB/LocalStorage)          Server (PostgreSQL)
────────────────────────────────         ──────────────────
[Offline Sales]  ──── push ──────────► POST /api/sync/push
[Customers]                              Idempotency check
[Stock Adjustments]                      Conflict resolution
                                         (ServerWins/ClientWins/Manual)
                 ◄─── pull ───────────  GET /api/sync/pull?since=...
                     Delta sync          (only changed records)
```

---

## 📋 API Reference

### Auth
```
POST /api/auth/register      — New company + owner
POST /api/auth/login         — JWT + Refresh Token
POST /api/auth/refresh       — Token rotation
POST /api/auth/logout        — Revoke refresh token
GET  /api/auth/me            — Current user
POST /api/auth/change-password
POST /api/auth/mfa/setup     — Generate TOTP secret + QR
POST /api/auth/mfa/verify    — Activate MFA
POST /api/auth/mfa/disable   — Disable MFA
```

### POS
```
GET  /api/pos/products?branchId=&search=
GET  /api/pos/barcode/{barcode}?branchId=
POST /api/pos/sale
GET  /api/pos/sales?branchId=&from=&to=&page=
GET  /api/pos/sales/{id}
POST /api/pos/sales/{id}/refund
```

### Inventory
```
GET    /api/inventory/products?page=&search=&categoryId=
POST   /api/inventory/products
PUT    /api/inventory/products/{id}
DELETE /api/inventory/products/{id}
GET    /api/inventory/stock?branchId=&lowOnly=
POST   /api/inventory/stock/adjust
POST   /api/inventory/stock/transfer
```

### Dashboard & Reports
```
GET  /api/dashboard?branchId=
POST /api/dashboard/sales-report
```

### Customers
```
GET  /api/customers?search=&page=
GET  /api/customers/{id}
GET  /api/customers/by-phone/{phone}
POST /api/customers
PUT  /api/customers/{id}
POST /api/customers/{id}/loyalty
```

### Sync
```
POST /api/sync/push     — Client → Server (offline queue)
GET  /api/sync/pull     — Server → Client (delta since timestamp)
```

---

## 🧪 Running Tests

```bash
cd backend
dotnet test tests/MesterX.Tests/MesterX.Tests.csproj --logger trx
# 20+ tests: Unit (Security, TOTP, Result) + Integration (Auth, POS, Health)
```

---

## 📦 Project Structure

```
MesterX-v7/
├── backend/
│   ├── src/
│   │   ├── MesterX.Domain/          ← Entities + Enums + Interfaces
│   │   ├── MesterX.Application/     ← MediatR Handlers + Validators + DTOs
│   │   ├── MesterX.Infrastructure/  ← EF Core + Services + Jobs + Seeding
│   │   └── MesterX.API/             ← Controllers + Program.cs
│   └── tests/MesterX.Tests/         ← Unit + Integration tests
├── frontend/
│   └── src/
│       ├── app/                     ← Next.js 14 App Router pages
│       ├── components/              ← Reusable UI components
│       ├── store/                   ← Zustand state management
│       └── lib/                     ← Axios API client
├── devops/nginx/nginx.conf          ← Production reverse proxy
├── database/schema.sql              ← PostgreSQL schema reference
├── docker-compose.yml               ← Full stack orchestration
└── .env.example                     ← Environment template
```

---

## 🏢 Default Credentials (Change Before Production!)

| Role | Email | Password |
|------|-------|----------|
| Platform Owner | mahmoudtohamy44@gmail.com | Admin@MesterX2025! |
| Demo Tenant Owner | owner@demo.mesterx.com | Admin@MesterX2025! |

---

*MesterX Enterprise v7.0.0 — صُنع في مصر 🇪🇬*
