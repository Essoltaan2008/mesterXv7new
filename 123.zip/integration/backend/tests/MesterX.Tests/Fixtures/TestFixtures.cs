using Bogus;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Enums;
using MesterX.Infrastructure.Services;

namespace MesterX.Tests.Fixtures;

/// <summary>Shared test data builders using Bogus for realistic Arabic test data</summary>
public static class Fakes
{
    public static readonly Guid TenantId = Guid.Parse("aaaaaaaa-0000-0000-0000-000000000001");
    public static readonly Guid UserId   = Guid.Parse("bbbbbbbb-0000-0000-0000-000000000001");
    public static readonly Guid BranchId = Guid.Parse("cccccccc-0000-0000-0000-000000000001");

    private static readonly Faker<ApplicationUser> _userFaker = new Faker<ApplicationUser>("ar")
        .RuleFor(u => u.Id,           _ => Guid.NewGuid())
        .RuleFor(u => u.TenantId,     _ => TenantId)
        .RuleFor(u => u.BranchId,     _ => BranchId)
        .RuleFor(u => u.Username,     f => f.Internet.UserName())
        .RuleFor(u => u.Email,        f => f.Internet.Email())
        .RuleFor(u => u.PasswordHash, _ => SecurityHelper.HashPassword("Test@12345!"))
        .RuleFor(u => u.FirstName,    f => f.Name.FirstName())
        .RuleFor(u => u.LastName,     f => f.Name.LastName())
        .RuleFor(u => u.Role,         _ => UserRole.Cashier)
        .RuleFor(u => u.IsActive,     _ => true)
        .RuleFor(u => u.Language,     _ => "ar");

    private static readonly Faker<Product> _productFaker = new Faker<Product>()
        .RuleFor(p => p.Id,           _ => Guid.NewGuid())
        .RuleFor(p => p.TenantId,     _ => TenantId)
        .RuleFor(p => p.Name,         f => f.Commerce.ProductName())
        .RuleFor(p => p.SKU,          f => f.Commerce.Ean8())
        .RuleFor(p => p.Barcode,      f => f.Commerce.Ean13())
        .RuleFor(p => p.SalePrice,    f => f.Random.Decimal(5, 500))
        .RuleFor(p => p.CostPrice,    (f, p) => p.SalePrice * 0.6m)
        .RuleFor(p => p.HasVat,       _ => true)
        .RuleFor(p => p.VatRate,      _ => 0.14m)
        .RuleFor(p => p.IsActive,     _ => true)
        .RuleFor(p => p.TrackInventory, _ => true)
        .RuleFor(p => p.LowStockThreshold, _ => 5)
        .RuleFor(p => p.Type,         _ => ProductType.Physical)
        .RuleFor(p => p.Unit,         _ => ProductUnit.Piece);

    private static readonly Faker<Customer> _customerFaker = new Faker<Customer>("ar")
        .RuleFor(c => c.Id,           _ => Guid.NewGuid())
        .RuleFor(c => c.TenantId,     _ => TenantId)
        .RuleFor(c => c.Name,         f => f.Name.FullName())
        .RuleFor(c => c.Phone,        f => "01" + f.Random.Number(0, 2).ToString() + f.Random.ReplaceNumbers("#########"))
        .RuleFor(c => c.Email,        f => f.Internet.Email())
        .RuleFor(c => c.Segment,      _ => CustomerSegment.New)
        .RuleFor(c => c.IsActive,     _ => true);

    public static ApplicationUser MakeUser(Action<ApplicationUser>? configure = null)
    {
        var u = _userFaker.Generate();
        configure?.Invoke(u);
        return u;
    }

    public static Product MakeProduct(Action<Product>? configure = null)
    {
        var p = _productFaker.Generate();
        configure?.Invoke(p);
        return p;
    }

    public static Customer MakeCustomer(Action<Customer>? configure = null)
    {
        var c = _customerFaker.Generate();
        configure?.Invoke(c);
        return c;
    }

    // Pre-built known user for auth tests
    public static ApplicationUser KnownUser => MakeUser(u =>
    {
        u.Id           = UserId;
        u.TenantId     = TenantId;
        u.Username     = "test_user";
        u.Email        = "test@mesterx.com";
        u.PasswordHash = SecurityHelper.HashPassword("Test@12345!");
        u.Role         = UserRole.Cashier;
        u.IsActive     = true;
    });
}
