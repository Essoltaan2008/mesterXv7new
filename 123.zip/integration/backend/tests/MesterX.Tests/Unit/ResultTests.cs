using FluentAssertions;
using MesterX.Application.Common;
using Xunit;

namespace MesterX.Tests.Unit;

/// <summary>
/// Tests for Result<T> — our typed error-handling monad.
/// Instead of relying on exceptions for expected failures, we use Result
/// to make error paths explicit and compile-time safe.
/// </summary>
public sealed class ResultTests
{
    [Fact]
    public void Ok_IsSuccess_True_ValuePresent()
    {
        var result = Result<string>.Ok("hello");
        result.IsSuccess.Should().BeTrue();
        result.IsFailure.Should().BeFalse();
        result.Value.Should().Be("hello");
        result.Error.Should().BeNull();
    }

    [Fact]
    public void Fail_IsFailure_True_ErrorPresent()
    {
        var result = Result<string>.Fail("something went wrong", "ERR_CODE");
        result.IsFailure.Should().BeTrue();
        result.IsSuccess.Should().BeFalse();
        result.Error.Should().Be("something went wrong");
        result.ErrorCode.Should().Be("ERR_CODE");
        result.Value.Should().BeNull();
    }

    [Fact]
    public void ToResponse_Success_ProducesSuccessfulApiResponse()
    {
        var r = Result<int>.Ok(42).ToResponse("تم");
        r.Success.Should().BeTrue();
        r.Data.Should().Be(42);
        r.Message.Should().Be("تم");
    }

    [Fact]
    public void ToResponse_Failure_ProducesFailedApiResponse()
    {
        var r = Result<int>.Fail("خطأ", "FAIL_CODE").ToResponse();
        r.Success.Should().BeFalse();
        r.Message.Should().Be("خطأ");
        r.ErrorCode.Should().Be("FAIL_CODE");
        r.Data.Should().Be(default);
    }

    [Fact]
    public void PagedResult_ComputesTotalPagesCorrectly()
    {
        var paged = new PagedResult<string>(["a","b","c"], 25, 1, 10);
        paged.TotalPages.Should().Be(3);
        paged.HasNext.Should().BeTrue();
        paged.HasPrev.Should().BeFalse();
    }

    [Fact]
    public void PagedResult_LastPage_HasNextFalse()
    {
        var paged = new PagedResult<string>(["a"], 25, 3, 10);
        paged.HasNext.Should().BeFalse();
        paged.HasPrev.Should().BeTrue();
    }
}
