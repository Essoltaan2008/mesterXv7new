using FluentAssertions;
using MesterX.Infrastructure.Services;
using Xunit;

namespace MesterX.Tests.Unit;

/// <summary>
/// Tests for TotpService — RFC 6238 TOTP compatible with Google/Microsoft Authenticator.
/// This service backs our MFA feature; correctness is security-critical.
/// </summary>
public sealed class TotpServiceTests
{
    private readonly TotpService _svc = new();

    [Fact]
    public void GenerateSecret_ReturnsNonEmptySecretAndQrUrl()
    {
        var (secret, qr) = _svc.GenerateSecret("test@example.com");
        secret.Should().NotBeNullOrWhiteSpace()
            .And.MatchRegex("^[A-Z2-7]+$", "secret must be valid Base32");
        qr.Should().StartWith("otpauth://totp/")
            .And.Contain("secret=")
            .And.Contain("test%40example.com");
    }

    [Fact]
    public void GenerateSecret_TwoCalls_ProduceDifferentSecrets()
    {
        var (s1, _) = _svc.GenerateSecret("a@example.com");
        var (s2, _) = _svc.GenerateSecret("a@example.com");
        s1.Should().NotBe(s2, "each user gets a unique TOTP secret");
    }

    [Fact]
    public void ValidateCode_WrongLength_ReturnsFalse()
    {
        var (secret, _) = _svc.GenerateSecret("user@test.com");
        _svc.ValidateCode(secret, "123")  .Should().BeFalse("5-digit code is invalid");
        _svc.ValidateCode(secret, "1234567").Should().BeFalse("7-digit code is invalid");
        _svc.ValidateCode(secret, "")     .Should().BeFalse("empty code is invalid");
    }

    [Fact]
    public void ValidateCode_NonNumericCode_ReturnsFalse()
    {
        var (secret, _) = _svc.GenerateSecret("user@test.com");
        _svc.ValidateCode(secret, "abcdef").Should().BeFalse();
    }

    [Fact]
    public void GenerateBackupCode_ReturnsEightCharHexCode()
    {
        var code = _svc.GenerateBackupCode();
        code.Should().HaveLength(8)
            .And.MatchRegex("^[0-9A-F]+$", "backup code must be uppercase hex");
    }

    [Fact]
    public void GenerateBackupCode_MultipleCalls_ProduceUniqueValues()
    {
        var codes = Enumerable.Range(0, 8).Select(_ => _svc.GenerateBackupCode()).ToList();
        codes.Distinct().Should().HaveCount(8, "backup codes must all be unique");
    }
}
