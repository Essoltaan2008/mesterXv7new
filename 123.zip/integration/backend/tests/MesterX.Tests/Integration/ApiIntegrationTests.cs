using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using MesterX.Application.Common;
using MesterX.Application.Features.Auth;
using MesterX.Infrastructure.Data;
using MesterX.Infrastructure.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace MesterX.Tests.Integration;

// ════════════════════════════════════════════════════════════════════════════
// WebApplicationFactory — replaces PostgreSQL with InMemory DB for tests
// Seeds a single tenant + owner user so all endpoints have real data
// ════════════════════════════════════════════════════════════════════════════
public sealed class MesterXFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    public const string TEST_EMAIL    = "owner@test.com";
    public const string TEST_PASSWORD = "Test@12345!";
    public const string TEST_USERNAME = "test_owner";
    public static readonly Guid TEST_BRANCH_ID = Guid.Parse("dddddddd-0000-0000-0000-000000000001");
    public static readonly Guid TEST_TENANT_ID = Guid.Parse("eeeeeeee-0000-0000-0000-000000000001");
    public static readonly Guid TEST_USER_ID   = Guid.Parse("ffffffff-0000-0000-0000-000000000001");
    private const string TEST_JWT_SECRET = "test-secret-0123456789abcdefghijklmnopqrstuvwxyz-ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private readonly string _dbName = $"TestDb_{Guid.NewGuid()}";

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureAppConfiguration((_, config) =>
        {
            config.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Secret"] = TEST_JWT_SECRET,
                ["Jwt:Issuer"] = "MesterX.Tests",
                ["Jwt:Audience"] = "MesterX.Tests.Client",
                ["AllowedOrigins:0"] = "http://localhost:3000",
            });
        });

        builder.ConfigureServices(services =>
        {
            // Remove real DB context and replace with InMemory
            var descriptor = services.SingleOrDefault(
                d => d.ServiceType == typeof(DbContextOptions<MesterXDbContext>));
            if (descriptor is not null) services.Remove(descriptor);

            services.AddDbContext<MesterXDbContext>(o =>
                o.UseInMemoryDatabase(_dbName));

            // Seed test data
            var sp = services.BuildServiceProvider();
            using var scope = sp.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<MesterXDbContext>();
            db.Database.EnsureCreated();
            SeedTestData(db);
        });

        builder.UseEnvironment("Test");
    }

    private static void SeedTestData(MesterXDbContext db)
    {
        db.Tenants.Add(new Domain.Entities.Core.Tenant
        {
            Id       = TEST_TENANT_ID, TenantId = TEST_TENANT_ID,
            Name     = "Test Company", Slug = "test-company",
            Currency = "EGP", VatRate = 0.14m, IsActive = true,
            Status   = Domain.Enums.TenantStatus.Active,
            Plan     = Domain.Enums.PlanType.ProMonthly,
            ActiveModules = Domain.Enums.TenantModules.POS | Domain.Enums.TenantModules.Inventory,
        });

        db.Branches.Add(new Domain.Entities.Core.Branch
        {
            Id = TEST_BRANCH_ID, TenantId = TEST_TENANT_ID,
            Name = "Main Branch", IsMain = true, IsActive = true,
        });

        db.Users.Add(new Domain.Entities.Auth.ApplicationUser
        {
            Id           = TEST_USER_ID, TenantId = TEST_TENANT_ID, BranchId = TEST_BRANCH_ID,
            Username     = TEST_USERNAME,
            Email        = TEST_EMAIL,
            PasswordHash = SecurityHelper.HashPassword(TEST_PASSWORD),
            FirstName    = "Test", LastName = "Owner",
            Role         = Domain.Enums.UserRole.CompanyOwner,
            IsActive     = true, Language = "ar",
        });

        db.SaveChanges();
    }

    public HttpClient CreateApiClient(bool allowAutoRedirect = false)
        => CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = allowAutoRedirect });

    public void ResetAuthState()
    {
        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<MesterXDbContext>();
        var user = db.Users.First(u => u.Id == TEST_USER_ID);
        user.FailedLoginAttempts = 0;
        user.LockoutEnd = null;
        user.LastLoginAt = null;
        db.RefreshTokens.RemoveRange(db.RefreshTokens);
        db.SaveChanges();
    }

    public Task InitializeAsync() => Task.CompletedTask;
    public new Task DisposeAsync() => Task.CompletedTask;
}

// ════════════════════════════════════════════════════════════════════════════
// Auth Endpoint Integration Tests
// ════════════════════════════════════════════════════════════════════════════
public sealed class AuthEndpointTests : IClassFixture<MesterXFactory>
{
    private readonly MesterXFactory _factory;
    private readonly HttpClient _client;

    public AuthEndpointTests(MesterXFactory factory)
    {
        _factory = factory;
        _client = factory.CreateApiClient();
        _factory.ResetAuthState();
    }

    // ── Login tests ──────────────────────────────────────────────────────────

    [Fact]
    public async Task Login_ValidCredentials_Returns200WithTokens()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = MesterXFactory.TEST_PASSWORD,
        });

        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var body = await response.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        body!.Success.Should().BeTrue("valid credentials should succeed");
        body.Data!.AccessToken.Should().NotBeNullOrEmpty("JWT must be returned");
        body.Data.RefreshToken.Should().NotBeNullOrEmpty("refresh token must be returned");
        body.Data.ExpiresInSeconds.Should().BeGreaterThan(0);
        body.Data.RequiresMfa.Should().BeFalse("MFA is not enabled for this test user");
    }

    [Fact]
    public async Task Login_WrongPassword_Returns401WithMessage()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = "WrongPassword!1",
        });

        // Our auth returns 401 for failed login
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
        var body = await response.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        body!.Success.Should().BeFalse();
        // Message should not reveal *why* it failed (prevent user enumeration)
        body.Message.Should().Contain("غير صحيحة");
    }

    [Fact]
    public async Task Login_NonExistentUser_Returns401SameMessage()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            email    = "ghost@nobody.com",
            password = "Whatever@1!",
        });

        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
        var body = await response.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        // Same message as wrong password — prevents user enumeration
        body!.Message.Should().Contain("غير صحيحة");
    }

    [Fact]
    public async Task Login_EmptyPassword_Returns400ValidationError()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = "",
        });

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task GetMe_WithoutToken_Returns401()
    {
        using var client = _factory.CreateApiClient();
        var response = await client.GetAsync("/api/auth/me");
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task GetMe_WithValidToken_Returns200WithUser()
    {
        // First log in to get a token
        var loginResp = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = MesterXFactory.TEST_PASSWORD,
        });
        var loginBody = await loginResp.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        var token     = loginBody!.Data!.AccessToken;

        // Use the token for /me
        using var authedClient = _factory.CreateApiClient();
        authedClient.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var response = await authedClient.GetAsync("/api/auth/me");
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var body = await response.Content.ReadFromJsonAsync<ApiResponse<UserDto>>();
        body!.Success.Should().BeTrue();
        body.Data!.Username.Should().Be(MesterXFactory.TEST_USERNAME);
        body.Data.Email.Should().Be(MesterXFactory.TEST_EMAIL);
    }

    [Fact]
    public async Task BruteForce_After5FailedAttempts_AccountIsLocked()
    {
        // Exhaust the 5-attempt limit
        for (int i = 0; i < 5; i++)
        {
            await _client.PostAsJsonAsync("/api/auth/login", new
            {
                username = MesterXFactory.TEST_USERNAME,
                password = "WrongAttempt@1!",
            });
        }

        // The 6th attempt with correct password should still fail — account is locked
        var resp = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = MesterXFactory.TEST_PASSWORD,
        });

        var body = await resp.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        body!.Success.Should().BeFalse("account should be locked after 5 failures");
        body.Message.Should().Contain("مقفول", "locked message should be in Arabic");
    }

    // ── Token refresh tests ────────────────────────────────────────────────

    [Fact]
    public async Task RefreshToken_ValidToken_ReturnsNewTokenPair()
    {
        // Login to get initial tokens
        var loginResp = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = MesterXFactory.TEST_PASSWORD,
        });
        var loginBody    = await loginResp.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        var refreshToken = loginBody!.Data!.RefreshToken;

        // Use the refresh token
        var refreshResp = await _client.PostAsJsonAsync("/api/auth/refresh",
            new RefreshTokenRequest(refreshToken));

        refreshResp.StatusCode.Should().Be(HttpStatusCode.OK);
        var body = await refreshResp.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        body!.Success.Should().BeTrue();
        body.Data!.AccessToken.Should().NotBeNullOrEmpty();
        // The new refresh token should be different (token rotation)
        body.Data.RefreshToken.Should().NotBe(refreshToken,
            "token rotation should issue a new refresh token each time");
    }

    [Fact]
    public async Task RefreshToken_InvalidToken_Returns401()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/refresh",
            new RefreshTokenRequest("this.is.not.valid"));

        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Health Check Tests
// ════════════════════════════════════════════════════════════════════════════
public sealed class HealthCheckTests : IClassFixture<MesterXFactory>
{
    private readonly HttpClient _client;
    public HealthCheckTests(MesterXFactory factory) => _client = factory.CreateApiClient();

    [Fact]
    public async Task Health_Endpoint_Returns200()
    {
        var response = await _client.GetAsync("/health");
        // The InMemory DB will be healthy; at minimum we don't want 500
        ((int)response.StatusCode).Should().BeOneOf(new[] { 200, 503 });
    }

    [Fact]
    public async Task Health_Live_Returns200()
    {
        // The "live" probe only checks if the process is running, not DB
        var response = await _client.GetAsync("/health/live");
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// POS Endpoint Integration Tests
// ════════════════════════════════════════════════════════════════════════════
public sealed class PosEndpointTests : IClassFixture<MesterXFactory>
{
    private readonly MesterXFactory _factory;
    private readonly HttpClient _client;
    private readonly Guid       _branchId = MesterXFactory.TEST_BRANCH_ID;

    public PosEndpointTests(MesterXFactory factory)
    {
        _factory = factory;
        _client = factory.CreateApiClient();
        _factory.ResetAuthState();
    }

    private async Task<string> GetTokenAsync()
    {
        var resp = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = MesterXFactory.TEST_PASSWORD,
        });
        var body = await resp.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>();
        return body!.Data!.AccessToken;
    }

    [Fact]
    public async Task GetProducts_WithoutAuth_Returns401()
    {
        using var c = _factory.CreateApiClient();
        var response = await c.GetAsync($"/api/pos/products?branchId={_branchId}");
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task GetProducts_WithAuth_Returns200()
    {
        var token = await GetTokenAsync();
        using var c = _factory.CreateApiClient();
        c.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        // Use a valid branch ID from test data
        var response = await c.GetAsync($"/api/pos/products?branchId={_branchId}");

        // 200 even if empty — the auth check is what matters here
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task CreateSale_EmptyCart_Returns400()
    {
        var token = await GetTokenAsync();
        using var c = _factory.CreateApiClient();
        c.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var response = await c.PostAsJsonAsync("/api/pos/sale", new
        {
            branchId      = _branchId,
            paymentMethod = 0,
            items         = new object[] { },   // empty cart → validation error
            amountPaid    = 0,
        });

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest,
            "empty cart should be rejected by FluentValidation");
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Dashboard Endpoint Tests
// ════════════════════════════════════════════════════════════════════════════
public sealed class DashboardTests : IClassFixture<MesterXFactory>
{
    private readonly MesterXFactory _factory;
    private readonly HttpClient _client;
    public DashboardTests(MesterXFactory factory)
    {
        _factory = factory;
        _client = factory.CreateApiClient();
        _factory.ResetAuthState();
    }

    [Fact]
    public async Task GetDashboard_WithAuth_Returns200()
    {
        var loginResp = await _client.PostAsJsonAsync("/api/auth/login", new
        {
            username = MesterXFactory.TEST_USERNAME,
            password = MesterXFactory.TEST_PASSWORD,
        });
        var token = (await loginResp.Content.ReadFromJsonAsync<ApiResponse<AuthResponse>>())!
            .Data!.AccessToken;

        using var c = _factory.CreateApiClient();
        c.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        var response = await c.GetAsync("/api/dashboard");
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}
