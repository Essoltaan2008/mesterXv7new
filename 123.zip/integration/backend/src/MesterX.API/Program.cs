using FluentValidation;
using MediatR;
using MesterX.Application.Behaviors;
using MesterX.Application.Common;
using MesterX.Application.Services;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Data;
using MesterX.Infrastructure.Repositories;
using MesterX.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Events;
using System.Text;
using System.Text.Json;
using System.Threading.RateLimiting;
using DomainInterfaces = MesterX.Domain.Interfaces;

// ── Bootstrap Serilog ─────────────────────────────────────────────────────────
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft",                     LogEventLevel.Warning)
    .MinimumLevel.Override("Microsoft.EntityFrameworkCore", LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {SourceContext}: {Message:lj}{NewLine}{Exception}")
    .WriteTo.File("logs/mesterx-.log",
        rollingInterval: RollingInterval.Day,
        retainedFileCountLimit: 30,
        outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff} {Level:u3}] {Message:lj} {Properties}{NewLine}{Exception}")
    .CreateLogger();

try
{
    var builder = WebApplication.CreateBuilder(args);
    builder.Host.UseSerilog();
    var cfg = builder.Configuration;

    // ── Database (PostgreSQL 16 + PgBouncer-ready) ────────────────────────────
    builder.Services.AddDbContext<MesterXDbContext>(o =>
    {
        o.UseNpgsql(
            cfg.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Connection string not configured."),
            pg =>
            {
                pg.EnableRetryOnFailure(3, TimeSpan.FromSeconds(5), null);
                pg.CommandTimeout(30);
                pg.MigrationsAssembly("MesterX.Infrastructure");
                pg.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
            });
        if (builder.Environment.IsDevelopment())
            o.EnableSensitiveDataLogging().EnableDetailedErrors();
    });

    // ── In-Process Cache ──────────────────────────────────────────────────────
    builder.Services.AddMemoryCache(o => o.ExpirationScanFrequency = TimeSpan.FromMinutes(5));

    // ── HTTP Context (needed for audit, tenant provider) ──────────────────────
    builder.Services.AddHttpContextAccessor();

    // ── Infrastructure Services ───────────────────────────────────────────────
    builder.Services.AddScoped<DomainInterfaces.IUnitOfWork,      UnitOfWork>();
    builder.Services.AddScoped<DomainInterfaces.IAuditService,    AuditService>();
    builder.Services.AddScoped<DomainInterfaces.ITenantProvider,  TenantProvider>();
    builder.Services.AddSingleton<DomainInterfaces.ICacheService, MemoryCacheService>();
    builder.Services.AddSingleton<DomainInterfaces.ITotpService,  TotpService>();

    // ── MediatR (CQRS pipeline) ────────────────────────────────────────────────
    // Registers all IRequestHandler<,> in MesterX.Application
    builder.Services.AddMediatR(cfg =>
    {
        cfg.RegisterServicesFromAssembly(typeof(AuthHandler).Assembly);
        cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
    });

    // ── FluentValidation — auto-register all validators in Application ─────────
    builder.Services.AddValidatorsFromAssembly(typeof(AuthHandler).Assembly);

    // ── Background Jobs ───────────────────────────────────────────────────────
    builder.Services.AddHostedService<LicenseEnforcementJob>();

    // ── SignalR (Restaurant KDS real-time) ────────────────────────────────────
    builder.Services.AddSignalR(o =>
    {
        o.EnableDetailedErrors      = builder.Environment.IsDevelopment();
        o.MaximumReceiveMessageSize = 64 * 1024;
        o.KeepAliveInterval         = TimeSpan.FromSeconds(15);
    });

    // ── JWT Authentication ────────────────────────────────────────────────────
    var jwtSecret = cfg["Jwt:Secret"];
    if (string.IsNullOrWhiteSpace(jwtSecret) && builder.Environment.IsEnvironment("Test"))
        jwtSecret = "test-secret-0123456789abcdefghijklmnopqrstuvwxyz-ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (string.IsNullOrWhiteSpace(jwtSecret))
        throw new InvalidOperationException("Jwt:Secret is required. Set it in appsettings or env.");

    if (jwtSecret.Length < 64)
        throw new InvalidOperationException("Jwt:Secret must be >= 64 characters.");

    builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(o =>
        {
            o.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer           = true,
                ValidateAudience         = true,
                ValidateLifetime         = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer              = cfg["Jwt:Issuer"]   ?? "MesterX",
                ValidAudience            = cfg["Jwt:Audience"] ?? "MesterXClient",
                IssuerSigningKey         = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
                ClockSkew                = TimeSpan.FromSeconds(30),
                RequireExpirationTime    = true,
            };
            o.Events = new JwtBearerEvents
            {
                OnChallenge = ctx =>
                {
                    ctx.HandleResponse();
                    ctx.Response.StatusCode  = 401;
                    ctx.Response.ContentType = "application/json";
                    return ctx.Response.WriteAsJsonAsync(
                        new { success = false, message = "غير مصرح. سجّل دخولك." });
                },
                OnForbidden = ctx =>
                {
                    ctx.Response.StatusCode  = 403;
                    ctx.Response.ContentType = "application/json";
                    return ctx.Response.WriteAsJsonAsync(
                        new { success = false, message = "ليس لديك صلاحية لهذا المورد." });
                },
            };
        });

    // RBAC policies
    builder.Services.AddAuthorization(o =>
    {
        o.AddPolicy("PlatformOwner", p => p.RequireRole("PlatformOwner"));
        o.AddPolicy("Admin+",        p => p.RequireRole("PlatformOwner","SuperAdmin","CompanyOwner","TenantAdmin"));
        o.AddPolicy("Manager+",      p => p.RequireRole("PlatformOwner","SuperAdmin","CompanyOwner","TenantAdmin","Manager"));
    });

    // ── Rate Limiting ─────────────────────────────────────────────────────────
    builder.Services.AddRateLimiter(o =>
    {
        // Auth endpoints: strict (brute-force protection)
        o.AddFixedWindowLimiter("auth", lim => { lim.PermitLimit = 10; lim.Window = TimeSpan.FromMinutes(1); lim.QueueLimit = 0; });
        // General API
        o.AddFixedWindowLimiter("api",  lim => { lim.PermitLimit = 300; lim.Window = TimeSpan.FromMinutes(1); lim.QueueLimit = 5; });
        o.RejectionStatusCode = 429;
        o.OnRejected = async (ctx, ct) =>
        {
            ctx.HttpContext.Response.StatusCode  = 429;
            ctx.HttpContext.Response.ContentType = "application/json";
            await ctx.HttpContext.Response.WriteAsJsonAsync(
                new { success = false, message = "تجاوزت الحد الأقصى للطلبات. انتظر دقيقة." }, ct);
        };
    });

    // ── CORS ──────────────────────────────────────────────────────────────────
    var origins = cfg.GetSection("AllowedOrigins").Get<string[]>() ?? ["http://localhost:3000"];
    builder.Services.AddCors(o => o.AddPolicy("MesterXCors", p =>
        p.WithOrigins(origins).AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

    // ── Controllers + JSON ────────────────────────────────────────────────────
    builder.Services.AddControllers()
        .AddJsonOptions(o =>
        {
            o.JsonSerializerOptions.PropertyNamingPolicy   = JsonNamingPolicy.CamelCase;
            o.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
            o.JsonSerializerOptions.WriteIndented          = builder.Environment.IsDevelopment();
        });

    // ── Swagger / OpenAPI ─────────────────────────────────────────────────────
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v7", new OpenApiInfo
        {
            Title       = "MesterX Enterprise v7 API",
            Version     = "7.0",
            Description = "🇪🇬 Hybrid Offline-First · Multi-Tenant · CQRS · JWT+MFA · POS · Restaurant · Rental",
        });
        c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT",
            In   = ParameterLocation.Header, Description = "Enter JWT token",
        });
        c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {{
            new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } },
            []
        }});
    });

    // ── Health Checks ─────────────────────────────────────────────────────────
    var healthChecks = builder.Services.AddHealthChecks()
        .AddCheck("self", () => HealthCheckResult.Healthy("Running"), ["live"]);
    var defaultConnection = cfg.GetConnectionString("DefaultConnection");
    if (!string.IsNullOrWhiteSpace(defaultConnection) && !builder.Environment.IsEnvironment("Test"))
    {
        healthChecks.AddNpgSql(defaultConnection, name: "db", tags: ["ready"]);
    }
    else
    {
        healthChecks.AddCheck("db", () => HealthCheckResult.Healthy("Test DB"), ["ready"]);
    }

    // ── Response Compression ──────────────────────────────────────────────────
    builder.Services.AddResponseCompression(o => { o.EnableForHttps = true; });

    // ═════════════════════════════════════════════════════════════════════════
    // BUILD
    // ═════════════════════════════════════════════════════════════════════════
    var app = builder.Build();

    // ── Migrate + Seed ─────────────────────────────────────────────────────────
    using (var scope = app.Services.CreateScope())
    {
        var db = scope.ServiceProvider.GetRequiredService<MesterXDbContext>();
        try
        {
            if (db.Database.IsRelational())
            {
                await db.Database.MigrateAsync();
                Log.Information("✅ Migrations applied");
            }
            else
            {
                await db.Database.EnsureCreatedAsync();
                Log.Information("✅ Test database created");
            }
            if (!await db.Tenants.AnyAsync())
            {
                await MesterX.Infrastructure.Seeding.DatabaseSeeder.SeedAsync(db);
                Log.Information("✅ Seed data applied");
            }
        }
        catch (Exception ex) { Log.Error(ex, "❌ DB startup failed"); }
    }

    // ── Middleware pipeline ────────────────────────────────────────────────────
    app.UseResponseCompression();

    app.UseSerilogRequestLogging(o =>
    {
        o.MessageTemplate = "HTTP {RequestMethod} {RequestPath} → {StatusCode} ({Elapsed:0.0}ms)";
        o.GetLevel = (ctx, _, ex) =>
            ex != null || ctx.Response.StatusCode >= 500 ? LogEventLevel.Error
            : ctx.Response.StatusCode >= 400 ? LogEventLevel.Warning
            : LogEventLevel.Information;
    });

    // Security headers on every response
    app.Use(async (ctx, next) =>
    {
        var h = ctx.Response.Headers;
        h["X-Content-Type-Options"]  = "nosniff";
        h["X-Frame-Options"]         = "DENY";
        h["X-XSS-Protection"]        = "1; mode=block";
        h["Referrer-Policy"]         = "strict-origin-when-cross-origin";
        h["Permissions-Policy"]      = "geolocation=(), microphone=(), camera=()";
        if (!app.Environment.IsDevelopment())
            h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains";
        await next();
    });

    // Global exception handler — structured JSON response, never leaks stack trace
    app.UseExceptionHandler(err => err.Run(async ctx =>
    {
        ctx.Response.StatusCode  = 500;
        ctx.Response.ContentType = "application/json";
        var feature = ctx.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>();
        Log.Error(feature?.Error, "Unhandled exception {Path}", ctx.Request.Path);
        await ctx.Response.WriteAsJsonAsync(new
        {
            success = false,
            message = "خطأ داخلي. يرجى المحاولة مرة أخرى أو التواصل مع الدعم.",
            traceId = ctx.TraceIdentifier,
        });
    }));

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v7/swagger.json", "MesterX v7"); c.RoutePrefix = "swagger"; });
    }
    else { app.UseHsts(); }

    if (!app.Environment.IsEnvironment("Test"))
        app.UseHttpsRedirection();
    app.UseCors("MesterXCors");
    app.UseRateLimiter();
    app.UseAuthentication();
    app.UseAuthorization();

    app.MapControllers().RequireRateLimiting("api");
    app.MapHealthChecks("/health");
    app.MapHealthChecks("/health/live",  new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions { Predicate = c => c.Tags.Contains("live") });
    app.MapHealthChecks("/health/ready", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions { Predicate = c => c.Tags.Contains("ready") });

    Log.Information("🚀 MesterX v7 — {Env} — ready", app.Environment.EnvironmentName);
    await app.RunAsync();
}
catch (Exception ex) when (ex is not HostAbortedException)
{
    Log.Fatal(ex, "💀 MesterX v7 failed to start");
    Environment.Exit(1);
}
finally { Log.CloseAndFlush(); }

public partial class Program { } // allows WebApplicationFactory in tests
