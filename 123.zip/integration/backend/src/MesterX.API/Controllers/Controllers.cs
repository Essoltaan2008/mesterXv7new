using FluentValidation;
using MediatR;
using MesterX.Application.Common;
using MesterX.Application.Features.Auth;
using MesterX.Application.Features.Customers;
using MesterX.Application.Features.Dashboard;
using MesterX.Application.Features.Inventory;
using MesterX.Application.Features.License;
using MesterX.Application.Features.Pos;
using MesterX.Application.Features.Sync;
using DomainInterfaces = MesterX.Domain.Interfaces;
using MesterX.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace MesterX.API.Controllers;

// ════════════════════════════════════════════════════════════════════════════
// BaseController — shared infrastructure for all controllers
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Produces("application/json")]
public abstract class BaseController : ControllerBase
{
    private IMediator? _mediator;

    // Lazy-resolve from DI so we don't pollute every constructor
    protected IMediator Mediator =>
        _mediator ??= HttpContext.RequestServices.GetRequiredService<IMediator>();

    protected string IpAddress =>
        HttpContext.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "0.0.0.0";

    protected string UserAgent
    {
        get
        {
            var ua = Request.Headers.UserAgent.ToString();
            return ua.Length > 250 ? ua[..250] : ua;
        }
    }

    protected DomainInterfaces.ITenantProvider Tenant =>
        HttpContext.RequestServices.GetRequiredService<DomainInterfaces.ITenantProvider>();

    // Converts a Result<T> into the appropriate HTTP response — all controllers
    // use this helper so error code mapping stays consistent.
    protected IActionResult FromResult<T>(Result<T> result)
    {
        if (result.IsSuccess) return Ok(result.ToResponse());
        return result.ErrorCode switch
        {
            "NOT_FOUND"    => NotFound(result.ToResponse()),
            "UNAUTHORIZED" => Unauthorized(result.ToResponse()),
            "DUPLICATE_*"  => Conflict(result.ToResponse()),
            _              => BadRequest(result.ToResponse()),
        };
    }

    // Handles FluentValidation exceptions thrown from the MediatR pipeline
    protected IActionResult HandleValidationException(ValidationException ex)
    {
        var errors = ex.Errors
            .GroupBy(e => e.PropertyName)
            .ToDictionary(g => g.Key, g => g.Select(e => e.ErrorMessage).ToArray());
        return BadRequest(ApiResponse<object>.Fail("خطأ في البيانات المُدخَلة",
            "VALIDATION_ERROR", errors));
    }
}

// ════════════════════════════════════════════════════════════════════════════
// AUTH CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/auth")]
public class AuthController : BaseController
{
    [HttpPost("register")]
    [AllowAnonymous]
    [EnableRateLimiting("auth")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req, CancellationToken ct)
    {
        try
        {
            var result = await Mediator.Send(new RegisterCommand(req), ct);
            return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    [HttpPost("login")]
    [AllowAnonymous]
    [EnableRateLimiting("auth")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req, CancellationToken ct)
    {
        try
        {
            var result = await Mediator.Send(new LoginCommand(req, IpAddress, UserAgent), ct);
            return result.IsSuccess ? Ok(result.ToResponse()) : Unauthorized(result.ToResponse());
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    [EnableRateLimiting("auth")]
    public async Task<IActionResult> Refresh([FromBody] RefreshTokenRequest req, CancellationToken ct)
    {
        var result = await Mediator.Send(new RefreshTokenCommand(req.RefreshToken, IpAddress), ct);
        return result.IsSuccess ? Ok(result.ToResponse()) : Unauthorized(result.ToResponse());
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout([FromBody] RefreshTokenRequest req, CancellationToken ct)
    {
        // Fire-and-forget style — we always return 200 to prevent token probing
        _ = Mediator.Send(new LogoutCommand(req.RefreshToken, Tenant.CurrentUserId, Tenant.TenantId), ct);
        return Ok(ApiResponse.Ok("تم تسجيل الخروج"));
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> Me(CancellationToken ct)
    {
        var uid = Tenant.CurrentUserId; var tid = Tenant.TenantId;
        if (uid is null || tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetCurrentUserQuery(uid.Value, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req, CancellationToken ct)
    {
        var uid = Tenant.CurrentUserId; var tid = Tenant.TenantId;
        if (uid is null || tid is null) return Unauthorized();
        try
        {
            var result = await Mediator.Send(new ChangePasswordCommand(req, uid.Value, tid.Value), ct);
            return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    // ── MFA endpoints ──────────────────────────────────────────────────────

    [HttpPost("mfa/setup")]
    [Authorize]
    public async Task<IActionResult> MfaSetup(CancellationToken ct)
    {
        var uid = Tenant.CurrentUserId; var tid = Tenant.TenantId;
        if (uid is null || tid is null) return Unauthorized();
        var result = await Mediator.Send(new SetupMfaCommand(uid.Value, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("mfa/verify")]
    [Authorize]
    public async Task<IActionResult> MfaVerify([FromBody] MfaVerifyRequest req, CancellationToken ct)
    {
        var uid = Tenant.CurrentUserId; var tid = Tenant.TenantId;
        if (uid is null || tid is null) return Unauthorized();
        var result = await Mediator.Send(new VerifyMfaCommand(req.Code, uid.Value, tid.Value), ct);
        return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
    }

    [HttpPost("mfa/disable")]
    [Authorize]
    public async Task<IActionResult> MfaDisable([FromBody] MfaVerifyRequest req, CancellationToken ct)
    {
        var uid = Tenant.CurrentUserId; var tid = Tenant.TenantId;
        if (uid is null || tid is null) return Unauthorized();
        var result = await Mediator.Send(new VerifyMfaCommand(req.Code, uid.Value, tid.Value, Disable: true), ct);
        return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
    }
}

// ════════════════════════════════════════════════════════════════════════════
// POS CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/pos")]
[Authorize]
public class PosController : BaseController
{
    [HttpGet("products")]
    public async Task<IActionResult> Products(
        [FromQuery] Guid branchId, [FromQuery] string? search, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetPosProductsQuery(branchId, search, tid.Value), ct);
        return FromResult(result);
    }

    [HttpGet("barcode/{barcode}")]
    public async Task<IActionResult> ByBarcode(
        string barcode, [FromQuery] Guid branchId, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetByBarcodeQuery(barcode, branchId, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("sale")]
    public async Task<IActionResult> Sale([FromBody] CreateSaleRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        try
        {
            var result = await Mediator.Send(new CreateSaleCommand(req, tid.Value, uid.Value), ct);
            return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    [HttpGet("sales")]
    public async Task<IActionResult> Sales(
        [FromQuery] Guid branchId, [FromQuery] DateTime? from, [FromQuery] DateTime? to,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken ct = default)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetSalesQuery(tid.Value, branchId, from, to, page, pageSize), ct);
        return FromResult(result);
    }

    [HttpGet("sales/{id:guid}")]
    public async Task<IActionResult> SaleById(Guid id, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetSaleByIdQuery(id, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("sales/{id:guid}/refund")]
    public async Task<IActionResult> Refund(
        Guid id, [FromBody] RefundRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new RefundSaleCommand(id, req, tid.Value, uid.Value), ct);
        return FromResult(result);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// INVENTORY CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/inventory")]
[Authorize]
public class InventoryController : BaseController
{
    [HttpGet("products")]
    public async Task<IActionResult> Products(
        [FromQuery] int page = 1, [FromQuery] int pageSize = 20,
        [FromQuery] string? search = null, [FromQuery] Guid? categoryId = null,
        CancellationToken ct = default)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetProductsQuery(tid.Value, page, pageSize, search, categoryId), ct);
        return FromResult(result);
    }

    [HttpGet("products/{id:guid}")]
    public async Task<IActionResult> Product(Guid id, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetProductQuery(id, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("products")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> Create([FromBody] CreateProductRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        try
        {
            var result = await Mediator.Send(new CreateProductCommand(req, tid.Value, uid.Value), ct);
            return result.IsSuccess
                ? CreatedAtAction(nameof(Product), new { id = result.Value?.Id }, result.ToResponse())
                : BadRequest(result.ToResponse());
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    [HttpPut("products/{id:guid}")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> Update(
        Guid id, [FromBody] UpdateProductRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new UpdateProductCommand(id, req, tid.Value, uid.Value), ct);
        return FromResult(result);
    }

    [HttpDelete("products/{id:guid}")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new DeleteProductCommand(id, tid.Value, uid.Value), ct);
        return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
    }

    [HttpGet("stock")]
    public async Task<IActionResult> Stock(
        [FromQuery] Guid? branchId, [FromQuery] bool lowOnly = false, CancellationToken ct = default)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetStockQuery(tid.Value, branchId, lowOnly), ct);
        return FromResult(result);
    }

    [HttpPost("stock/adjust")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> Adjust([FromBody] StockAdjustRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        try
        {
            var result = await Mediator.Send(new AdjustStockCommand(req, tid.Value, uid.Value), ct);
            return FromResult(result);
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    [HttpPost("stock/transfer")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> Transfer([FromBody] StockTransferRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new TransferStockCommand(req, tid.Value, uid.Value), ct);
        return FromResult(result);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// CUSTOMER CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/customers")]
[Authorize]
public class CustomerController : BaseController
{
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] string? search, [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20, CancellationToken ct = default)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetCustomersQuery(tid.Value, search, page, pageSize), ct);
        return FromResult(result);
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetCustomerQuery(id, tid.Value), ct);
        return FromResult(result);
    }

    [HttpGet("by-phone/{phone}")]
    public async Task<IActionResult> ByPhone(string phone, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new FindByPhoneQuery(phone, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateCustomerRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        try
        {
            var result = await Mediator.Send(new CreateCustomerCommand(req, tid.Value, uid.Value), ct);
            return result.IsSuccess
                ? CreatedAtAction(nameof(Get), new { id = result.Value?.Id }, result.ToResponse())
                : BadRequest(result.ToResponse());
        }
        catch (ValidationException ex) { return HandleValidationException(ex); }
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(
        Guid id, [FromBody] UpdateCustomerRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new UpdateCustomerCommand(id, req, tid.Value, uid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("{id:guid}/loyalty")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> Loyalty(
        Guid id, [FromBody] AddLoyaltyPointsRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new AddLoyaltyCommand(id, req, tid.Value, uid.Value), ct);
        return result.IsSuccess ? Ok(result.ToResponse()) : BadRequest(result.ToResponse());
    }
}

// ════════════════════════════════════════════════════════════════════════════
// DASHBOARD CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/dashboard")]
[Authorize]
public class DashboardController : BaseController
{
    [HttpGet]
    public async Task<IActionResult> Stats([FromQuery] Guid? branchId, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetDashboardQuery(tid.Value, branchId), ct);
        return FromResult(result);
    }

    [HttpPost("sales-report")]
    [Authorize(Policy = "Manager+")]
    public async Task<IActionResult> SalesReport([FromBody] SalesReportRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetSalesReportQuery(req, tid.Value), ct);
        return FromResult(result);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// SYNC CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/sync")]
[Authorize]
public class SyncController : BaseController
{
    [HttpPost("push")]
    public async Task<IActionResult> Push([FromBody] SyncPushRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; var uid = Tenant.CurrentUserId;
        if (tid is null || uid is null) return Unauthorized();
        var result = await Mediator.Send(new PushSyncCommand(req, tid.Value, uid.Value), ct);
        return FromResult(result);
    }

    [HttpGet("pull")]
    public async Task<IActionResult> Pull(
        [FromQuery] Guid branchId, [FromQuery] DateTime? since, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(
            new PullSyncQuery(tid.Value, branchId, since ?? DateTime.UtcNow.AddDays(-7)), ct);
        return FromResult(result);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// LICENSE CONTROLLER
// ════════════════════════════════════════════════════════════════════════════
[Route("api/license")]
[Authorize]
public class LicenseController : BaseController
{
    [HttpGet("status")]
    public async Task<IActionResult> Status(CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new GetLicenseStatusQuery(tid.Value), ct);
        return FromResult(result);
    }

    [HttpGet("plans")]
    [AllowAnonymous]
    public async Task<IActionResult> Plans(CancellationToken ct)
    {
        var result = await Mediator.Send(new GetPlansQuery(), ct);
        return FromResult(result);
    }

    [HttpPost("activate")]
    public async Task<IActionResult> Activate([FromBody] ActivateLicenseRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new ActivateLicenseCommand(req, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("activate-sync")]
    public async Task<IActionResult> ActivateSync([FromBody] ActivateSyncAddonRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new ActivateSyncCommand(req, tid.Value), ct);
        return FromResult(result);
    }

    [HttpPost("validate-device")]
    public async Task<IActionResult> ValidateDevice([FromBody] ValidateDeviceRequest req, CancellationToken ct)
    {
        var tid = Tenant.TenantId; if (tid is null) return Unauthorized();
        var result = await Mediator.Send(new ValidateDeviceCommand(req, tid.Value), ct);
        return FromResult(result);
    }
}
