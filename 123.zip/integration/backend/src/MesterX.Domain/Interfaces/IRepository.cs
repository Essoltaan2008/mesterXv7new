using System.Linq.Expressions;
using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Billing;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Entities.Sync;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Interfaces;

// ── Generic Repository ───────────────────────────────────────────────────────
public interface IRepository<T> where T : class
{
    IQueryable<T>                        Query();
    Task<T?>                             GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<T?>                             FirstOrDefaultAsync(Expression<Func<T,bool>> p, CancellationToken ct = default);
    Task<IEnumerable<T>>                 FindAsync(Expression<Func<T,bool>> p, CancellationToken ct = default);
    Task<bool>                           AnyAsync(Expression<Func<T,bool>> p, CancellationToken ct = default);
    Task<int>                            CountAsync(Expression<Func<T,bool>> p, CancellationToken ct = default);
    Task                                 AddAsync(T entity, CancellationToken ct = default);
    Task                                 AddRangeAsync(IEnumerable<T> entities, CancellationToken ct = default);
    void                                 Update(T entity);
    void                                 SoftDelete(T entity, Guid deletedBy);
    void                                 Remove(T entity);
}

// ── Unit of Work ─────────────────────────────────────────────────────────────
public interface IUnitOfWork : IDisposable, IAsyncDisposable
{
    // Auth
    IRepository<ApplicationUser>         Users                { get; }
    IRepository<ApplicationRole>         Roles                { get; }
    IRepository<ApplicationPermission>   Permissions          { get; }
    IRepository<RefreshToken>            RefreshTokens        { get; }
    IRepository<FeatureFlag>             FeatureFlags         { get; }

    // Core
    IRepository<Tenant>                  Tenants              { get; }
    IRepository<Branch>                  Branches             { get; }
    IRepository<Category>                Categories           { get; }
    IRepository<Customer>                Customers            { get; }
    IRepository<Supplier>                Suppliers            { get; }
    IRepository<Expense>                 Expenses             { get; }

    // Billing
    IRepository<Plan>                    Plans                { get; }
    IRepository<Subscription>            Subscriptions        { get; }
    IRepository<License>                 Licenses             { get; }
    IRepository<DeviceRegistration>      DeviceRegistrations  { get; }
    IRepository<Plugin>                  Plugins              { get; }
    IRepository<PluginInstallation>      PluginInstallations  { get; }

    // POS
    IRepository<Product>                 Products             { get; }
    IRepository<StockItem>               StockItems           { get; }
    IRepository<StockMovement>           StockMovements       { get; }
    IRepository<SaleOrder>               SaleOrders           { get; }
    IRepository<SaleOrderItem>           SaleOrderItems       { get; }
    IRepository<Payment>                 Payments             { get; }
    IRepository<SaleRefund>              SaleRefunds          { get; }
    IRepository<PurchaseOrder>           PurchaseOrders       { get; }
    IRepository<PurchaseOrderItem>       PurchaseOrderItems   { get; }

    // Sync & Audit
    IRepository<SyncQueue>               SyncQueue            { get; }
    IRepository<SyncLog>                 SyncLogs             { get; }
    IRepository<AuditLog>                AuditLogs            { get; }
    IRepository<PlatformConfig>          PlatformConfigs      { get; }

    // Transactions
    Task<int>  SaveChangesAsync(CancellationToken ct = default);
    Task       BeginTransactionAsync(CancellationToken ct = default);
    Task       CommitTransactionAsync(CancellationToken ct = default);
    Task       RollbackTransactionAsync(CancellationToken ct = default);
}

// ── Supporting Interfaces ─────────────────────────────────────────────────────
public interface ICurrentUserService
{
    Guid?   UserId         { get; }
    Guid?   TenantId       { get; }
    string? Email          { get; }
    UserRole? Role         { get; }
    bool    IsAuthenticated{ get; }
    bool    IsInRole(UserRole role);
    bool    IsAtLeast(UserRole minimum);
}

public interface IDateTimeService
{
    DateTime UtcNow    { get; }
    DateTime CairoNow  { get; }
    DateOnly Today     { get; }
}

// Audit entry record for type-safe audit logging
public sealed record AuditEntry(
    Guid        TenantId,
    Guid?       UserId,
    AuditAction Action,
    string      EntityType,
    Guid?       EntityId     = null,
    object?     OldValues    = null,
    object?     NewValues    = null,
    bool        IsSuccess    = true,
    string?     ErrorMessage = null
);

public interface IAuditService
{
    Task LogAsync(AuditEntry entry, CancellationToken ct = default);
}

public interface ITenantProvider
{
    Guid?  TenantId       { get; }
    Guid?  CurrentUserId  { get; }
    UserRole? CurrentRole { get; }
}

public interface IFeatureFlagService
{
    Task<bool> IsEnabledAsync(string feature, Guid tenantId, CancellationToken ct = default);
    Task EnsureEnabledAsync(string feature);
}

public interface ICacheService
{
    Task<T?>  GetAsync<T>(string key, CancellationToken ct = default) where T : class;
    Task      SetAsync<T>(string key, T value, TimeSpan? ttl = null, CancellationToken ct = default);
    Task      RemoveAsync(string key, CancellationToken ct = default);
    Task      RemovePrefixAsync(string prefix, CancellationToken ct = default);
}

public interface ITotpService
{
    (string Secret, string QrCodeUrl) GenerateSecret(string email, string issuer = "MesterX");
    bool   ValidateCode(string secret, string code, int toleranceSteps = 1);
    string GenerateBackupCode();
}

public static class CacheKeys
{
    public static string Plans                  => "mx:plans:all";
    public static string PlatformConfig         => "mx:platform:config";
    public static string TenantLicense(Guid t)  => $"mx:license:{t}";
    public static string TenantFeatures(Guid t) => $"mx:features:{t}";
    public static string ProductsByBranch(Guid b)=> $"mx:products:branch:{b}";
    public static string DashboardStats(Guid t, DateOnly d) => $"mx:dash:{t}:{d:yyyyMMdd}";
}
