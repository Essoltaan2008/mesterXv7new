namespace MesterX.Domain.Enums;

// ─── Identity & Access ───────────────────────────────────────────────────────
public enum UserRole : short
{
    PlatformOwner = 0, SuperAdmin = 1, CompanyOwner = 2,
    TenantAdmin = 3, Manager = 4, Cashier = 5, Viewer = 6
}

// ─── Tenant ───────────────────────────────────────────────────────────────────
public enum TenantStatus    : short { Trial=0, Active=1, Suspended=2, Cancelled=3 }
public enum BusinessType    : short { Restaurant=0, Supermarket=1, RetailStore=2, Pharmacy=3, Services=4, RentalEvents=5, Café=6, Bakery=7, Electronics=8, Clothing=9, Other=99 }
[Flags]
public enum TenantModules   : int   { None=0, POS=1, Inventory=2, Restaurant=4, Delivery=8, Rental=16, Marketplace=32, CRM=64, Accounting=128, WhatsApp=256, AI=512 }

// ─── Billing ───────────────────────────────────────────────────────────────────
public enum PlanType           : short { Trial=0, Basic=1, ProMonthly=2, Lifetime=3, Enterprise=4 }
public enum BillingCycle       : short { Monthly=0, Annual=1, Once=2 }
public enum SubscriptionStatus : short { Trial=0, Active=1, PastDue=2, Cancelled=3, Paused=4 }
public enum LicenseStatus      : short { Active=0, Expired=1, Suspended=2, Downgraded=3, Revoked=4 }

// ─── Product ───────────────────────────────────────────────────────────────────
public enum ProductType : short { Physical=0, Service=1, Digital=2, Composite=3 }
public enum ProductUnit : short { Piece=0, Kg=1, Gram=2, Liter=3, Ml=4, Meter=5, Box=6, Dozen=7 }

// ─── Stock ────────────────────────────────────────────────────────────────────
public enum StockMovementType : short { Purchase=0, Sale=1, Adjustment=2, Return=3, Transfer=4, PhysicalCount=5, Waste=6, Opening=7 }

// ─── Sales ────────────────────────────────────────────────────────────────────
public enum SaleStatus   : short { Pending=0, Completed=1, PartialRefund=2, Refunded=3, Voided=4, OnHold=5 }
public enum PaymentMethod: short { Cash=0, Card=1, Wallet=2, BankTransfer=3, Mixed=4, Credit=5, Fawry=6, InstaPay=7 }
public enum DiscountType : short { Amount=0, Percentage=1 }

// ─── Customer ─────────────────────────────────────────────────────────────────
public enum CustomerSegment : short { New=0, Regular=1, VIP=2, Inactive=3, Blocked=4 }
public enum Gender          : short { Unknown=0, Male=1, Female=2 }

// ─── Supplier & Purchasing ────────────────────────────────────────────────────
public enum SupplierStatus      : short { Active=0, Inactive=1, Blacklisted=2 }
public enum PurchaseOrderStatus : short { Draft=0, Sent=1, Received=2, PartiallyReceived=3, Cancelled=4, Overdue=5 }

// ─── Expense ──────────────────────────────────────────────────────────────────
public enum ExpenseCategory : short { Rent=0, Salaries=1, Utilities=2, Marketing=3, Supplies=4, Maintenance=5, Delivery=6, Insurance=7, Taxes=8, Other=99 }

// ─── Order (Delivery/Online) ──────────────────────────────────────────────────
public enum OrderStatus  : short { Pending=0, Confirmed=1, Preparing=2, ReadyForPickup=3, OutForDelivery=4, Delivered=5, Cancelled=6, Refunded=7 }
public enum DeliveryStatus:short { Pending=0, AssignedToDriver=1, PickedUp=2, InTransit=3, Delivered=4, FailedDelivery=5, Returned=6 }

// ─── Sync ─────────────────────────────────────────────────────────────────────
public enum SyncEntityType  : short { SaleOrder=0, Customer=1, Product=2, StockAdjustment=3, StockMovement=4, Payment=5, Expense=6 }
public enum SyncStatus      : short { Pending=0, Processing=1, Completed=2, Conflict=3, Failed=4 }
public enum SyncOperation   : short { Insert=0, Update=1, Delete=2 }
public enum ConflictStrategy: short { ServerWins=0, ClientWins=1, LatestWins=2, Manual=3 }

// ─── Audit ────────────────────────────────────────────────────────────────────
public enum AuditAction : short
{
    Create=0, Update=1, Delete=2, Read=3,
    Login=4, Logout=5, LoginFailed=6, PasswordChange=7,
    MfaEnabled=8, MfaDisabled=9,
    LicenseActivate=10, LicenseDowngrade=11, LicenseSuspend=12,
    SyncPush=13, SyncPull=14,
    Export=15, BackupCreated=16,
    TenantSuspend=17, TenantActivate=18,
    StockAdjust=19, Refund=20
}

// ─── Plugins ──────────────────────────────────────────────────────────────────
public enum PluginCategory : short { Booking=0, Loyalty=1, Accounting=2, CRM=3, Marketing=4, Analytics=5, Delivery=6, Payment=7, Other=99 }

// ─── Payments ─────────────────────────────────────────────────────────────────
public enum PaymentStatus: short { Pending=0, Processing=1, Completed=2, Failed=3, Refunded=4 }

// ─── Restaurant ───────────────────────────────────────────────────────────────
public enum TableStatus  : short { Available=0, Occupied=1, Reserved=2, Cleaning=3, OutOfService=4 }
public enum OrderType    : short { DineIn=0, Takeaway=1, Delivery=2 }
public enum KitchenStatus: short { Received=0, Preparing=1, Ready=2, Served=3, Cancelled=4 }

// ─── Rental ───────────────────────────────────────────────────────────────────
public enum AssetStatus      : short { Available=0, Rented=1, UnderMaintenance=2, Retired=3 }
public enum RentalBookingStatus:short { Pending=0, Confirmed=1, Active=2, Completed=3, Cancelled=4, Overdue=5 }
