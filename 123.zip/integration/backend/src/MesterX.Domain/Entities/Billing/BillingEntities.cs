using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Billing;

public class Plan : Base.BaseEntity
{
    public required string Name            { get; set; }
    public required string NameEn          { get; set; }
    public string?  Description            { get; set; }
    public PlanType Type                   { get; set; }
    public bool     IsActive               { get; set; } = true;
    public int      SortOrder              { get; set; }
    public decimal  MonthlyPrice           { get; set; }
    public decimal  AnnualPrice            { get; set; }
    public decimal  LifetimePrice          { get; set; }
    public decimal  SetupFee               { get; set; }
    public int      MaxBranches            { get; set; } = 1;   // -1 = unlimited
    public int      MaxUsers               { get; set; } = 1;
    public int      MaxProducts            { get; set; } = 500;
    public int      MaxCustomers           { get; set; } = -1;
    public int      DataRetentionDays      { get; set; } = 365;
    public bool     HasPOS                 { get; set; } = true;
    public bool     HasInventory           { get; set; } = true;
    public bool     HasSyncEngine          { get; set; }
    public bool     HasMultiBranch         { get; set; }
    public bool     HasAdvancedReports     { get; set; }
    public bool     HasApiAccess           { get; set; }
    public bool     HasWhiteLabel          { get; set; }
    public bool     HasAi                  { get; set; }
    public bool     HasPluginStore         { get; set; }
    public bool     HasMarketplace         { get; set; }
    public bool     HasDelivery            { get; set; }
    public bool     HasWhatsApp            { get; set; }
    public int      MaxWhatsAppNumbers     { get; set; }
    public bool     HasRestaurantModule    { get; set; }
    public int      MaxRestaurantTables    { get; set; }
    public bool     HasKDS                 { get; set; }
    public bool     HasQRMenu              { get; set; }
    public bool     HasTableReservations   { get; set; }
    public bool     HasRestaurantAnalytics { get; set; }
    public bool     HasRentalModule        { get; set; }
    public int      MaxRentalAssets        { get; set; }
    public bool     HasRentalMarketplace   { get; set; }
    public string?  SupportLevel           { get; set; } = "basic";
    public int      UptimeSlaPercent       { get; set; } = 99;

    public virtual ICollection<Subscription> Subscriptions { get; set; } = [];
}

public class Subscription : Base.BaseEntity
{
    public Guid PlanId                     { get; set; }
    public SubscriptionStatus Status       { get; set; }
    public BillingCycle BillingCycle       { get; set; }
    public decimal Amount                  { get; set; }
    public decimal DiscountAmount          { get; set; }
    public DateTime StartDate              { get; set; }
    public DateTime EndDate                { get; set; }
    public DateTime? TrialEndsAt           { get; set; }
    public DateTime? CancelledAt           { get; set; }
    public string?  CancelReason           { get; set; }
    public bool     AutoRenew              { get; set; } = true;
    public DateTime? NextBillingDate       { get; set; }
    public string?  PaymentGateway         { get; set; }
    public string?  ExternalSubscriptionId { get; set; }
    public string?  LastPaymentRef         { get; set; }
    public DateTime? LastPaymentAt         { get; set; }
    public int      FailedPaymentAttempts  { get; set; }
    public bool     SyncAddonActive        { get; set; }
    public DateTime? SyncAddonExpiresAt    { get; set; }

    public virtual Tenant? Tenant          { get; set; }
    public virtual Plan?   Plan            { get; set; }
}

public class License : Base.BaseEntity
{
    public required string LicenseKeyHash  { get; set; }   // SHA-512
    public PlanType PlanType               { get; set; }
    public LicenseStatus Status            { get; set; }
    public DateTime ActivatedAt            { get; set; } = DateTime.UtcNow;
    public DateTime? ExpiresAt             { get; set; }
    public bool     SyncAddonActive        { get; set; }
    public DateTime? SyncAddonExpiresAt    { get; set; }
    public string?  DeviceFingerprintHash  { get; set; }   // SHA-256
    public int      MaxBranches            { get; set; } = 1;
    public int      MaxUsers               { get; set; } = 1;
    public int      MaxProducts            { get; set; } = 500;
    public DateTime? DowngradedAt          { get; set; }
    public string?  DowngradeReason        { get; set; }

    public virtual Tenant? Tenant          { get; set; }
    public virtual ICollection<DeviceRegistration> Devices { get; set; } = [];
}

public class DeviceRegistration : Base.BaseEntity
{
    public Guid     LicenseId              { get; set; }
    public required string FingerprintHash { get; set; }
    public required string DeviceName      { get; set; }
    public string?  OS                     { get; set; }
    public string?  AppVersion             { get; set; }
    public DateTime LastSeenAt             { get; set; } = DateTime.UtcNow;
    public bool     IsRevoked              { get; set; }
    public DateTime? RevokedAt             { get; set; }

    public virtual License? License        { get; set; }
}

public class Plugin : Base.BaseEntity
{
    public required string Name            { get; set; }
    public required string Slug            { get; set; }
    public string?  Description            { get; set; }
    public string?  DeveloperName          { get; set; }
    public string   Version                { get; set; } = "1.0.0";
    public PluginCategory Category         { get; set; }
    public decimal  Price                  { get; set; }
    public bool     IsActive               { get; set; } = true;
    public bool     IsVerified             { get; set; }
    public bool     IsFeatured             { get; set; }
    public int      InstallCount           { get; set; }
    public decimal  Rating                 { get; set; }

    public virtual ICollection<PluginInstallation> Installations { get; set; } = [];
}

public class PluginInstallation : Base.BaseEntity
{
    public Guid     PluginId               { get; set; }
    public bool     IsEnabled              { get; set; } = true;
    public string?  Config                 { get; set; }
    public DateTime InstalledAt            { get; set; } = DateTime.UtcNow;

    public virtual Plugin?  Plugin         { get; set; }
    public virtual Tenant?  Tenant         { get; set; }
}
