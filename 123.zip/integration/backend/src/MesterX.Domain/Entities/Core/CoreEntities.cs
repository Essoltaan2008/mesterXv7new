using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Billing;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Core;

public class Tenant : Base.BaseEntity
{
    public required string Name           { get; set; }
    public required string Slug           { get; set; }   // URL-safe unique key
    public string?  LogoUrl               { get; set; }
    public string?  CoverUrl              { get; set; }
    public BusinessType BusinessType      { get; set; } = BusinessType.RetailStore;
    public string?  Description           { get; set; }
    public string?  ContactEmail          { get; set; }
    public string?  ContactPhone          { get; set; }
    public string?  WhatsApp              { get; set; }
    public string?  Website               { get; set; }
    public string?  Address               { get; set; }
    public string?  City                  { get; set; }
    public string   Country               { get; set; } = "EG";
    public string?  TaxNumber             { get; set; }
    public string   Currency              { get; set; } = "EGP";
    public decimal  VatRate               { get; set; } = 0.14m;
    public string   Language              { get; set; } = "ar";
    public string   Timezone              { get; set; } = "Africa/Cairo";
    public TenantStatus Status            { get; set; } = TenantStatus.Trial;
    public PlanType Plan                  { get; set; } = PlanType.Trial;
    public TenantModules ActiveModules    { get; set; } = TenantModules.POS | TenantModules.Inventory;
    public bool     IsActive              { get; set; } = true;
    public bool     IsVerified            { get; set; }
    public DateTime? VerifiedAt           { get; set; }
    public DateTime? TrialEndsAt          { get; set; }
    public DateTime? SuspendedAt          { get; set; }
    public string?  SuspendReason         { get; set; }
    public bool     LoyaltyEnabled        { get; set; }
    public decimal  LoyaltyPointsRate     { get; set; } = 1m;   // 1 ج.م = 1 point
    public int      LoyaltyRedeemMin      { get; set; } = 100;  // 100 points = 1 ج.م
    public string?  ReceiptFooter         { get; set; }

    public virtual ICollection<Branch>            Branches      { get; set; } = [];
    public virtual ICollection<ApplicationUser>   Users         { get; set; } = [];
    public virtual ICollection<Subscription>      Subscriptions { get; set; } = [];
    public virtual ICollection<Product>           Products      { get; set; } = [];
    public virtual ICollection<Customer>          Customers     { get; set; } = [];
    public virtual ICollection<SaleOrder>         SaleOrders    { get; set; } = [];
    public virtual ICollection<Category>          Categories    { get; set; } = [];
    public virtual ICollection<Supplier>          Suppliers     { get; set; } = [];
    public virtual ICollection<Expense>           Expenses      { get; set; } = [];
}

public class Branch : Base.BaseEntity
{
    public required string Name            { get; set; }
    public string?  NameAr                 { get; set; }
    public string?  Code                   { get; set; }
    public Guid?    ManagerId              { get; set; }
    public string?  Address                { get; set; }
    public string?  City                   { get; set; }
    public string   Country                { get; set; } = "EG";
    public string?  PhoneNumber            { get; set; }
    public string?  Email                  { get; set; }
    public double?  Latitude               { get; set; }
    public double?  Longitude              { get; set; }
    public bool     IsMain                 { get; set; }
    public bool     IsActive               { get; set; } = true;
    public bool     AcceptsOnlineOrders    { get; set; } = true;
    public TimeOnly? OpenTime              { get; set; }
    public TimeOnly? CloseTime             { get; set; }

    public virtual Tenant?              Tenant     { get; set; }
    public virtual ApplicationUser?     Manager    { get; set; }
    public virtual ICollection<ApplicationUser> Users     { get; set; } = [];
    public virtual ICollection<StockItem>       StockItems{ get; set; } = [];
    public virtual ICollection<SaleOrder>       SaleOrders{ get; set; } = [];
}

public class Product : Base.BaseEntity
{
    public Guid?    CategoryId             { get; set; }
    public Guid?    BranchId               { get; set; }   // null = all branches
    public required string Name            { get; set; }
    public string?  NameAr                 { get; set; }
    public string?  Description            { get; set; }
    public string?  Barcode                { get; set; }
    public string?  SKU                    { get; set; }
    public ProductType Type                { get; set; } = ProductType.Physical;
    public ProductUnit Unit                { get; set; } = ProductUnit.Piece;
    public decimal  CostPrice              { get; set; }
    public decimal  SalePrice              { get; set; }
    public decimal? WholesalePrice         { get; set; }
    public decimal? MinSalePrice           { get; set; }   // floor price — cannot sell below
    public bool     HasVat                 { get; set; } = true;
    public decimal  VatRate                { get; set; } = 0.14m;
    public string?  ImageUrl               { get; set; }
    public string?  GalleryUrls            { get; set; }   // JSON array
    public bool     IsActive               { get; set; } = true;
    public bool     IsAvailableOnline      { get; set; } = true;
    public bool     IsFeatured             { get; set; }
    public bool     TrackInventory         { get; set; } = true;
    public int      LowStockThreshold      { get; set; } = 5;
    public decimal? ReorderPoint           { get; set; }
    public decimal? ReorderQuantity        { get; set; }

    public virtual Tenant?     Tenant          { get; set; }
    public virtual Category?   Category        { get; set; }
    public virtual Branch?     Branch          { get; set; }
    public virtual ICollection<StockItem>     StockItems     { get; set; } = [];
    public virtual ICollection<StockMovement> StockMovements { get; set; } = [];
    public virtual ICollection<SaleOrderItem> SaleOrderItems { get; set; } = [];
}

public class Customer : Base.BaseEntity
{
    public required string Name            { get; set; }
    public string?  Phone                  { get; set; }
    public string?  Email                  { get; set; }
    public string?  Address                { get; set; }
    public string?  City                   { get; set; }
    public Gender   Gender                 { get; set; } = Gender.Unknown;
    public DateOnly? DateOfBirth           { get; set; }
    public CustomerSegment Segment         { get; set; } = CustomerSegment.New;
    public decimal  LoyaltyPoints          { get; set; }
    public decimal  TotalPurchases         { get; set; }
    public int      TotalOrders            { get; set; }
    public DateTime? LastPurchaseAt        { get; set; }
    public DateTime? FirstPurchaseAt       { get; set; }
    public decimal  CreditLimit            { get; set; }
    public decimal  OutstandingBalance     { get; set; }
    public bool     AllowCredit            { get; set; }
    public bool     IsActive               { get; set; } = true;
    public bool     IsBlacklisted          { get; set; }
    public string?  BlacklistReason        { get; set; }
    public string?  Notes                  { get; set; }

    public virtual Tenant?   Tenant    { get; set; }
    public virtual ICollection<SaleOrder> SaleOrders { get; set; } = [];
}

public class Category : Base.BaseEntity
{
    public required string Name  { get; set; }
    public string?  NameAr       { get; set; }
    public string?  Description  { get; set; }
    public string?  ImageUrl     { get; set; }
    public Guid?    ParentId     { get; set; }
    public int      SortOrder    { get; set; }
    public bool     IsActive     { get; set; } = true;

    public virtual Tenant?     Tenant        { get; set; }
    public virtual Category?   Parent        { get; set; }
    public virtual ICollection<Category> SubCategories { get; set; } = [];
    public virtual ICollection<Product>  Products      { get; set; } = [];
}

public class Supplier : Base.BaseEntity
{
    public required string Name        { get; set; }
    public string?  ContactPerson      { get; set; }
    public string?  Phone              { get; set; }
    public string?  Email              { get; set; }
    public string?  Address            { get; set; }
    public string?  City               { get; set; }
    public string?  TaxNumber          { get; set; }
    public SupplierStatus Status       { get; set; } = SupplierStatus.Active;
    public decimal  CreditLimit        { get; set; }
    public decimal  OutstandingBalance { get; set; }
    public int      PaymentTermsDays   { get; set; } = 30;
    public string?  Notes              { get; set; }

    public virtual Tenant? Tenant { get; set; }
    public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = [];
}

public class Expense : Base.BaseEntity
{
    public required string Description { get; set; }
    public Guid?    BranchId           { get; set; }
    public Guid?    ApprovedById       { get; set; }
    public ExpenseCategory Category    { get; set; }
    public decimal  Amount             { get; set; }
    public DateTime ExpenseDate        { get; set; }
    public PaymentMethod PaymentMethod { get; set; } = PaymentMethod.Cash;
    public string?  Reference          { get; set; }
    public string?  AttachmentUrl      { get; set; }
    public string?  Notes              { get; set; }
    public bool     IsRecurring        { get; set; }

    public virtual Tenant?           Tenant      { get; set; }
    public virtual Branch?           Branch      { get; set; }
    public virtual ApplicationUser?  ApprovedBy  { get; set; }
}
