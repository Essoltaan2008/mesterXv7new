using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Auth;

/// <summary>
/// Application user. Belongs to exactly one Tenant.
/// Supports MFA (TOTP), account lockout after N failed logins,
/// and forced password change on first login.
/// </summary>
public class ApplicationUser : BaseEntity
{
    public required string Username         { get; set; }
    public required string Email            { get; set; }
    public required string PasswordHash     { get; set; }   // BCrypt cost=12
    public required string FirstName        { get; set; }
    public required string LastName         { get; set; }
    public string  FullName => $"{FirstName} {LastName}";
    public string? Phone                    { get; set; }
    public string? AvatarUrl               { get; set; }
    public UserRole Role                    { get; set; } = UserRole.Cashier;
    public Guid?   BranchId                { get; set; }   // null = all branches

    // Status
    public bool    IsActive                { get; set; } = true;
    public bool    IsEmailVerified         { get; set; }
    public DateTime? EmailVerifiedAt       { get; set; }

    // Login tracking
    public DateTime? LastLoginAt           { get; set; }
    public string?   LastLoginIp           { get; set; }
    public string?   LastLoginDevice       { get; set; }

    // Lockout — after 5 wrong passwords, lock for 15 minutes
    public int       FailedLoginAttempts   { get; set; }
    public DateTime? LockoutEnd            { get; set; }
    public bool IsLockedOut => LockoutEnd.HasValue && LockoutEnd.Value > DateTime.UtcNow;

    // MFA / TOTP (RFC 6238)
    public bool    TwoFactorEnabled        { get; set; }
    public string? TotpSecret              { get; set; }    // AES-256 encrypted
    public string? BackupCodes             { get; set; }    // JSON hashed codes

    // Password policy
    public DateTime? PasswordChangedAt     { get; set; }
    public bool    MustChangePassword      { get; set; }

    // Preferences
    public string Language                 { get; set; } = "ar";
    public string Theme                    { get; set; } = "dark";
    public string Timezone                 { get; set; } = "Africa/Cairo";

    // Navigation
    public virtual Tenant?  Tenant         { get; set; }
    public virtual Branch?  Branch         { get; set; }
    public virtual ICollection<RefreshToken> RefreshTokens { get; set; } = [];
}

/// <summary>
/// Salted + hashed refresh tokens. Raw token never stored.
/// Token = random 32 bytes → store SHA-256(raw + salt).
/// Rotation: old token is revoked, new one issued on every refresh.
/// </summary>
public class RefreshToken : BaseEntity
{
    public Guid     UserId         { get; set; }
    public required string TokenHash  { get; set; }   // SHA-256(raw + salt)
    public required string Salt       { get; set; }   // 16 random bytes
    public string?  DeviceInfo     { get; set; }
    public string?  IpAddress      { get; set; }
    public bool     IsRevoked      { get; set; }
    public DateTime ExpiresAt      { get; set; }
    public DateTime? RevokedAt     { get; set; }
    public string?  ReplacedByHash { get; set; }   // for token family tracking

    public virtual ApplicationUser? User { get; set; }
}

/// <summary>Custom role with fine-grained permissions per resource.</summary>
public class ApplicationRole : BaseEntity
{
    public required string Name        { get; set; }
    public required string NameAr      { get; set; }
    public string?  Description        { get; set; }
    public bool     IsSystem           { get; set; }   // cannot be deleted
    public bool     IsActive           { get; set; } = true;

    public virtual ICollection<ApplicationPermission> Permissions { get; set; } = [];
}

/// <summary>CRUD permission for a specific resource, attached to a Role.</summary>
public class ApplicationPermission : BaseEntity
{
    public Guid     RoleId    { get; set; }
    public required string Resource { get; set; }   // "products", "reports", etc.
    public bool     CanCreate { get; set; }
    public bool     CanRead   { get; set; }
    public bool     CanUpdate { get; set; }
    public bool     CanDelete { get; set; }
    public bool     CanExport { get; set; }

    public virtual ApplicationRole? Role { get; set; }
}

/// <summary>Per-tenant feature flag (enable/disable modules at runtime).</summary>
public class FeatureFlag : BaseEntity
{
    public required string Feature   { get; set; }
    public bool    IsEnabled         { get; set; }
    public string? Config            { get; set; }   // JSON config
    public DateTime? EnabledAt       { get; set; }
    public DateTime? ExpiresAt       { get; set; }   // null = permanent
}
