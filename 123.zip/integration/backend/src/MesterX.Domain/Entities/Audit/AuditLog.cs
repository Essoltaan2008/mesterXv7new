using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Audit;

/// <summary>
/// Immutable audit record. Every sensitive operation writes one entry.
/// IntegrityHash chains each record to the previous, forming a tamper-evident log.
/// Protected by a database trigger preventing UPDATE/DELETE on records > 24h old.
/// </summary>
public class AuditLog
{
    public Guid          Id             { get; set; } = Guid.NewGuid();
    public Guid          TenantId       { get; set; }
    public Guid?         UserId         { get; set; }
    public AuditAction   Action         { get; set; }
    public string        EntityType     { get; set; } = "";
    public Guid?         EntityId       { get; set; }
    public string?       OldValues      { get; set; }   // JSON
    public string?       NewValues      { get; set; }   // JSON
    public string?       IpAddress      { get; set; }
    public string?       UserAgent      { get; set; }
    public bool          IsSuccess      { get; set; } = true;
    public string?       ErrorMessage   { get; set; }
    public string        IntegrityHash  { get; set; } = ""; // SHA-256 chain
    public DateTime      CreatedAt      { get; set; } = DateTime.UtcNow;
    public DateTime      UpdatedAt      { get; set; } = DateTime.UtcNow;
    public int           Version        { get; set; } = 1;
}
