namespace MesterX.Domain.Entities.Platform;

public class PlatformConfig
{
    public Guid    Id            { get; set; } = Guid.NewGuid();
    public required string Key   { get; set; }
    public required string Value { get; set; }
    public string? DescriptionAr { get; set; }
    public bool    IsPublic      { get; set; }
    public DateTime CreatedAt    { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt    { get; set; } = DateTime.UtcNow;
}
