namespace MesterX.Domain.Entities.Base;

/// <summary>
/// Every database table inherits from this.
/// Contains: PK, TenantId (multi-tenant key), soft-delete fields,
/// audit timestamps, and optimistic concurrency version.
/// </summary>
public abstract class BaseEntity
{
    public Guid      Id        { get; set; } = Guid.NewGuid();
    public Guid      TenantId  { get; set; }

    // Soft delete — never hard-delete anything
    public bool      IsDeleted { get; set; }
    public DateTime? DeletedAt { get; set; }
    public Guid?     DeletedBy { get; set; }

    // Timestamps — set automatically by EF Core interceptor
    public DateTime  CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime  UpdatedAt { get; set; } = DateTime.UtcNow;
    public Guid?     CreatedBy { get; set; }
    public Guid?     UpdatedBy { get; set; }

    // Optimistic concurrency — incremented on every UPDATE by SaveChanges
    public int       Version   { get; set; } = 1;
}
