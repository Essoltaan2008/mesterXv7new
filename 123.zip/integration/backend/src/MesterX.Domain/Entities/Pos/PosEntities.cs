using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.POS;

public class SaleOrder : Base.BaseEntity
{
    public required string OrderNumber       { get; set; }
    public Guid     BranchId                 { get; set; }
    public Guid?    CustomerId               { get; set; }
    public Guid     CashierId                { get; set; }
    public SaleStatus Status                 { get; set; } = SaleStatus.Pending;
    public PaymentMethod PaymentMethod       { get; set; } = PaymentMethod.Cash;
    public DiscountType? DiscountType        { get; set; }
    public decimal  SubTotal                 { get; set; }
    public decimal  VatAmount                { get; set; }
    public decimal  DiscountAmount           { get; set; }
    public decimal  TotalAmount              { get; set; }
    public decimal  AmountPaid               { get; set; }
    public decimal  ChangeGiven              { get; set; }
    public decimal  LoyaltyPointsUsed        { get; set; }
    public decimal  LoyaltyPointsEarned      { get; set; }
    public bool     IsOffline                { get; set; }
    public string?  ClientIdempotencyKey     { get; set; }
    public bool     IsPrinted                { get; set; }
    public DateTime? PrintedAt               { get; set; }
    public DateTime? SyncedAt                { get; set; }
    public string?  Notes                    { get; set; }

    public virtual Tenant?          Tenant    { get; set; }
    public virtual Branch?          Branch    { get; set; }
    public virtual Customer?        Customer  { get; set; }
    public virtual ApplicationUser? Cashier   { get; set; }
    public virtual ICollection<SaleOrderItem> Items    { get; set; } = [];
    public virtual ICollection<Payment>       Payments { get; set; } = [];
    public virtual ICollection<SaleRefund>    Refunds  { get; set; } = [];
}

public class SaleOrderItem : Base.BaseEntity
{
    public Guid     SaleOrderId              { get; set; }
    public Guid     ProductId                { get; set; }
    public required string ProductName       { get; set; }
    public string?  ProductBarcode           { get; set; }
    public string?  ProductSku               { get; set; }
    public decimal  Quantity                 { get; set; }
    public decimal  UnitPrice                { get; set; }
    public decimal  CostPrice                { get; set; }   // for profit reports
    public decimal  VatRate                  { get; set; }
    public decimal  VatAmount                { get; set; }
    public decimal  DiscountAmount           { get; set; }
    public decimal  LineTotal                { get; set; }
    public string?  Notes                    { get; set; }

    public virtual SaleOrder?  SaleOrder  { get; set; }
    public virtual Product?    Product    { get; set; }
}

public class Payment : Base.BaseEntity
{
    public Guid     SaleOrderId              { get; set; }
    public Guid     ProcessedById            { get; set; }
    public PaymentMethod Method              { get; set; }
    public decimal  Amount                   { get; set; }
    public PaymentStatus Status              { get; set; } = PaymentStatus.Completed;
    public string?  Reference                { get; set; }
    public string?  ExternalRef              { get; set; }
    public string?  Notes                    { get; set; }
    public DateTime? PaidAt                  { get; set; } = DateTime.UtcNow;

    public virtual SaleOrder?      SaleOrder    { get; set; }
    public virtual ApplicationUser? ProcessedBy { get; set; }
}

public class SaleRefund : Base.BaseEntity
{
    public Guid     SaleOrderId              { get; set; }
    public Guid     ProcessedById            { get; set; }
    public decimal  RefundAmount             { get; set; }
    public PaymentMethod RefundMethod        { get; set; } = PaymentMethod.Cash;
    public string?  Reason                   { get; set; }
    public string?  Reference                { get; set; }
    public bool     IsFullRefund             { get; set; }
    public DateTime RefundedAt               { get; set; } = DateTime.UtcNow;

    public virtual SaleOrder?      SaleOrder    { get; set; }
    public virtual ApplicationUser? ProcessedBy { get; set; }
}

public class StockItem : Base.BaseEntity
{
    public Guid     ProductId                { get; set; }
    public Guid     BranchId                 { get; set; }
    public decimal  Quantity                 { get; set; }
    public decimal  ReservedQuantity         { get; set; }
    public decimal  AvailableQuantity => Quantity - ReservedQuantity;
    public decimal? LastCostPrice            { get; set; }
    public DateTime? LastCountedAt           { get; set; }

    public virtual Product?  Product   { get; set; }
    public virtual Branch?   Branch    { get; set; }
    public virtual ICollection<StockMovement> Movements { get; set; } = [];
}

public class StockMovement : Base.BaseEntity
{
    public Guid     ProductId                { get; set; }
    public Guid     BranchId                 { get; set; }
    public Guid?    UserId                   { get; set; }
    public Guid?    SaleOrderId              { get; set; }
    public Guid?    PurchaseOrderId          { get; set; }
    public Guid?    TransferToId             { get; set; }
    public StockMovementType Type            { get; set; }
    public decimal  QuantityBefore           { get; set; }
    public decimal  QuantityChange           { get; set; }
    public decimal  QuantityAfter            { get; set; }
    public decimal? UnitCost                 { get; set; }
    public string?  Reference                { get; set; }
    public string?  Notes                    { get; set; }

    public virtual Product?        Product { get; set; }
    public virtual Branch?         Branch  { get; set; }
    public virtual ApplicationUser? User   { get; set; }
}

public class PurchaseOrder : Base.BaseEntity
{
    public Guid     SupplierId               { get; set; }
    public Guid     BranchId                 { get; set; }
    public Guid?    ApprovedById             { get; set; }
    public required string PONumber          { get; set; }
    public PurchaseOrderStatus Status        { get; set; } = PurchaseOrderStatus.Draft;
    public decimal  TotalAmount              { get; set; }
    public decimal  AmountPaid               { get; set; }
    public decimal  AmountDue => TotalAmount - AmountPaid;
    public DateTime? OrderDate               { get; set; }
    public DateTime? ExpectedDate            { get; set; }
    public DateTime? ReceivedDate            { get; set; }
    public PaymentMethod PaymentMethod       { get; set; }
    public int      PaymentTermsDays         { get; set; } = 30;
    public string?  Notes                    { get; set; }
    public string?  AttachmentUrl            { get; set; }

    public virtual Tenant?         Tenant      { get; set; }
    public virtual Supplier?       Supplier    { get; set; }
    public virtual Branch?         Branch      { get; set; }
    public virtual ApplicationUser? ApprovedBy { get; set; }
    public virtual ICollection<PurchaseOrderItem> Items { get; set; } = [];
}

public class PurchaseOrderItem : Base.BaseEntity
{
    public Guid     PurchaseOrderId          { get; set; }
    public Guid     ProductId                { get; set; }
    public required string ProductName       { get; set; }
    public decimal  QuantityOrdered          { get; set; }
    public decimal  QuantityReceived         { get; set; }
    public decimal  UnitCost                 { get; set; }
    public decimal  VatAmount                { get; set; }
    public decimal  LineTotal                { get; set; }
    public DateTime? ReceivedAt              { get; set; }
    public string?  Notes                    { get; set; }

    public virtual PurchaseOrder? PurchaseOrder { get; set; }
    public virtual Product?       Product       { get; set; }
}
