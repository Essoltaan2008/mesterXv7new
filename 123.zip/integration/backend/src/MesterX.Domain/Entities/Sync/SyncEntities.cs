using MesterX.Domain.Enums;

namespace MesterX.Domain.Entities.Sync;

public class SyncQueue : Base.BaseEntity
{
    public required string IdempotencyKey    { get; set; }
    public SyncEntityType  EntityType        { get; set; }
    public SyncOperation   Operation         { get; set; }
    public required string Payload           { get; set; }   // JSON
    public int             ClientVersion     { get; set; }
    public ConflictStrategy ConflictStrategy { get; set; }
    public SyncStatus      Status            { get; set; } = SyncStatus.Pending;
    public bool            HasConflict       { get; set; }
    public string?         ConflictDetails   { get; set; }
    public string?         ErrorMessage      { get; set; }
    public Guid?           CreatedBy         { get; set; }
    public DateTime?       ProcessedAt       { get; set; }
}

public class SyncLog : Base.BaseEntity
{
    public Guid?   DeviceId    { get; set; }
    public string? DeviceName  { get; set; }
    public int     ItemsPushed { get; set; }
    public int     ItemsPulled { get; set; }
    public int     Conflicts   { get; set; }
    public bool    IsSuccess   { get; set; }
    public string? ErrorMessage{ get; set; }
    public DateTime SyncedAt   { get; set; } = DateTime.UtcNow;
}
