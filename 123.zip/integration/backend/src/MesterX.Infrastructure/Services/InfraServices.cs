using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace MesterX.Infrastructure.Services;

// ════════════════════════════════════════════════════════════════════════════
// SecurityHelper — BCrypt passwords + Salted refresh tokens
// ════════════════════════════════════════════════════════════════════════════
public static class SecurityHelper
{
    private const int WORK = 12; // BCrypt work factor ≈ 250ms

    public static string HashPassword(string password)
        => BCrypt.Net.BCrypt.HashPassword(password, WORK);

    public static bool VerifyPassword(string password, string hash)
    {
        try { return BCrypt.Net.BCrypt.Verify(password, hash); }
        catch { return false; }
    }

    public static (bool Valid, string? Error) ValidatePolicy(string password)
    {
        if (password.Length < 8) return (false, "كلمة المرور يجب أن تكون 8 أحرف على الأقل");
        if (!password.Any(char.IsUpper)) return (false, "يجب أن تحتوي على حرف كبير");
        if (!password.Any(char.IsDigit)) return (false, "يجب أن تحتوي على رقم");
        if (!password.Any(c => !char.IsLetterOrDigit(c))) return (false, "يجب أن تحتوي على رمز خاص");
        return (true, null);
    }

    public static (string Raw, string Hash, string Salt) GenerateRefreshToken()
    {
        var raw  = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
        var salt = Convert.ToBase64String(RandomNumberGenerator.GetBytes(16));
        var hash = ComputeSha256(raw + salt);
        return (raw, hash, salt);
    }

    public static bool VerifyRefreshToken(string raw, string storedHash, string salt)
        => string.Equals(ComputeSha256(raw + salt), storedHash, StringComparison.OrdinalIgnoreCase);

    public static string HashSha256(string input) => ComputeSha256(input);
    public static string HashSha512(string input)
        => Convert.ToHexString(SHA512.HashData(Encoding.UTF8.GetBytes(input))).ToLower();

    private static string ComputeSha256(string input)
        => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(input))).ToLower();
}

// ════════════════════════════════════════════════════════════════════════════
// ITotpService + TotpService — RFC 6238 TOTP
// ════════════════════════════════════════════════════════════════════════════
public interface ITotpService
{
    (string Secret, string QrCodeUrl) GenerateSecret(string email, string issuer = "MesterX");
    bool   ValidateCode(string secret, string code, int tolerance = 1);
    string GenerateBackupCode();
}

public sealed class TotpService : MesterX.Domain.Interfaces.ITotpService
{
    private const int    STEP     = 30;
    private const int    DIGITS   = 6;
    private const string B32CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public (string Secret, string QrCodeUrl) GenerateSecret(string email, string issuer = "MesterX")
    {
        var secret = Base32Encode(RandomNumberGenerator.GetBytes(20));
        var qr = $"otpauth://totp/{Uri.EscapeDataString(issuer)}:{Uri.EscapeDataString(email)}" +
                 $"?secret={secret}&issuer={Uri.EscapeDataString(issuer)}&digits={DIGITS}&period={STEP}";
        return (secret, qr);
    }

    public bool ValidateCode(string secret, string code, int tolerance = 1)
    {
        if (string.IsNullOrWhiteSpace(code) || code.Length != DIGITS) return false;
        if (!long.TryParse(code, out var input)) return false;
        var key     = Base32Decode(secret.Trim().ToUpperInvariant());
        var counter = DateTimeOffset.UtcNow.ToUnixTimeSeconds() / STEP;
        for (int i = -tolerance; i <= tolerance; i++)
            if (Hotp(key, counter + i) == input) return true;
        return false;
    }

    public string GenerateBackupCode()
        => Convert.ToHexString(RandomNumberGenerator.GetBytes(5)).ToUpper()[..8];

    private static long Hotp(byte[] key, long c)
    {
        var msg = BitConverter.GetBytes(c);
        if (BitConverter.IsLittleEndian) Array.Reverse(msg);
        using var h = new HMACSHA1(key);
        var hash   = h.ComputeHash(msg);
        int offset = hash[^1] & 0x0F;
        int trunc  = ((hash[offset] & 0x7F) << 24) | ((hash[offset+1] & 0xFF) << 16)
                   | ((hash[offset+2] & 0xFF) << 8)  |  (hash[offset+3] & 0xFF);
        return trunc % (long)Math.Pow(10, DIGITS);
    }

    private static string Base32Encode(byte[] data)
    {
        var sb = new StringBuilder();
        for (int i = 0; i < data.Length; i += 5)
        {
            ulong buf = 0; int rem = Math.Min(5, data.Length - i);
            for (int j = 0; j < rem; j++) buf |= (ulong)data[i+j] << (32 - 8*j);
            int bits = (int)Math.Ceiling(rem * 8.0 / 5);
            for (int j = 0; j < bits; j++) sb.Append(B32CHARS[(int)((buf >> (35-5*j)) & 0x1F)]);
        }
        return sb.ToString();
    }

    private static byte[] Base32Decode(string input)
    {
        input = input.TrimEnd('=');
        var out_ = new byte[input.Length * 5 / 8];
        int buf = 0, bits = 0, idx = 0;
        foreach (char c in input)
        {
            int v = B32CHARS.IndexOf(c); if (v < 0) continue;
            buf = (buf << 5) | v; bits += 5;
            if (bits >= 8) out_[idx++] = (byte)(buf >> (bits -= 8));
        }
        return out_;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// ICacheService + MemoryCacheService
// ════════════════════════════════════════════════════════════════════════════
public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken ct = default) where T : class;
    Task     SetAsync<T>(string key, T value, TimeSpan? ttl = null, CancellationToken ct = default);
    Task     RemoveAsync(string key, CancellationToken ct = default);
    Task     RemovePrefixAsync(string prefix, CancellationToken ct = default);
}

public static class CacheKeys
{
    public static string Plans                   => "mx:plans";
    public static string TenantLicense(Guid t)   => $"mx:lic:{t}";
    public static string ProductsByBranch(Guid b) => $"mx:prod:{b}";
    public static string DashboardStats(Guid t, DateOnly d) => $"mx:dash:{t}:{d:yyyyMMdd}";
}

public sealed class MemoryCacheService : MesterX.Domain.Interfaces.ICacheService
{
    private readonly IMemoryCache    _cache;
    private readonly SemaphoreSlim   _lock = new(1, 1);
    private readonly HashSet<string> _keys = new();
    private static readonly TimeSpan DEFAULT = TimeSpan.FromMinutes(5);

    public MemoryCacheService(IMemoryCache cache) => _cache = cache;

    public Task<T?> GetAsync<T>(string key, CancellationToken ct = default) where T : class
    {
        _cache.TryGetValue(key, out T? v);
        return Task.FromResult(v);
    }

    public async Task SetAsync<T>(string key, T value, TimeSpan? ttl = null, CancellationToken ct = default)
    {
        var opts = new MemoryCacheEntryOptions { AbsoluteExpirationRelativeToNow = ttl ?? DEFAULT };
        opts.RegisterPostEvictionCallback((k, _, _, _) => TrackRemove(k.ToString()!));
        _cache.Set(key, value, opts);
        await _lock.WaitAsync(ct); try { _keys.Add(key); } finally { _lock.Release(); }
    }

    public async Task RemoveAsync(string key, CancellationToken ct = default)
    {
        _cache.Remove(key);
        await _lock.WaitAsync(ct); try { _keys.Remove(key); } finally { _lock.Release(); }
    }

    public async Task RemovePrefixAsync(string prefix, CancellationToken ct = default)
    {
        await _lock.WaitAsync(ct);
        try
        {
            foreach (var k in _keys.Where(k => k.StartsWith(prefix)).ToList())
            { _cache.Remove(k); _keys.Remove(k); }
        }
        finally { _lock.Release(); }
    }

    private void TrackRemove(string k) { _lock.Wait(); try { _keys.Remove(k); } finally { _lock.Release(); } }
}

// ════════════════════════════════════════════════════════════════════════════
// IAuditService + AuditService — SHA-256 chain for tamper detection
// ════════════════════════════════════════════════════════════════════════════
public interface IAuditService
{
    Task LogAsync(AuditEntry entry, CancellationToken ct = default);
}

public sealed record AuditEntry(
    Guid        TenantId,
    Guid?       UserId,
    AuditAction Action,
    string      EntityType,
    Guid?       EntityId     = null,
    object?     OldValues    = null,
    object?     NewValues    = null,
    bool        IsSuccess    = true,
    string?     ErrorMessage = null);

public sealed class AuditService : MesterX.Domain.Interfaces.IAuditService
{
    private readonly MesterXDbContext      _db;
    private readonly IHttpContextAccessor  _http;
    private readonly ILogger<AuditService> _log;
    private static readonly JsonSerializerOptions J = new()
        { PropertyNamingPolicy        = JsonNamingPolicy.CamelCase,
          DefaultIgnoreCondition      = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull };

    public AuditService(MesterXDbContext db, IHttpContextAccessor http, ILogger<AuditService> log)
    { _db = db; _http = http; _log = log; }

    public async Task LogAsync(MesterX.Domain.Interfaces.AuditEntry entry, CancellationToken ct = default)
    {
        try
        {
            var ctx  = _http.HttpContext;
            var ip   = ctx?.Connection.RemoteIpAddress?.ToString();
            var ua   = ctx?.Request.Headers["User-Agent"].ToString();
            if (ua is not null && ua.Length > 500) ua = ua[..500];
            var now  = DateTime.UtcNow;
            var prev = await GetLastHashAsync(entry.TenantId, ct);

            _db.AuditLogs.Add(new Domain.Entities.Audit.AuditLog
            {
                Id            = Guid.NewGuid(),
                TenantId      = entry.TenantId,
                UserId        = entry.UserId,
                Action        = entry.Action,
                EntityType    = entry.EntityType,
                EntityId      = entry.EntityId,
                OldValues     = entry.OldValues is not null ? JsonSerializer.Serialize(entry.OldValues, J) : null,
                NewValues     = entry.NewValues is not null ? JsonSerializer.Serialize(entry.NewValues, J) : null,
                IsSuccess     = entry.IsSuccess,
                ErrorMessage  = entry.ErrorMessage,
                IpAddress     = ip,
                UserAgent     = ua,
                IntegrityHash = ChainHash(entry.TenantId, entry.Action, entry.EntityType, entry.EntityId, now, prev),
                CreatedAt     = now,
                UpdatedAt     = now,
                Version       = 1,
            });
            await _db.SaveChangesAsync(ct);
        }
        catch (Exception ex) { _log.LogError(ex, "Audit failed: {A}/{E}", entry.Action, entry.EntityType); }
    }

    private async Task<string> GetLastHashAsync(Guid tenantId, CancellationToken ct)
    {
        var h = await _db.AuditLogs
            .Where(a => a.TenantId == tenantId)
            .OrderByDescending(a => a.CreatedAt)
            .Select(a => a.IntegrityHash).FirstOrDefaultAsync(ct);
        return h ?? "GENESIS";
    }

    private static string ChainHash(Guid tid, AuditAction act, string entity,
        Guid? eid, DateTime at, string prev)
    {
        var raw   = $"{tid}|{(int)act}|{entity}|{eid}|{at:O}|{prev}";
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(raw));
        return Convert.ToHexString(bytes).ToLower();
    }
}

// ════════════════════════════════════════════════════════════════════════════
// ITenantProvider — resolves current user/tenant from JWT claims
// ════════════════════════════════════════════════════════════════════════════
public interface ITenantProvider
{
    Guid? TenantId      { get; }
    Guid? CurrentUserId { get; }
    string? Language    { get; }
    bool IsAuthenticated{ get; }
}

public sealed class TenantProvider : MesterX.Domain.Interfaces.ITenantProvider
{
    private readonly IHttpContextAccessor _http;
    public TenantProvider(IHttpContextAccessor http) => _http = http;

    public Guid? TenantId      => Parse(_http.HttpContext?.User.FindFirst("tenant_id")?.Value);
    public Guid? CurrentUserId => Parse(_http.HttpContext?.User.FindFirst("user_id")?.Value);
    public UserRole? CurrentRole => Enum.TryParse<UserRole>(
        _http.HttpContext?.User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value,
        out var role) ? role : null;

    private static Guid? Parse(string? v) => Guid.TryParse(v, out var g) ? g : null;
}

// ════════════════════════════════════════════════════════════════════════════
// LicenseEnforcementJob — runs every 30 minutes, auto-downgrades expired
// ════════════════════════════════════════════════════════════════════════════
public sealed class LicenseEnforcementJob : Microsoft.Extensions.Hosting.BackgroundService
{
    private readonly IServiceProvider _sp;
    private readonly ILogger<LicenseEnforcementJob> _log;

    public LicenseEnforcementJob(IServiceProvider sp, ILogger<LicenseEnforcementJob> log)
    { _sp = sp; _log = log; }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        _log.LogInformation("⚡ LicenseEnforcementJob started (30-min cycle)");
        await Task.Delay(TimeSpan.FromSeconds(30), ct); // initial delay on startup

        while (!ct.IsCancellationRequested)
        {
            try { await RunAsync(ct); }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
            catch (Exception ex) { _log.LogError(ex, "License enforcement error"); }
            await Task.Delay(TimeSpan.FromMinutes(30), ct);
        }
    }

    private async Task RunAsync(CancellationToken ct)
    {
        using var scope = _sp.CreateScope();
        var db  = scope.ServiceProvider.GetRequiredService<MesterXDbContext>();
        var now = DateTime.UtcNow;

        var expired = await db.Licenses
            .Include(l => l.Tenant)
            .Where(l => !l.IsDeleted && l.Status == LicenseStatus.Active
                     && l.ExpiresAt.HasValue && l.ExpiresAt.Value < now
                     && l.PlanType != PlanType.Lifetime && l.PlanType != PlanType.Enterprise)
            .ToListAsync(ct);

        foreach (var lic in expired)
        {
            var reason = lic.PlanType == PlanType.Trial
                ? "انتهت فترة التجربة" : "انتهى الاشتراك الشهري";

            lic.PlanType = PlanType.Basic; lic.Status = LicenseStatus.Downgraded;
            lic.MaxBranches = 1; lic.MaxUsers = 1; lic.MaxProducts = 500;
            lic.SyncAddonActive = false; lic.DowngradedAt = now; lic.DowngradeReason = reason;
            if (lic.Tenant is not null) lic.Tenant.Plan = PlanType.Basic;

            _log.LogWarning("⬇️ Downgraded: Tenant={T} Reason={R}", lic.TenantId, reason);
        }

        // Revoke expired sync add-ons
        var expiredSync = await db.Licenses
            .Where(l => !l.IsDeleted && l.SyncAddonActive
                     && l.SyncAddonExpiresAt.HasValue && l.SyncAddonExpiresAt.Value < now)
            .ToListAsync(ct);
        foreach (var lic in expiredSync)
        { lic.SyncAddonActive = false; lic.SyncAddonExpiresAt = null; }

        if (expired.Count + expiredSync.Count > 0)
        {
            await db.SaveChangesAsync(ct);
            _log.LogInformation("License enforcement: {D} downgraded, {S} sync revoked",
                expired.Count, expiredSync.Count);
        }
    }
}
