using System.Linq.Expressions;
using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Billing;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Entities.Sync;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace MesterX.Infrastructure.Repositories;

// ── Generic Repository ────────────────────────────────────────────────────────
public class Repository<T> : IRepository<T> where T : class
{
    protected readonly MesterXDbContext _db;
    protected readonly DbSet<T>        _set;

    public Repository(MesterXDbContext db) { _db = db; _set = db.Set<T>(); }

    public IQueryable<T> Query() => _set.AsQueryable();

    public async Task<T?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => await _set.FindAsync([id], ct);

    public async Task<T?> FirstOrDefaultAsync(
        Expression<Func<T,bool>> p, CancellationToken ct = default)
        => await _set.FirstOrDefaultAsync(p, ct);

    public async Task<IEnumerable<T>> FindAsync(
        Expression<Func<T,bool>> p, CancellationToken ct = default)
        => await _set.Where(p).ToListAsync(ct);

    public async Task<bool> AnyAsync(
        Expression<Func<T,bool>> p, CancellationToken ct = default)
        => await _set.AnyAsync(p, ct);

    public async Task<int> CountAsync(
        Expression<Func<T,bool>> p, CancellationToken ct = default)
        => await _set.CountAsync(p, ct);

    public async Task AddAsync(T entity, CancellationToken ct = default)
        => await _set.AddAsync(entity, ct);

    public async Task AddRangeAsync(IEnumerable<T> entities, CancellationToken ct = default)
        => await _set.AddRangeAsync(entities, ct);

    public void Update(T entity) => _set.Update(entity);

    public void SoftDelete(T entity, Guid deletedBy)
    {
        if (entity is BaseEntity b)
        {
            b.IsDeleted = true;
            b.DeletedAt = DateTime.UtcNow;
            b.DeletedBy = deletedBy;
            _set.Update(entity);
        }
    }

    public void Remove(T entity) => _set.Remove(entity);
}

// ── Unit of Work ─────────────────────────────────────────────────────────────
public class UnitOfWork : IUnitOfWork
{
    private readonly MesterXDbContext    _db;
    private IDbContextTransaction?      _tx;

    public UnitOfWork(MesterXDbContext db) => _db = db;

    // Auth
    public IRepository<ApplicationUser>       Users               => new Repository<ApplicationUser>(_db);
    public IRepository<ApplicationRole>       Roles               => new Repository<ApplicationRole>(_db);
    public IRepository<ApplicationPermission> Permissions         => new Repository<ApplicationPermission>(_db);
    public IRepository<RefreshToken>          RefreshTokens       => new Repository<RefreshToken>(_db);
    public IRepository<FeatureFlag>           FeatureFlags        => new Repository<FeatureFlag>(_db);

    // Core
    public IRepository<Tenant>                Tenants             => new Repository<Tenant>(_db);
    public IRepository<Branch>                Branches            => new Repository<Branch>(_db);
    public IRepository<Category>              Categories          => new Repository<Category>(_db);
    public IRepository<Customer>              Customers           => new Repository<Customer>(_db);
    public IRepository<Supplier>              Suppliers           => new Repository<Supplier>(_db);
    public IRepository<Expense>               Expenses            => new Repository<Expense>(_db);

    // Billing
    public IRepository<Plan>                  Plans               => new Repository<Plan>(_db);
    public IRepository<Subscription>          Subscriptions       => new Repository<Subscription>(_db);
    public IRepository<License>               Licenses            => new Repository<License>(_db);
    public IRepository<DeviceRegistration>    DeviceRegistrations => new Repository<DeviceRegistration>(_db);
    public IRepository<Plugin>                Plugins             => new Repository<Plugin>(_db);
    public IRepository<PluginInstallation>    PluginInstallations => new Repository<PluginInstallation>(_db);

    // POS
    public IRepository<Product>               Products            => new Repository<Product>(_db);
    public IRepository<StockItem>             StockItems          => new Repository<StockItem>(_db);
    public IRepository<StockMovement>         StockMovements      => new Repository<StockMovement>(_db);
    public IRepository<SaleOrder>             SaleOrders          => new Repository<SaleOrder>(_db);
    public IRepository<SaleOrderItem>         SaleOrderItems      => new Repository<SaleOrderItem>(_db);
    public IRepository<Payment>               Payments            => new Repository<Payment>(_db);
    public IRepository<SaleRefund>            SaleRefunds         => new Repository<SaleRefund>(_db);
    public IRepository<PurchaseOrder>         PurchaseOrders      => new Repository<PurchaseOrder>(_db);
    public IRepository<PurchaseOrderItem>     PurchaseOrderItems  => new Repository<PurchaseOrderItem>(_db);

    // Sync & Audit
    public IRepository<SyncQueue>             SyncQueue           => new Repository<SyncQueue>(_db);
    public IRepository<SyncLog>               SyncLogs            => new Repository<SyncLog>(_db);
    public IRepository<AuditLog>              AuditLogs           => new Repository<AuditLog>(_db);
    public IRepository<PlatformConfig>        PlatformConfigs     => new Repository<PlatformConfig>(_db);

    public async Task<int> SaveChangesAsync(CancellationToken ct = default)
        => await _db.SaveChangesAsync(ct);

    public async Task BeginTransactionAsync(CancellationToken ct = default)
        => _tx = await _db.Database.BeginTransactionAsync(ct);

    public async Task CommitTransactionAsync(CancellationToken ct = default)
    {
        if (_tx is null) return;
        await _tx.CommitAsync(ct);
        await _tx.DisposeAsync();
        _tx = null;
    }

    public async Task RollbackTransactionAsync(CancellationToken ct = default)
    {
        if (_tx is null) return;
        await _tx.RollbackAsync(ct);
        await _tx.DisposeAsync();
        _tx = null;
    }

    public void          Dispose()       => _db.Dispose();
    public ValueTask     DisposeAsync()  => _db.DisposeAsync();
}
