using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Billing;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Enums;
using MesterX.Infrastructure.Data;
using MesterX.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MesterX.Infrastructure.Seeding;

/// <summary>
/// Seeds the database with plans, plugins, a platform owner, and two demo tenants
/// (restaurant + supermarket) so the system is immediately usable after docker-compose up.
/// </summary>
public static class DatabaseSeeder
{
    public static async Task SeedAsync(MesterXDbContext db, ILogger? log = null)
    {
        await SeedPlansAsync(db);
        await SeedPluginsAsync(db);
        await SeedPlatformOwnerAsync(db);
        await SeedDemoRestaurantAsync(db);
        await SeedDemoSupermarketAsync(db);
        await db.SaveChangesAsync();
        log?.LogInformation("✅ Seed data applied successfully");
    }

    // ── Plans ────────────────────────────────────────────────────────────────
    private static async Task SeedPlansAsync(MesterXDbContext db)
    {
        if (await db.Plans.AnyAsync()) return;

        db.Plans.AddRange(
            new Plan { Id = Guid.Parse("00000000-0000-0000-0000-000000000001"),
                Name="التجريبية",NameEn="Trial",Type=PlanType.Trial,SortOrder=0,
                MonthlyPrice=0,AnnualPrice=0,MaxBranches=1,MaxUsers=3,MaxProducts=50,
                HasSyncEngine=true,HasAdvancedReports=true,DataRetentionDays=90,SupportLevel="basic",IsActive=true },
            new Plan { Id = Guid.Parse("00000000-0000-0000-0000-000000000002"),
                Name="الأساسية",NameEn="Basic",Type=PlanType.Basic,SortOrder=1,
                MonthlyPrice=0,AnnualPrice=0,MaxBranches=1,MaxUsers=1,MaxProducts=500,
                HasSyncEngine=false,HasAdvancedReports=false,DataRetentionDays=365,SupportLevel="basic",IsActive=true },
            new Plan { Id = Guid.Parse("00000000-0000-0000-0000-000000000003"),
                Name="المحترفة",NameEn="Pro",Type=PlanType.ProMonthly,SortOrder=2,
                MonthlyPrice=499,AnnualPrice=4990,MaxBranches=5,MaxUsers=20,MaxProducts=5000,
                HasSyncEngine=true,HasMultiBranch=true,HasAdvancedReports=true,HasDelivery=true,
                HasWhatsApp=true,MaxWhatsAppNumbers=1,HasPluginStore=true,
                HasRestaurantModule=true,MaxRestaurantTables=30,HasKDS=true,HasQRMenu=true,
                HasTableReservations=true,HasRestaurantAnalytics=true,
                HasRentalModule=true,MaxRentalAssets=50,DataRetentionDays=730,SupportLevel="priority",IsActive=true },
            new Plan { Id = Guid.Parse("00000000-0000-0000-0000-000000000004"),
                Name="الدائمة",NameEn="Lifetime",Type=PlanType.Lifetime,SortOrder=3,
                MonthlyPrice=0,AnnualPrice=0,LifetimePrice=9999,MaxBranches=3,MaxUsers=15,MaxProducts=2000,
                HasSyncEngine=false,HasMultiBranch=true,HasAdvancedReports=true,
                HasRestaurantModule=true,HasRentalModule=true,DataRetentionDays=-1,SupportLevel="priority",IsActive=true },
            new Plan { Id = Guid.Parse("00000000-0000-0000-0000-000000000005"),
                Name="المؤسسية",NameEn="Enterprise",Type=PlanType.Enterprise,SortOrder=4,
                MonthlyPrice=1999,AnnualPrice=19990,MaxBranches=-1,MaxUsers=-1,MaxProducts=-1,
                HasSyncEngine=true,HasMultiBranch=true,HasAdvancedReports=true,HasApiAccess=true,
                HasWhiteLabel=true,HasAi=true,HasDelivery=true,HasMarketplace=true,
                HasWhatsApp=true,MaxWhatsAppNumbers=10,HasPluginStore=true,
                HasRestaurantModule=true,MaxRestaurantTables=-1,HasKDS=true,HasQRMenu=true,
                HasTableReservations=true,HasRestaurantAnalytics=true,
                HasRentalModule=true,MaxRentalAssets=-1,HasRentalMarketplace=true,
                DataRetentionDays=-1,SupportLevel="dedicated",UptimeSlaPercent=999,IsActive=true }
        );
    }

    // ── Plugins ──────────────────────────────────────────────────────────────
    private static async Task SeedPluginsAsync(MesterXDbContext db)
    {
        if (await db.Plugins.AnyAsync()) return;
        db.Plugins.AddRange(
            new Plugin { Id=Guid.NewGuid(),Name="نظام الحجوزات",Slug="booking-system",DeveloperName="MesterX",Version="1.2.0",Category=PluginCategory.Booking,Price=0,IsActive=true,IsVerified=true,IsFeatured=true,Rating=4.8m,InstallCount=1240,Description="حجز الطاولات والمواعيد أونلاين" },
            new Plugin { Id=Guid.NewGuid(),Name="برنامج الولاء",Slug="loyalty-program",DeveloperName="MesterX",Version="1.5.0",Category=PluginCategory.Loyalty,Price=0,IsActive=true,IsVerified=true,IsFeatured=true,Rating=4.9m,InstallCount=2100,Description="نقاط مكافآت ومستويات VIP" },
            new Plugin { Id=Guid.NewGuid(),Name="المحاسبة المتقدمة",Slug="advanced-accounting",DeveloperName="MesterX",Version="2.0.0",Category=PluginCategory.Accounting,Price=99,IsActive=true,IsVerified=true,Rating=4.5m,InstallCount=680,Description="أرباح وخسائر وتقارير ضريبية" },
            new Plugin { Id=Guid.NewGuid(),Name="CRM Pro",Slug="crm-pro",DeveloperName="MesterX",Version="1.3.0",Category=PluginCategory.CRM,Price=149,IsActive=true,IsVerified=true,Rating=4.6m,InstallCount=430,Description="إدارة علاقات العملاء" },
            new Plugin { Id=Guid.NewGuid(),Name="تسويق واتساب",Slug="whatsapp-marketing",DeveloperName="MesterX",Version="1.1.0",Category=PluginCategory.Marketing,Price=79,IsActive=true,IsVerified=true,Rating=4.4m,InstallCount=890,Description="حملات واتساب بالجملة" }
        );
    }

    // ── Platform Owner ────────────────────────────────────────────────────────
    private static async Task SeedPlatformOwnerAsync(MesterXDbContext db)
    {
        if (await db.Users.AnyAsync(u => u.Role == UserRole.PlatformOwner)) return;

        var ptid = Guid.Parse("00000000-0000-0000-FFFF-000000000001");
        if (!await db.Tenants.AnyAsync(t => t.Id == ptid))
        {
            db.Tenants.Add(new Tenant
            {
                Id=ptid,TenantId=ptid,Name="MesterX Platform",Slug="mesterx-platform",
                Status=TenantStatus.Active,IsActive=true,Plan=PlanType.Enterprise,
                Currency="EGP",VatRate=0.14m,
            });
        }

        db.Users.Add(new ApplicationUser
        {
            Id=Guid.Parse("00000000-0000-0000-FFFF-000000000010"),TenantId=ptid,
            Username="platform_owner",Email="mahmoudtohamy44@gmail.com",
            PasswordHash=SecurityHelper.HashPassword("Admin@MesterX2025!"),
            FirstName="محمود",LastName="طهامي",Phone="+201090647292",
            Role=UserRole.PlatformOwner,IsActive=true,IsEmailVerified=true,Language="ar",
        });
    }

    // ── Demo: مطعم النيل كافيه ────────────────────────────────────────────────
    private static async Task SeedDemoRestaurantAsync(MesterXDbContext db)
    {
        var tenantId = Guid.Parse("00000000-0000-0000-0001-000000000001");
        if (await db.Tenants.AnyAsync(t => t.Id == tenantId)) return;

        var branchId = Guid.Parse("00000000-0000-0000-0001-000000000002");
        var ownerId  = Guid.Parse("00000000-0000-0000-0001-000000000003");

        db.Tenants.Add(new Tenant { Id=tenantId,TenantId=tenantId,Name="مطعم النيل كافيه",Slug="nile-cafe",BusinessType=BusinessType.Restaurant,ContactEmail="info@nilecafe.eg",ContactPhone="+20223456789",Address="26 شارع عمر أفندي، الزمالك",City="القاهرة",TaxNumber="123456789",Status=TenantStatus.Active,IsActive=true,IsVerified=true,Plan=PlanType.ProMonthly,ActiveModules=TenantModules.POS|TenantModules.Inventory|TenantModules.Restaurant,LoyaltyEnabled=true,LoyaltyPointsRate=1m });
        db.Branches.Add(new Branch { Id=branchId,TenantId=tenantId,Name="الفرع الرئيسي — الزمالك",Code="ZM01",Address="26 شارع عمر أفندي",City="القاهرة",IsMain=true,IsActive=true,OpenTime=new TimeOnly(8,0),CloseTime=new TimeOnly(2,0) });
        db.Users.Add(new ApplicationUser { Id=ownerId,TenantId=tenantId,BranchId=branchId,Username="nile_owner",Email="owner@nilecafe.eg",PasswordHash=SecurityHelper.HashPassword("Admin@MesterX2025!"),FirstName="أحمد",LastName="النيل",Phone="+20100111111",Role=UserRole.CompanyOwner,IsActive=true });
        db.Users.Add(new ApplicationUser { Id=Guid.NewGuid(),TenantId=tenantId,BranchId=branchId,Username="nile_cashier",Email="cashier@nilecafe.eg",PasswordHash=SecurityHelper.HashPassword("Admin@MesterX2025!"),FirstName="سارة",LastName="حسن",Phone="+20100333333",Role=UserRole.Cashier,IsActive=true });

        // License
        db.Licenses.Add(new License { Id=Guid.NewGuid(),TenantId=tenantId,LicenseKeyHash=SecurityHelper.HashSha512("NILE-PRO-2025"),PlanType=PlanType.ProMonthly,Status=LicenseStatus.Active,ActivatedAt=DateTime.UtcNow,ExpiresAt=DateTime.UtcNow.AddMonths(1),MaxBranches=5,MaxUsers=20,MaxProducts=5000 });

        // Categories + products
        var catId = Guid.NewGuid();
        db.Categories.Add(new Category { Id=catId,TenantId=tenantId,Name="مشروبات",SortOrder=1,IsActive=true });

        var prod1 = Guid.NewGuid();
        db.Products.Add(new Product { Id=prod1,TenantId=tenantId,CategoryId=catId,Name="إسبريسو صغير",SKU="ESP-SM",CostPrice=5,SalePrice=25,HasVat=true,VatRate=0.14m,IsActive=true,Type=ProductType.Physical,Unit=ProductUnit.Piece,TrackInventory=false });
        db.Products.Add(new Product { Id=Guid.NewGuid(),TenantId=tenantId,CategoryId=catId,Name="كابتشينو وسط",SKU="CAP-MD",CostPrice=7,SalePrice=35,HasVat=true,VatRate=0.14m,IsActive=true,Type=ProductType.Physical,Unit=ProductUnit.Piece,TrackInventory=false });
        db.Products.Add(new Product { Id=Guid.NewGuid(),TenantId=tenantId,CategoryId=catId,Name="سندوتش فراخ",SKU="SAND-CH",CostPrice=22,SalePrice=55,HasVat=true,VatRate=0.14m,IsActive=true,Type=ProductType.Physical,Unit=ProductUnit.Piece,TrackInventory=true,LowStockThreshold=5 });

        // Customer
        db.Customers.Add(new Customer { Id=Guid.NewGuid(),TenantId=tenantId,Name="محمد السيد",Phone="01012345678",Email="m.elsayed@email.com",Segment=CustomerSegment.VIP,LoyaltyPoints=580,TotalPurchases=5800,TotalOrders=47,IsActive=true });
    }

    // ── Demo: سوبر ماركت الفرح ────────────────────────────────────────────────
    private static async Task SeedDemoSupermarketAsync(MesterXDbContext db)
    {
        var tenantId = Guid.Parse("00000000-0000-0000-0002-000000000001");
        if (await db.Tenants.AnyAsync(t => t.Id == tenantId)) return;

        var branchId = Guid.Parse("00000000-0000-0000-0002-000000000002");

        db.Tenants.Add(new Tenant { Id=tenantId,TenantId=tenantId,Name="سوبر ماركت الفرح",Slug="farha-supermarket",BusinessType=BusinessType.Supermarket,ContactPhone="+20234567890",City="الجيزة",Status=TenantStatus.Active,IsActive=true,Plan=PlanType.Basic,ActiveModules=TenantModules.POS|TenantModules.Inventory });
        db.Branches.Add(new Branch { Id=branchId,TenantId=tenantId,Name="الفرع الرئيسي",Code="HR01",City="الجيزة",IsMain=true,IsActive=true });
        db.Users.Add(new ApplicationUser { Id=Guid.NewGuid(),TenantId=tenantId,BranchId=branchId,Username="farha_owner",Email="owner@farha.eg",PasswordHash=SecurityHelper.HashPassword("Admin@MesterX2025!"),FirstName="كريم",LastName="الفرح",Role=UserRole.CompanyOwner,IsActive=true });
        db.Licenses.Add(new License { Id=Guid.NewGuid(),TenantId=tenantId,LicenseKeyHash=SecurityHelper.HashSha512("FARHA-BASIC-2025"),PlanType=PlanType.Basic,Status=LicenseStatus.Active,ActivatedAt=DateTime.UtcNow,ExpiresAt=null,MaxBranches=1,MaxUsers=1,MaxProducts=500 });

        var catFoodId = Guid.NewGuid();
        var catDrinkId = Guid.NewGuid();
        db.Categories.AddRange(
            new Category { Id=catFoodId,TenantId=tenantId,Name="مواد غذائية",SortOrder=1,IsActive=true },
            new Category { Id=catDrinkId,TenantId=tenantId,Name="مشروبات",SortOrder=2,IsActive=true }
        );

        var products = new[]
        {
            (Guid.NewGuid(),catFoodId,"أرز مصري 5 كيلو","RICE-5KG","6224001234567",40m,65m,150m),
            (Guid.NewGuid(),catFoodId,"زيت ذرة 1.5 لتر","OIL-15L","6224009876543",28m,42m,80m),
            (Guid.NewGuid(),catFoodId,"سكر أبيض 2 كيلو","SUGAR-2KG","6224003456789",18m,28m,200m),
            (Guid.NewGuid(),catFoodId,"لبن كامل 1 لتر","MILK-1L","6224007654321",12m,18m,120m),
            (Guid.NewGuid(),catDrinkId,"مياه معدنية 1.5 لتر","WATER-15","6224003333333",2m,5m,500m),
            (Guid.NewGuid(),catDrinkId,"بيبسي 1 لتر","PEPSI-1L","6224004444444",12m,20m,200m),
        };

        foreach (var (id, catId, name, sku, barcode, cost, price, stock) in products)
        {
            db.Products.Add(new Product { Id=id,TenantId=tenantId,CategoryId=catId,Name=name,SKU=sku,Barcode=barcode,CostPrice=cost,SalePrice=price,HasVat=true,VatRate=0.14m,IsActive=true,TrackInventory=true,LowStockThreshold=10,Type=ProductType.Physical,Unit=ProductUnit.Piece });
            db.StockItems.Add(new StockItem { Id=Guid.NewGuid(),TenantId=tenantId,ProductId=id,BranchId=branchId,Quantity=stock });
        }
    }
}
