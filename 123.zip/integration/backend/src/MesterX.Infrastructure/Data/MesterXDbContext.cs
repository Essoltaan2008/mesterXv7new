using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Base;
using MesterX.Domain.Entities.Billing;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Entities.Sync;

namespace MesterX.Infrastructure.Data;

public class MesterXDbContext : DbContext
{
    public MesterXDbContext(DbContextOptions<MesterXDbContext> options) : base(options) { }

    // ── Auth ──────────────────────────────────────────────────────────────
    public DbSet<ApplicationUser>       Users               => Set<ApplicationUser>();
    public DbSet<ApplicationRole>       Roles               => Set<ApplicationRole>();
    public DbSet<ApplicationPermission> Permissions         => Set<ApplicationPermission>();
    public DbSet<RefreshToken>          RefreshTokens       => Set<RefreshToken>();
    public DbSet<FeatureFlag>           FeatureFlags        => Set<FeatureFlag>();

    // ── Core ─────────────────────────────────────────────────────────────
    public DbSet<Tenant>                Tenants             => Set<Tenant>();
    public DbSet<Branch>                Branches            => Set<Branch>();
    public DbSet<Category>              Categories          => Set<Category>();
    public DbSet<Customer>              Customers           => Set<Customer>();
    public DbSet<Supplier>              Suppliers           => Set<Supplier>();
    public DbSet<Expense>               Expenses            => Set<Expense>();

    // ── Billing ───────────────────────────────────────────────────────────
    public DbSet<Plan>                  Plans               => Set<Plan>();
    public DbSet<Subscription>          Subscriptions       => Set<Subscription>();
    public DbSet<License>               Licenses            => Set<License>();
    public DbSet<DeviceRegistration>    DeviceRegistrations => Set<DeviceRegistration>();
    public DbSet<Plugin>                Plugins             => Set<Plugin>();
    public DbSet<PluginInstallation>    PluginInstallations => Set<PluginInstallation>();

    // ── POS ───────────────────────────────────────────────────────────────
    public DbSet<Product>               Products            => Set<Product>();
    public DbSet<StockItem>             StockItems          => Set<StockItem>();
    public DbSet<StockMovement>         StockMovements      => Set<StockMovement>();
    public DbSet<SaleOrder>             SaleOrders          => Set<SaleOrder>();
    public DbSet<SaleOrderItem>         SaleOrderItems      => Set<SaleOrderItem>();
    public DbSet<Payment>               Payments            => Set<Payment>();
    public DbSet<SaleRefund>            SaleRefunds         => Set<SaleRefund>();
    public DbSet<PurchaseOrder>         PurchaseOrders      => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderItem>     PurchaseOrderItems  => Set<PurchaseOrderItem>();

    // ── Sync & Audit ──────────────────────────────────────────────────────
    public DbSet<SyncQueue>             SyncQueue           => Set<SyncQueue>();
    public DbSet<SyncLog>               SyncLogs            => Set<SyncLog>();
    public DbSet<AuditLog>              AuditLogs           => Set<AuditLog>();
    public DbSet<PlatformConfig>        PlatformConfigs     => Set<PlatformConfig>();

    protected override void OnModelCreating(ModelBuilder m)
    {
        base.OnModelCreating(m);

        // Apply all IEntityTypeConfiguration classes in this assembly
        m.ApplyConfigurationsFromAssembly(typeof(MesterXDbContext).Assembly);

        // Global soft-delete filter on every BaseEntity
        foreach (var et in m.Model.GetEntityTypes())
        {
            if (!typeof(BaseEntity).IsAssignableFrom(et.ClrType)) continue;
            var isDeleted = et.FindProperty("IsDeleted");
            if (isDeleted == null) continue;
            var param = System.Linq.Expressions.Expression.Parameter(et.ClrType, "e");
            var prop  = System.Linq.Expressions.Expression.Property(param, "IsDeleted");
            var notDeleted = System.Linq.Expressions.Expression.Not(prop);
            var lambda = System.Linq.Expressions.Expression.Lambda(notDeleted, param);
            et.SetQueryFilter(lambda);
        }
    }

    public override Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        // Auto-set timestamps + version on every save
        var now = DateTime.UtcNow;
        foreach (var entry in ChangeTracker.Entries<BaseEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                entry.Entity.CreatedAt = now;
                entry.Entity.UpdatedAt = now;
            }
            else if (entry.State == EntityState.Modified)
            {
                entry.Entity.UpdatedAt = now;
                entry.Entity.Version++;
            }
        }
        // AuditLog timestamps (not BaseEntity)
        foreach (var entry in ChangeTracker.Entries<AuditLog>()
                     .Where(e => e.State == EntityState.Added))
        {
            entry.Entity.CreatedAt = now;
            entry.Entity.UpdatedAt = now;
        }
        return base.SaveChangesAsync(ct);
    }
}
