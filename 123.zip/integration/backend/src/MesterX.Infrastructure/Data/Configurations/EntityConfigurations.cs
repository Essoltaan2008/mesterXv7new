using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MesterX.Domain.Entities.Audit;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Billing;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.Platform;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Entities.Sync;

namespace MesterX.Infrastructure.Data.Configurations;

// ── Tenant ────────────────────────────────────────────────────────────────────
public class TenantConfig : IEntityTypeConfiguration<Tenant>
{
    public void Configure(EntityTypeBuilder<Tenant> e)
    {
        e.ToTable("tenants");
        e.HasIndex(x => x.Slug).IsUnique();
        e.HasIndex(x => x.Status);
        e.Property(x => x.Name).HasMaxLength(200).IsRequired();
        e.Property(x => x.Slug).HasMaxLength(100).IsRequired();
        e.Property(x => x.Currency).HasMaxLength(10).HasDefaultValue("EGP");
        e.Property(x => x.VatRate).HasColumnType("decimal(5,4)").HasDefaultValue(0.14m);
        e.Property(x => x.LoyaltyPointsRate).HasColumnType("decimal(10,4)").HasDefaultValue(1m);
        e.Property(x => x.Country).HasMaxLength(5).HasDefaultValue("EG");
    }
}

// ── Branch ────────────────────────────────────────────────────────────────────
public class BranchConfig : IEntityTypeConfiguration<Branch>
{
    public void Configure(EntityTypeBuilder<Branch> e)
    {
        e.ToTable("branches");
        e.HasIndex(x => x.TenantId);
        e.Property(x => x.Name).HasMaxLength(200).IsRequired();
        e.Property(x => x.Code).HasMaxLength(20);
        e.HasOne(x => x.Tenant).WithMany(t => t.Branches)
            .HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Cascade);
        e.HasOne(x => x.Manager).WithMany()
            .HasForeignKey(x => x.ManagerId).OnDelete(DeleteBehavior.SetNull);
    }
}

// ── ApplicationUser ───────────────────────────────────────────────────────────
public class UserConfig : IEntityTypeConfiguration<ApplicationUser>
{
    public void Configure(EntityTypeBuilder<ApplicationUser> e)
    {
        e.ToTable("users");
        e.HasIndex(x => x.Email).IsUnique().HasFilter("is_deleted = false");
        e.HasIndex(x => x.Username).IsUnique().HasFilter("is_deleted = false");
        e.HasIndex(x => x.TenantId);
        e.Property(x => x.Email).HasMaxLength(256).IsRequired();
        e.Property(x => x.Username).HasMaxLength(100).IsRequired();
        e.Property(x => x.PasswordHash).HasMaxLength(100).IsRequired();  // BCrypt ~60 chars
        e.Property(x => x.FirstName).HasMaxLength(100).IsRequired();
        e.Property(x => x.LastName).HasMaxLength(100).IsRequired();
        e.Property(x => x.Phone).HasMaxLength(30);
        e.Property(x => x.TotpSecret).HasMaxLength(512);
        e.HasOne(x => x.Tenant).WithMany(t => t.Users)
            .HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Restrict);
        e.HasOne(x => x.Branch).WithMany(b => b.Users)
            .HasForeignKey(x => x.BranchId).OnDelete(DeleteBehavior.SetNull);
    }
}

// ── RefreshToken ──────────────────────────────────────────────────────────────
public class RefreshTokenConfig : IEntityTypeConfiguration<RefreshToken>
{
    public void Configure(EntityTypeBuilder<RefreshToken> e)
    {
        e.ToTable("refresh_tokens");
        e.HasIndex(x => x.TokenHash).IsUnique();
        e.HasIndex(x => x.UserId);
        e.HasIndex(x => x.ExpiresAt);
        e.Property(x => x.TokenHash).HasMaxLength(512).IsRequired();
        e.Property(x => x.Salt).HasMaxLength(100).IsRequired();
        e.HasOne(x => x.User).WithMany(u => u.RefreshTokens)
            .HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        // RefreshTokens bypass soft-delete filter
        e.HasQueryFilter(x => true);
    }
}

// ── Product ───────────────────────────────────────────────────────────────────
public class ProductConfig : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> e)
    {
        e.ToTable("products");
        e.HasIndex(x => new { x.TenantId, x.SKU }).IsUnique()
            .HasFilter("sku IS NOT NULL AND is_deleted = false");
        e.HasIndex(x => x.Barcode).HasFilter("barcode IS NOT NULL");
        e.HasIndex(x => x.TenantId);
        e.Property(x => x.Name).HasMaxLength(300).IsRequired();
        e.Property(x => x.Barcode).HasMaxLength(100);
        e.Property(x => x.SKU).HasMaxLength(100);
        e.Property(x => x.CostPrice).HasColumnType("decimal(12,2)");
        e.Property(x => x.SalePrice).HasColumnType("decimal(12,2)");
        e.Property(x => x.WholesalePrice).HasColumnType("decimal(12,2)");
        e.Property(x => x.MinSalePrice).HasColumnType("decimal(12,2)");
        e.Property(x => x.VatRate).HasColumnType("decimal(5,4)").HasDefaultValue(0.14m);
        e.HasOne(x => x.Tenant).WithMany(t => t.Products)
            .HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Cascade);
        e.HasOne(x => x.Category).WithMany(c => c.Products)
            .HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.SetNull);
    }
}

// ── StockItem ─────────────────────────────────────────────────────────────────
public class StockItemConfig : IEntityTypeConfiguration<StockItem>
{
    public void Configure(EntityTypeBuilder<StockItem> e)
    {
        e.ToTable("stock_items");
        e.HasIndex(x => new { x.ProductId, x.BranchId }).IsUnique();
        e.HasIndex(x => x.TenantId);
        e.Property(x => x.Quantity).HasColumnType("decimal(12,4)");
        e.Property(x => x.ReservedQuantity).HasColumnType("decimal(12,4)");
        e.Ignore(x => x.AvailableQuantity);
        e.HasOne(x => x.Product).WithMany(p => p.StockItems)
            .HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Cascade);
        e.HasOne(x => x.Branch).WithMany(b => b.StockItems)
            .HasForeignKey(x => x.BranchId).OnDelete(DeleteBehavior.Cascade);
    }
}

// ── SaleOrder ─────────────────────────────────────────────────────────────────
public class SaleOrderConfig : IEntityTypeConfiguration<SaleOrder>
{
    public void Configure(EntityTypeBuilder<SaleOrder> e)
    {
        e.ToTable("sale_orders");
        e.HasIndex(x => x.OrderNumber).IsUnique();
        e.HasIndex(x => new { x.TenantId, x.CreatedAt });
        e.HasIndex(x => new { x.BranchId, x.CreatedAt });
        e.HasIndex(x => x.ClientIdempotencyKey)
            .HasFilter("client_idempotency_key IS NOT NULL").IsUnique();
        e.Property(x => x.SubTotal).HasColumnType("decimal(14,2)");
        e.Property(x => x.VatAmount).HasColumnType("decimal(12,2)");
        e.Property(x => x.DiscountAmount).HasColumnType("decimal(12,2)");
        e.Property(x => x.TotalAmount).HasColumnType("decimal(14,2)");
        e.Property(x => x.AmountPaid).HasColumnType("decimal(14,2)");
        e.Property(x => x.ChangeGiven).HasColumnType("decimal(12,2)");
        e.Property(x => x.LoyaltyPointsUsed).HasColumnType("decimal(12,2)");
        e.Property(x => x.LoyaltyPointsEarned).HasColumnType("decimal(12,2)");
        e.HasOne(x => x.Customer).WithMany(c => c.SaleOrders)
            .HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.SetNull);
    }
}

// ── Customer ──────────────────────────────────────────────────────────────────
public class CustomerConfig : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> e)
    {
        e.ToTable("customers");
        e.HasIndex(x => new { x.TenantId, x.Phone })
            .IsUnique().HasFilter("phone IS NOT NULL AND is_deleted = false");
        e.HasIndex(x => x.TenantId);
        e.Property(x => x.Name).HasMaxLength(200).IsRequired();
        e.Property(x => x.Phone).HasMaxLength(30);
        e.Property(x => x.LoyaltyPoints).HasColumnType("decimal(12,2)");
        e.Property(x => x.TotalPurchases).HasColumnType("decimal(14,2)");
        e.Property(x => x.CreditLimit).HasColumnType("decimal(12,2)");
        e.Property(x => x.OutstandingBalance).HasColumnType("decimal(12,2)");
        e.HasOne(x => x.Tenant).WithMany(t => t.Customers)
            .HasForeignKey(x => x.TenantId).OnDelete(DeleteBehavior.Cascade);
    }
}

// ── Plan ──────────────────────────────────────────────────────────────────────
public class PlanConfig : IEntityTypeConfiguration<Plan>
{
    public void Configure(EntityTypeBuilder<Plan> e)
    {
        e.ToTable("plans");
        e.HasIndex(x => x.Type).IsUnique();
        e.Property(x => x.Name).HasMaxLength(100).IsRequired();
        e.Property(x => x.NameEn).HasMaxLength(100).IsRequired();
        e.Property(x => x.MonthlyPrice).HasColumnType("decimal(10,2)");
        e.Property(x => x.AnnualPrice).HasColumnType("decimal(10,2)");
        e.Property(x => x.LifetimePrice).HasColumnType("decimal(10,2)");
        // Plan has no TenantId filter — it's global
        e.HasQueryFilter(x => true);
    }
}

// ── Subscription ──────────────────────────────────────────────────────────────
public class SubscriptionConfig : IEntityTypeConfiguration<Subscription>
{
    public void Configure(EntityTypeBuilder<Subscription> e)
    {
        e.ToTable("subscriptions");
        e.HasIndex(x => x.TenantId);
        e.HasIndex(x => new { x.Status, x.EndDate });
        e.Property(x => x.Amount).HasColumnType("decimal(10,2)");
        e.HasOne(x => x.Plan).WithMany(p => p.Subscriptions)
            .HasForeignKey(x => x.PlanId).OnDelete(DeleteBehavior.Restrict);
    }
}

// ── License ───────────────────────────────────────────────────────────────────
public class LicenseConfig : IEntityTypeConfiguration<License>
{
    public void Configure(EntityTypeBuilder<License> e)
    {
        e.ToTable("licenses");
        e.HasIndex(x => x.LicenseKeyHash).IsUnique();
        e.HasIndex(x => x.TenantId);
        e.Property(x => x.LicenseKeyHash).HasMaxLength(512).IsRequired();
        e.Property(x => x.DeviceFingerprintHash).HasMaxLength(512);
        e.HasQueryFilter(x => !x.IsDeleted);
    }
}

// ── AuditLog ──────────────────────────────────────────────────────────────────
public class AuditLogConfig : IEntityTypeConfiguration<AuditLog>
{
    public void Configure(EntityTypeBuilder<AuditLog> e)
    {
        e.ToTable("audit_logs");
        e.HasKey(x => x.Id);
        e.HasIndex(x => new { x.TenantId, x.CreatedAt });
        e.HasIndex(x => new { x.UserId, x.CreatedAt }).HasFilter("user_id IS NOT NULL");
        e.Property(x => x.IntegrityHash).HasMaxLength(200).IsRequired();
        e.Property(x => x.EntityType).HasMaxLength(100).IsRequired();
        e.Property(x => x.IpAddress).HasMaxLength(50);
        e.Property(x => x.UserAgent).HasMaxLength(500);
        // Never soft-delete audit logs
        e.HasQueryFilter(x => true);
    }
}

// ── SyncQueue ─────────────────────────────────────────────────────────────────
public class SyncQueueConfig : IEntityTypeConfiguration<SyncQueue>
{
    public void Configure(EntityTypeBuilder<SyncQueue> e)
    {
        e.ToTable("sync_queue");
        e.HasIndex(x => new { x.TenantId, x.IdempotencyKey }).IsUnique();
        e.HasIndex(x => new { x.TenantId, x.Status });
        e.Property(x => x.IdempotencyKey).HasMaxLength(200).IsRequired();
    }
}

// ── PlatformConfig ────────────────────────────────────────────────────────────
public class PlatformConfigConfig : IEntityTypeConfiguration<PlatformConfig>
{
    public void Configure(EntityTypeBuilder<PlatformConfig> e)
    {
        e.ToTable("platform_configs");
        e.HasKey(x => x.Id);
        e.HasIndex(x => x.Key).IsUnique();
        e.Property(x => x.Key).HasMaxLength(100).IsRequired();
        e.Property(x => x.Value).HasMaxLength(1000).IsRequired();
        e.HasQueryFilter(x => true);
    }
}
