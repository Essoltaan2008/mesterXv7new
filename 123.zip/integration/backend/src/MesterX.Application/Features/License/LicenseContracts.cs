using MediatR;
using MesterX.Application.Common;
using MesterX.Domain.Enums;

namespace MesterX.Application.Features.License;

public sealed record LicenseStatusDto(
    PlanType PlanType, LicenseStatus Status,
    DateTime ActivatedAt, DateTime? ExpiresAt,
    bool SyncAddonActive, DateTime? SyncAddonExpiresAt,
    int MaxBranches, int MaxUsers, int MaxProducts,
    int CurrentBranches, int CurrentUsers, int CurrentProducts,
    string? DowngradeReason, bool IsExpired, int? DaysUntilExpiry);

public sealed record PlanDto(
    Guid Id, string Name, string NameEn, PlanType Type,
    decimal MonthlyPrice, decimal AnnualPrice,
    int MaxBranches, int MaxUsers, int MaxProducts,
    bool HasSync, bool HasAdvancedReports,
    bool HasApiAccess, bool HasWhiteLabel,
    bool HasRestaurant, bool HasRental, bool HasAI);

public sealed record ActivateLicenseRequest(string LicenseKey, string DeviceFingerprint);
public sealed record ActivateSyncAddonRequest(string SyncKey);
public sealed record ValidateDeviceRequest(string DeviceFingerprint);

public sealed record GetLicenseStatusQuery(Guid TenantId) : IRequest<Result<LicenseStatusDto>>;
public sealed record GetPlansQuery() : IRequest<Result<IReadOnlyList<PlanDto>>>;
public sealed record ActivateLicenseCommand(ActivateLicenseRequest Request, Guid TenantId) : IRequest<Result<LicenseStatusDto>>;
public sealed record ActivateSyncCommand(ActivateSyncAddonRequest Request, Guid TenantId) : IRequest<Result<LicenseStatusDto>>;
public sealed record ValidateDeviceCommand(ValidateDeviceRequest Request, Guid TenantId) : IRequest<Result<bool>>;
