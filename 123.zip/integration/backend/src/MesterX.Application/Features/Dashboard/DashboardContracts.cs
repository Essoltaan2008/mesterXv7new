using MediatR;
using MesterX.Application.Common;

namespace MesterX.Application.Features.Dashboard;

public sealed record DashboardStatsDto(
    decimal TodayRevenue, int TodayOrders,
    decimal MonthRevenue, int MonthOrders,
    int TotalCustomers, int NewThisMonth,
    int TotalProducts, int LowStockCount,
    int ActiveBranches, decimal AvgOrderValue,
    decimal GrossProfitToday,
    IReadOnlyList<DailySaleDto> WeekSales,
    IReadOnlyList<TopProductDto> TopProducts,
    IReadOnlyList<RecentOrderDto> RecentOrders);

public sealed record DailySaleDto(DateOnly Date, decimal Revenue, int Orders, decimal Profit);
public sealed record TopProductDto(Guid ProductId, string Name, int QuantitySold, decimal Revenue);
public sealed record RecentOrderDto(Guid Id, string OrderNumber, string? CustomerName, decimal Amount, string PaymentMethod, DateTime At);

public sealed record SalesReportRequest(
    DateTime FromDate, DateTime ToDate,
    Guid? BranchId = null, string GroupBy = "day");

public sealed record SalesReportDto(
    DateTime From, DateTime To,
    decimal TotalRevenue, decimal TotalVat, decimal TotalDiscount, decimal NetRevenue,
    int TotalOrders, decimal AvgOrderValue,
    IReadOnlyList<DailySaleDto> ByPeriod,
    IReadOnlyList<TopProductDto> TopProducts,
    IDictionary<string, decimal> ByPaymentMethod);

public sealed record GetDashboardQuery(Guid TenantId, Guid? BranchId) : IRequest<Result<DashboardStatsDto>>;
public sealed record GetSalesReportQuery(SalesReportRequest Request, Guid TenantId) : IRequest<Result<SalesReportDto>>;
