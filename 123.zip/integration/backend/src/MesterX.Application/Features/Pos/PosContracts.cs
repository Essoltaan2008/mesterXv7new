using MediatR;
using MesterX.Application.Common;
using MesterX.Domain.Enums;
using FluentValidation;

namespace MesterX.Application.Features.Pos;

// ── DTOs ─────────────────────────────────────────────────────────────────────
public sealed record ProductPosDto(
    Guid    Id, string Name, string? NameAr, string? Barcode, string? SKU,
    decimal SalePrice, bool HasVat, decimal VatRate,
    string? ImageUrl,  string? CategoryName,
    decimal Stock, decimal Reserved, decimal Available, bool IsLowStock);

public sealed record SaleLineRequest(
    Guid    ProductId,
    decimal Quantity,
    decimal UnitPrice,
    decimal DiscountAmount = 0);

public sealed record CreateSaleRequest(
    Guid               BranchId,
    Guid?              CustomerId,
    PaymentMethod      PaymentMethod,
    IList<SaleLineRequest> Items,
    decimal            DiscountAmount        = 0,
    DiscountType       DiscountType          = DiscountType.Amount,
    decimal            LoyaltyPointsToRedeem = 0,
    decimal            AmountPaid            = 0,
    string?            ClientIdempotencyKey  = null,
    bool               IsOffline             = false,
    string?            Notes                 = null);

public sealed record SaleOrderDto(
    Guid          Id, string OrderNumber,
    Guid          BranchId,  string BranchName,
    Guid?         CustomerId, string? CustomerName,
    string        CashierName,
    SaleStatus    Status, PaymentMethod PaymentMethod,
    decimal       SubTotal, decimal VatAmount, decimal DiscountAmount,
    decimal       TotalAmount, decimal AmountPaid, decimal ChangeGiven,
    decimal       LoyaltyEarned, bool IsOffline, DateTime CreatedAt,
    IList<SaleLineDto>  Items,
    IList<PaymentDto>   Payments);

public sealed record SaleLineDto(
    Guid ProductId, string ProductName, string? Barcode,
    decimal Qty, decimal UnitPrice, decimal VatRate, decimal VatAmt,
    decimal Discount, decimal LineTotal);

public sealed record PaymentDto(
    Guid Id, PaymentMethod Method, decimal Amount,
    PaymentStatus Status, string? Reference, DateTime? PaidAt);

public sealed record RefundRequest(
    decimal RefundAmount, string? Reason,
    PaymentMethod RefundMethod = PaymentMethod.Cash);

// ── Commands & Queries ───────────────────────────────────────────────────────
public sealed record GetPosProductsQuery(Guid BranchId, string? Search, Guid TenantId)
    : IRequest<Result<IReadOnlyList<ProductPosDto>>>;

public sealed record GetByBarcodeQuery(string Barcode, Guid BranchId, Guid TenantId)
    : IRequest<Result<ProductPosDto>>;

public sealed record CreateSaleCommand(CreateSaleRequest Request, Guid TenantId, Guid CashierId)
    : IRequest<Result<SaleOrderDto>>;

public sealed record GetSalesQuery(
    Guid TenantId, Guid BranchId,
    DateTime? From, DateTime? To, int Page, int PageSize)
    : IRequest<Result<PagedResult<SaleOrderDto>>>;

public sealed record GetSaleByIdQuery(Guid SaleId, Guid TenantId)
    : IRequest<Result<SaleOrderDto>>;

public sealed record RefundSaleCommand(Guid SaleId, RefundRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<SaleOrderDto>>;

// ── Validators ────────────────────────────────────────────────────────────────
public sealed class CreateSaleCommandValidator : AbstractValidator<CreateSaleCommand>
{
    public CreateSaleCommandValidator()
    {
        RuleFor(x => x.Request.BranchId).NotEmpty().WithMessage("الفرع مطلوب");
        RuleFor(x => x.Request.Items)
            .NotEmpty().WithMessage("السلة فارغة")
            .Must(i => i.All(l => l.Quantity > 0)).WithMessage("الكميات يجب أن تكون أكبر من صفر");
        RuleFor(x => x.Request.AmountPaid)
            .GreaterThanOrEqualTo(0).WithMessage("المبلغ المدفوع لا يمكن أن يكون سالباً");
    }
}
