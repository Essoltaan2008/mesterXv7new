using FluentValidation;
using MediatR;
using MesterX.Application.Common;
using MesterX.Domain.Enums;

namespace MesterX.Application.Features.Inventory;

public sealed record ProductDto(
    Guid Id, string Name, string? NameAr, string? Description,
    string? Barcode, string? SKU, ProductType Type, ProductUnit Unit,
    decimal CostPrice, decimal SalePrice, decimal? WholesalePrice, decimal? MinSalePrice,
    bool HasVat, decimal VatRate, string? ImageUrl,
    bool IsActive, bool IsAvailableOnline, bool TrackInventory, int LowStockThreshold,
    string? CategoryName, Guid? CategoryId, decimal? CurrentStock);

public sealed record CreateProductRequest(
    string Name, string? NameAr, string? Description,
    string? Barcode, string? SKU, Guid? CategoryId,
    ProductType Type  = ProductType.Physical,
    ProductUnit Unit  = ProductUnit.Piece,
    decimal CostPrice = 0, decimal SalePrice = 0,
    decimal? WholesalePrice = null, decimal? MinSalePrice = null,
    bool HasVat = true, string? ImageUrl = null,
    bool TrackInventory = true, int LowStockThreshold = 5,
    decimal? InitialStock = null, Guid? BranchId = null);

public sealed record UpdateProductRequest(
    string Name, string? NameAr, string? Description,
    string? Barcode, string? SKU, Guid? CategoryId,
    decimal CostPrice, decimal SalePrice,
    decimal? WholesalePrice, decimal? MinSalePrice,
    bool HasVat, string? ImageUrl,
    bool IsActive, bool IsAvailableOnline,
    bool TrackInventory, int LowStockThreshold,
    decimal? ReorderPoint, decimal? ReorderQuantity);

public sealed record StockItemDto(
    Guid ProductId, string ProductName, string? Barcode, string? SKU,
    Guid BranchId, string BranchName,
    decimal Quantity, decimal Reserved, decimal Available,
    decimal? LastCostPrice, bool IsLowStock, DateTime? LastCountedAt);

public sealed record StockAdjustRequest(
    Guid ProductId, Guid BranchId, decimal Quantity,
    StockMovementType Type, string? Notes, string? Reference);

public sealed record StockTransferRequest(
    Guid ProductId, Guid FromBranchId, Guid ToBranchId,
    decimal Quantity, string? Notes);

// Queries
public sealed record GetProductsQuery(Guid TenantId, int Page, int PageSize, string? Search, Guid? CategoryId)
    : IRequest<Result<PagedResult<ProductDto>>>;

public sealed record GetProductQuery(Guid Id, Guid TenantId)
    : IRequest<Result<ProductDto>>;

// Commands
public sealed record CreateProductCommand(CreateProductRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<ProductDto>>;

public sealed record UpdateProductCommand(Guid Id, UpdateProductRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<ProductDto>>;

public sealed record DeleteProductCommand(Guid Id, Guid TenantId, Guid UserId)
    : IRequest<Result<string>>;

public sealed record GetStockQuery(Guid TenantId, Guid? BranchId, bool LowOnly)
    : IRequest<Result<IReadOnlyList<StockItemDto>>>;

public sealed record AdjustStockCommand(StockAdjustRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<StockItemDto>>;

public sealed record TransferStockCommand(StockTransferRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<StockItemDto>>;

// Validators
public sealed class CreateProductCommandValidator : AbstractValidator<CreateProductCommand>
{
    public CreateProductCommandValidator()
    {
        RuleFor(x => x.Request.Name).NotEmpty().WithMessage("اسم المنتج مطلوب").MaximumLength(300);
        RuleFor(x => x.Request.SalePrice).GreaterThanOrEqualTo(0).WithMessage("سعر البيع لا يمكن أن يكون سالباً");
        RuleFor(x => x.Request.CostPrice).GreaterThanOrEqualTo(0).WithMessage("سعر التكلفة لا يمكن أن يكون سالباً");
        RuleFor(x => x.Request.LowStockThreshold).GreaterThanOrEqualTo(0);
    }
}

public sealed class AdjustStockCommandValidator : AbstractValidator<AdjustStockCommand>
{
    public AdjustStockCommandValidator()
    {
        RuleFor(x => x.Request.ProductId).NotEmpty().WithMessage("المنتج مطلوب");
        RuleFor(x => x.Request.BranchId).NotEmpty().WithMessage("الفرع مطلوب");
        RuleFor(x => x.Request.Quantity).NotEqual(0).WithMessage("الكمية لا يمكن أن تكون صفراً");
    }
}
