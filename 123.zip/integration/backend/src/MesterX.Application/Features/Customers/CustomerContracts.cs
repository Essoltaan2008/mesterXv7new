using FluentValidation;
using MediatR;
using MesterX.Application.Common;
using MesterX.Domain.Enums;

namespace MesterX.Application.Features.Customers;

public sealed record CustomerDto(
    Guid    Id, string Name, string? Phone, string? Email,
    string? City, CustomerSegment Segment,
    decimal LoyaltyPoints, decimal TotalPurchases,
    int     TotalOrders, DateTime? LastPurchaseAt,
    bool    IsActive, DateTime CreatedAt);

public sealed record CreateCustomerRequest(
    string   Name,
    string?  Phone,
    string?  Email,
    string?  Address,
    string?  City,
    Gender   Gender     = Gender.Unknown,
    DateOnly? DateOfBirth = null);

public sealed record UpdateCustomerRequest(
    string  Name, string? Phone, string? Email,
    string? Address, string? City, bool IsActive, string? Notes);

public sealed record AddLoyaltyPointsRequest(int Points, string? Reason);

// Queries
public sealed record GetCustomersQuery(Guid TenantId, string? Search, int Page, int PageSize)
    : IRequest<Result<PagedResult<CustomerDto>>>;

public sealed record GetCustomerQuery(Guid Id, Guid TenantId)
    : IRequest<Result<CustomerDto>>;

public sealed record FindByPhoneQuery(string Phone, Guid TenantId)
    : IRequest<Result<CustomerDto>>;

// Commands
public sealed record CreateCustomerCommand(CreateCustomerRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<CustomerDto>>;

public sealed record UpdateCustomerCommand(Guid Id, UpdateCustomerRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<CustomerDto>>;

public sealed record AddLoyaltyCommand(Guid CustomerId, AddLoyaltyPointsRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<string>>;

// Validators
public sealed class CreateCustomerCommandValidator : AbstractValidator<CreateCustomerCommand>
{
    public CreateCustomerCommandValidator()
    {
        RuleFor(x => x.Request.Name).NotEmpty().WithMessage("اسم العميل مطلوب").MaximumLength(200);
        RuleFor(x => x.Request.Phone)
            .Matches(@"^01[0-9]{9}$")
            .When(x => !string.IsNullOrEmpty(x.Request.Phone))
            .WithMessage("رقم الموبايل غير صحيح (مثال: 01012345678)");
        RuleFor(x => x.Request.Email)
            .EmailAddress().When(x => !string.IsNullOrEmpty(x.Request.Email))
            .WithMessage("بريد إلكتروني غير صحيح");
    }
}
