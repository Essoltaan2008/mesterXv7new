using FluentValidation;
using MediatR;
using MesterX.Application.Common;
using MesterX.Domain.Enums;

namespace MesterX.Application.Features.Auth;

// ════════════════════════════════════════════════════════════════════════════
// Auth Request / Response DTOs
// ════════════════════════════════════════════════════════════════════════════

public sealed record LoginRequest(
    string?  Username,
    string?  Email,
    string   Password,
    string?  MfaCode    = null,
    bool     RememberMe = false);

public sealed record RegisterRequest(
    string  FirstName,
    string  LastName,
    string  Username,
    string  Email,
    string  Password,
    string? Phone       = null,
    string? CompanyName = null,
    string  Language    = "ar");

public sealed record RefreshTokenRequest(string RefreshToken);
public sealed record ChangePasswordRequest(string OldPassword, string NewPassword, string ConfirmPassword);
public sealed record MfaVerifyRequest(string Code);

public sealed record UserDto(
    Guid      Id,
    string    Username,
    string    Email,
    string    FirstName,
    string    LastName,
    string    FullName,
    string?   Phone,
    string?   AvatarUrl,
    UserRole  Role,
    Guid?     BranchId,
    string?   BranchName,
    bool      IsActive,
    bool      TwoFactorEnabled,
    DateTime? LastLoginAt,
    DateTime  CreatedAt,
    string    Language = "ar");

public sealed record AuthResponse(
    string    AccessToken,
    string    RefreshToken,
    int       ExpiresInSeconds,
    UserDto   User,
    bool      RequiresMfa = false);

public sealed record MfaSetupResponse(
    string                Secret,
    string                QrCodeUrl,
    IReadOnlyList<string> BackupCodes);

// ── Commands ─────────────────────────────────────────────────────────────────

public sealed record LoginCommand(LoginRequest Request, string Ip, string UserAgent)
    : IRequest<Result<AuthResponse>>;

public sealed record RegisterCommand(RegisterRequest Request)
    : IRequest<Result<AuthResponse>>;

public sealed record RefreshTokenCommand(string RawToken, string Ip)
    : IRequest<Result<AuthResponse>>;

public sealed record LogoutCommand(string RawToken, Guid? UserId, Guid? TenantId)
    : IRequest<Result<string>>;

public sealed record ChangePasswordCommand(ChangePasswordRequest Request, Guid UserId, Guid TenantId)
    : IRequest<Result<string>>;

public sealed record SetupMfaCommand(Guid UserId, Guid TenantId)
    : IRequest<Result<MfaSetupResponse>>;

public sealed record VerifyMfaCommand(string Code, Guid UserId, Guid TenantId, bool Disable = false)
    : IRequest<Result<string>>;

// ── Queries ───────────────────────────────────────────────────────────────────

public sealed record GetCurrentUserQuery(Guid UserId, Guid TenantId)
    : IRequest<Result<UserDto>>;

// ── Validators ────────────────────────────────────────────────────────────────

public sealed class LoginCommandValidator : AbstractValidator<LoginCommand>
{
    public LoginCommandValidator()
    {
        RuleFor(x => x.Request).NotNull();
        RuleFor(x => x.Request.Password)
            .NotEmpty().WithMessage("كلمة المرور مطلوبة")
            .MinimumLength(6).WithMessage("كلمة المرور قصيرة جداً");
        RuleFor(x => x.Request)
            .Must(r => !string.IsNullOrWhiteSpace(r.Username) || !string.IsNullOrWhiteSpace(r.Email))
            .WithMessage("يجب إدخال اسم المستخدم أو البريد الإلكتروني");
    }
}

public sealed class RegisterCommandValidator : AbstractValidator<RegisterCommand>
{
    public RegisterCommandValidator()
    {
        RuleFor(x => x.Request.FirstName).NotEmpty().WithMessage("الاسم الأول مطلوب").MaximumLength(100);
        RuleFor(x => x.Request.LastName).NotEmpty().WithMessage("اسم العائلة مطلوب").MaximumLength(100);
        RuleFor(x => x.Request.Username)
            .NotEmpty().WithMessage("اسم المستخدم مطلوب")
            .MinimumLength(3).WithMessage("اسم المستخدم 3 أحرف على الأقل")
            .MaximumLength(50)
            .Matches(@"^[a-zA-Z0-9_\.]+$").WithMessage("اسم المستخدم يحتوي على أحرف غير مسموحة");
        RuleFor(x => x.Request.Email)
            .NotEmpty().WithMessage("البريد الإلكتروني مطلوب")
            .EmailAddress().WithMessage("بريد إلكتروني غير صحيح");
        RuleFor(x => x.Request.Password)
            .NotEmpty().WithMessage("كلمة المرور مطلوبة")
            .MinimumLength(8).WithMessage("كلمة المرور 8 أحرف على الأقل")
            .Matches("[A-Z]").WithMessage("يجب أن تحتوي على حرف كبير")
            .Matches("[0-9]").WithMessage("يجب أن تحتوي على رقم")
            .Matches("[^a-zA-Z0-9]").WithMessage("يجب أن تحتوي على رمز خاص");
    }
}

public sealed class ChangePasswordCommandValidator : AbstractValidator<ChangePasswordCommand>
{
    public ChangePasswordCommandValidator()
    {
        RuleFor(x => x.Request.OldPassword).NotEmpty().WithMessage("كلمة المرور الحالية مطلوبة");
        RuleFor(x => x.Request.NewPassword)
            .NotEmpty().WithMessage("كلمة المرور الجديدة مطلوبة")
            .MinimumLength(8).WithMessage("كلمة المرور 8 أحرف على الأقل")
            .Matches("[A-Z]").WithMessage("يجب أن تحتوي على حرف كبير")
            .Matches("[0-9]").WithMessage("يجب أن تحتوي على رقم")
            .Matches("[^a-zA-Z0-9]").WithMessage("يجب أن تحتوي على رمز خاص");
        RuleFor(x => x.Request)
            .Must(r => r.NewPassword == r.ConfirmPassword)
            .WithMessage("كلمتا المرور غير متطابقتين");
    }
}
