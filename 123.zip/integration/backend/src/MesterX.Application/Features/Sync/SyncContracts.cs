using MediatR;
using MesterX.Application.Common;
using MesterX.Domain.Enums;

namespace MesterX.Application.Features.Sync;

public sealed record SyncItemRequest(
    string IdempotencyKey, SyncEntityType EntityType,
    SyncOperation Operation, object Payload,
    int ClientVersion, ConflictStrategy Strategy = ConflictStrategy.ServerWins);

public sealed record SyncPushRequest(
    IList<SyncItemRequest> Items, string ClientVersion, string DeviceFingerprint);

public sealed record SyncItemResult(
    string IdempotencyKey, SyncStatus Status,
    string? Message, object? ServerData = null);

public sealed record SyncPushResult(
    int Total, int Processed, int Conflicts, int Failed,
    IReadOnlyList<SyncItemResult> Results);

public sealed record SyncPullResult(
    IReadOnlyList<object> Products,
    IReadOnlyList<object> Customers,
    IReadOnlyList<object> SaleOrders,
    DateTime ServerTime, bool HasMore, string? NextCursor);

public sealed record PushSyncCommand(SyncPushRequest Request, Guid TenantId, Guid UserId)
    : IRequest<Result<SyncPushResult>>;

public sealed record PullSyncQuery(Guid TenantId, Guid BranchId, DateTime Since, int MaxItems = 500)
    : IRequest<Result<SyncPullResult>>;
