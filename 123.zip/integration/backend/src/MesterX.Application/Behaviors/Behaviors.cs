// Pipeline behaviors are defined in MesterX.Application.Common.ApplicationBase
// This file re-exports them under the Behaviors namespace for DI registration
using MesterX.Application.Common;

namespace MesterX.Application.Behaviors;

// Re-export for clean registration in Program.cs
public sealed class AppValidationBehavior<TRequest, TResponse>
    : ValidationBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    public AppValidationBehavior(
        IEnumerable<FluentValidation.IValidator<TRequest>> validators)
        : base(validators) { }
}
