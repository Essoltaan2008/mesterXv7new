using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MediatR;
using MesterX.Application.Common;
using MesterX.Application.Features.Auth;
using MesterX.Application.Features.Customers;
using MesterX.Application.Features.Inventory;
using MesterX.Domain.Entities.Auth;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using SecurityHelper = MesterX.Infrastructure.Services.SecurityHelper;

namespace MesterX.Application.Services;

// ════════════════════════════════════════════════════════════════════════════
// AuthHandler — handles ALL auth MediatR commands/queries
// Single class owns all auth logic; injected via MediatR handler registration
// ════════════════════════════════════════════════════════════════════════════
public sealed class AuthHandler :
    IRequestHandler<LoginCommand,            Result<AuthResponse>>,
    IRequestHandler<RegisterCommand,          Result<AuthResponse>>,
    IRequestHandler<RefreshTokenCommand,      Result<AuthResponse>>,
    IRequestHandler<GetCurrentUserQuery,      Result<UserDto>>
{
    private readonly IUnitOfWork              _uow;
    private readonly IConfiguration           _cfg;
    private readonly IAuditService            _audit;
    private readonly ITotpService             _totp;
    private readonly ILogger<AuthHandler>     _log;

    private const int MAX_FAILED    = 5;
    private const int LOCKOUT_MIN   = 15;
    private const int JWT_MIN       = 60;
    private const int REFRESH_DAYS  = 7;

    public AuthHandler(IUnitOfWork uow, IConfiguration cfg,
        IAuditService audit, ITotpService totp, ILogger<AuthHandler> log)
    { _uow = uow; _cfg = cfg; _audit = audit; _totp = totp; _log = log; }

    // ── LOGIN ──────────────────────────────────────────────────────────────
    public async Task<Result<AuthResponse>> Handle(LoginCommand cmd, CancellationToken ct)
    {
        var r = cmd.Request;
        var user = await _uow.Users.Query()
            .Include(u => u.Branch)
            .FirstOrDefaultAsync(u =>
                (u.Username == r.Username || u.Email == r.Email) && !u.IsDeleted, ct);

        // Same message for "not found" and "wrong password" — prevents enumeration
        const string BAD = "بيانات الدخول غير صحيحة";

        if (user == null)
        {
            await _audit.LogAsync(new AuditEntry(Guid.Empty, null, AuditAction.LoginFailed,
                "User", ErrorMessage: $"not found: {r.Email ?? r.Username}"), ct);
            return Result<AuthResponse>.Fail(BAD, "INVALID_CREDENTIALS");
        }

        if (user.IsLockedOut)
        {
            var min = (int)Math.Ceiling((user.LockoutEnd!.Value - DateTime.UtcNow).TotalMinutes);
            return Result<AuthResponse>.Fail(
                $"الحساب مقفول مؤقتاً. حاول بعد {min} دقيقة", "ACCOUNT_LOCKED");
        }

        if (!SecurityHelper.VerifyPassword(r.Password, user.PasswordHash))
        {
            user.FailedLoginAttempts++;
            if (user.FailedLoginAttempts >= MAX_FAILED)
            {
                user.LockoutEnd = DateTime.UtcNow.AddMinutes(LOCKOUT_MIN);
                _log.LogWarning("Account locked after {N} attempts: {Email}",
                    MAX_FAILED, user.Email);
            }
            await _uow.SaveChangesAsync(ct);
            await _audit.LogAsync(new AuditEntry(user.TenantId, user.Id,
                AuditAction.LoginFailed, "User", user.Id,
                ErrorMessage: $"attempt {user.FailedLoginAttempts}"), ct);
            return Result<AuthResponse>.Fail(BAD, "INVALID_CREDENTIALS");
        }

        if (!user.IsActive)
            return Result<AuthResponse>.Fail("الحساب معطّل. تواصل مع المدير", "ACCOUNT_DISABLED");

        // MFA gate — return partial response if enabled and code not provided
        if (user.TwoFactorEnabled)
        {
            if (string.IsNullOrWhiteSpace(r.MfaCode))
                return Result<AuthResponse>.Ok(
                    new AuthResponse("", "", 0, MapUser(user), RequiresMfa: true));

            if (!_totp.ValidateCode(user.TotpSecret!, r.MfaCode))
                return Result<AuthResponse>.Fail("كود التحقق الثنائي غير صحيح", "INVALID_MFA");
        }

        // Reset lockout, update last login
        user.FailedLoginAttempts = 0;
        user.LockoutEnd          = null;
        user.LastLoginAt         = DateTime.UtcNow;
        user.LastLoginIp         = cmd.Ip;
        user.LastLoginDevice     = cmd.UserAgent[..Math.Min(cmd.UserAgent.Length, 250)];

        // Generate token pair
        var jwt = BuildJwt(user);
        var (raw, hash, salt) = SecurityHelper.GenerateRefreshToken();

        await _uow.RefreshTokens.AddAsync(new RefreshToken
        {
            Id        = Guid.NewGuid(), TenantId  = user.TenantId,
            UserId    = user.Id,        TokenHash = hash,
            Salt      = salt,           IpAddress = cmd.Ip,
            DeviceInfo= cmd.UserAgent[..Math.Min(cmd.UserAgent.Length, 250)],
            ExpiresAt = DateTime.UtcNow.AddDays(REFRESH_DAYS),
        }, ct);

        await _uow.SaveChangesAsync(ct);
        await _audit.LogAsync(new AuditEntry(user.TenantId, user.Id, AuditAction.Login, "User", user.Id), ct);

        return Result<AuthResponse>.Ok(
            new AuthResponse(jwt, raw, JWT_MIN * 60, MapUser(user)));
    }

    // ── REGISTER ────────────────────────────────────────────────────────────
    public async Task<Result<AuthResponse>> Handle(RegisterCommand cmd, CancellationToken ct)
    {
        var r = cmd.Request;

        var exists = await _uow.Users.AnyAsync(
            u => u.Username == r.Username || u.Email == r.Email, ct);
        if (exists)
            return Result<AuthResponse>.Fail(
                "البريد الإلكتروني أو اسم المستخدم موجود بالفعل", "DUPLICATE_USER");

        await _uow.BeginTransactionAsync(ct);
        try
        {
            var tenantId = Guid.NewGuid();
            var branchId = Guid.NewGuid();

            var tenant = new Tenant
            {
                Id = tenantId, TenantId = tenantId,
                Name = r.CompanyName ?? $"شركة {r.FirstName}",
                Slug = SlugFrom(r.Username),
                Currency = "EGP", VatRate = 0.14m, Language = r.Language,
                IsActive = true, Status = TenantStatus.Trial,
                Plan = PlanType.Trial, TrialEndsAt = DateTime.UtcNow.AddDays(14),
                ActiveModules = TenantModules.POS | TenantModules.Inventory,
            };
            await _uow.Tenants.AddAsync(tenant, ct);

            var branch = new Branch
            {
                Id = branchId, TenantId = tenantId,
                Name = "الفرع الرئيسي", IsMain = true, IsActive = true,
            };
            await _uow.Branches.AddAsync(branch, ct);

            var user = new ApplicationUser
            {
                Id = Guid.NewGuid(), TenantId = tenantId, BranchId = branchId,
                Username = r.Username, Email = r.Email,
                PasswordHash = SecurityHelper.HashPassword(r.Password),
                FirstName = r.FirstName, LastName = r.LastName,
                Phone = r.Phone, Role = UserRole.CompanyOwner,
                IsActive = true, Language = r.Language,
            };
            await _uow.Users.AddAsync(user, ct);
            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);

            _log.LogInformation("✅ New tenant registered: {Slug}", tenant.Slug);
            return await Handle(new LoginCommand(
                new LoginRequest(r.Username, r.Email, r.Password), "register", "system"), ct);
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync(ct);
            _log.LogError(ex, "Registration failed: {Email}", r.Email);
            return Result<AuthResponse>.Fail("فشل التسجيل. حاول مرة أخرى", "REGISTRATION_FAILED");
        }
    }

    // ── REFRESH TOKEN ────────────────────────────────────────────────────────
    public async Task<Result<AuthResponse>> Handle(RefreshTokenCommand cmd, CancellationToken ct)
    {
        var candidates = await _uow.RefreshTokens.Query()
            .Include(r => r.User).ThenInclude(u => u.Branch)
            .Where(r => !r.IsRevoked && r.ExpiresAt > DateTime.UtcNow)
            .ToListAsync(ct);

        var rt = candidates.FirstOrDefault(r =>
            SecurityHelper.VerifyRefreshToken(cmd.RawToken, r.TokenHash, r.Salt));

        if (rt == null)
            return Result<AuthResponse>.Fail("رمز التجديد غير صالح أو منتهي", "INVALID_REFRESH");

        // Rotate: revoke old, issue new
        rt.IsRevoked = true; rt.RevokedAt = DateTime.UtcNow;

        var (raw, hash, salt) = SecurityHelper.GenerateRefreshToken();
        await _uow.RefreshTokens.AddAsync(new RefreshToken
        {
            Id = Guid.NewGuid(), TenantId = rt.TenantId, UserId = rt.UserId,
            TokenHash = hash, Salt = salt, IpAddress = cmd.Ip,
            DeviceInfo = rt.DeviceInfo, ExpiresAt = DateTime.UtcNow.AddDays(REFRESH_DAYS),
        }, ct);

        await _uow.SaveChangesAsync(ct);
        return Result<AuthResponse>.Ok(
            new AuthResponse(BuildJwt(rt.User), raw, JWT_MIN * 60, MapUser(rt.User)));
    }

    // ── GET CURRENT USER ─────────────────────────────────────────────────────
    public async Task<Result<UserDto>> Handle(GetCurrentUserQuery q, CancellationToken ct)
    {
        var user = await _uow.Users.Query()
            .Include(u => u.Branch)
            .FirstOrDefaultAsync(u => u.Id == q.UserId && u.TenantId == q.TenantId, ct);
        return user == null
            ? Result<UserDto>.Fail("المستخدم غير موجود", "NOT_FOUND")
            : Result<UserDto>.Ok(MapUser(user));
    }

    // ── HELPERS ──────────────────────────────────────────────────────────────
    private string BuildJwt(ApplicationUser u)
    {
        var secret  = _cfg["Jwt:Secret"]!;
        var expiry  = int.TryParse(_cfg["Jwt:ExpiryMinutes"], out var e) ? e : JWT_MIN;
        var key     = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
        var creds   = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub,   u.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, u.Email),
            new Claim(JwtRegisteredClaimNames.Jti,   Guid.NewGuid().ToString()),
            new Claim("tenant_id",  u.TenantId.ToString()),
            new Claim("user_id",    u.Id.ToString()),
            new Claim("branch_id",  u.BranchId?.ToString() ?? ""),
            new Claim("role",       ((int)u.Role).ToString()),
            new Claim(ClaimTypes.Role, u.Role.ToString()),
            new Claim("first_name", u.FirstName),
            new Claim("lang",       u.Language),
        };

        var token = new JwtSecurityToken(
            _cfg["Jwt:Issuer"]   ?? "MesterX",
            _cfg["Jwt:Audience"] ?? "MesterXClient",
            claims, expires: DateTime.UtcNow.AddMinutes(expiry),
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static UserDto MapUser(ApplicationUser u) => new(
        u.Id, u.Username, u.Email, u.FirstName, u.LastName, $"{u.FirstName} {u.LastName}",
        u.Phone, u.AvatarUrl, u.Role, u.BranchId, u.Branch?.Name,
        u.IsActive, u.TwoFactorEnabled, u.LastLoginAt, u.CreatedAt, u.Language);

    private static string SlugFrom(string s) =>
        s.ToLowerInvariant().Replace(" ", "-").Replace("@", "").Replace(".", "-")[..Math.Min(s.Length, 80)];
}

// ── Additional handlers for commands returning Result<string> ────────────────
public sealed class LogoutHandler : IRequestHandler<LogoutCommand, Result<string>>
{
    private readonly IUnitOfWork          _uow;
    private readonly IAuditService        _audit;

    public LogoutHandler(IUnitOfWork uow, IAuditService audit) { _uow = uow; _audit = audit; }

    public async Task<Result<string>> Handle(LogoutCommand cmd, CancellationToken ct)
    {
        var candidates = await _uow.RefreshTokens.Query()
            .Where(r => !r.IsRevoked).ToListAsync(ct);

        var rt = candidates.FirstOrDefault(r =>
            SecurityHelper.VerifyRefreshToken(cmd.RawToken, r.TokenHash, r.Salt));

        if (rt is not null) { rt.IsRevoked = true; rt.RevokedAt = DateTime.UtcNow; }

        if (cmd.UserId.HasValue && cmd.TenantId.HasValue)
            await _audit.LogAsync(new AuditEntry(
                cmd.TenantId.Value, cmd.UserId, AuditAction.Logout, "User", cmd.UserId), ct);

        await _uow.SaveChangesAsync(ct);
        return Result<string>.Ok("تم تسجيل الخروج");
    }
}

public sealed class ChangePasswordHandler : IRequestHandler<ChangePasswordCommand, Result<string>>
{
    private readonly IUnitOfWork     _uow;
    private readonly IAuditService   _audit;

    public ChangePasswordHandler(IUnitOfWork uow, IAuditService audit) { _uow = uow; _audit = audit; }

    public async Task<Result<string>> Handle(ChangePasswordCommand cmd, CancellationToken ct)
    {
        var user = await _uow.Users.Query()
            .FirstOrDefaultAsync(u => u.Id == cmd.UserId && u.TenantId == cmd.TenantId, ct);
        if (user is null) return Result<string>.Fail("المستخدم غير موجود", "NOT_FOUND");
        if (!SecurityHelper.VerifyPassword(cmd.Request.OldPassword, user.PasswordHash))
            return Result<string>.Fail("كلمة المرور الحالية غير صحيحة", "INVALID_PASSWORD");

        user.PasswordHash       = SecurityHelper.HashPassword(cmd.Request.NewPassword);
        user.PasswordChangedAt  = DateTime.UtcNow;
        user.MustChangePassword = false;

        // Revoke all refresh tokens for security
        var tokens = await _uow.RefreshTokens.FindAsync(r => r.UserId == cmd.UserId && !r.IsRevoked, ct);
        foreach (var t in tokens) { t.IsRevoked = true; t.RevokedAt = DateTime.UtcNow; }

        await _uow.SaveChangesAsync(ct);
        await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId, AuditAction.PasswordChange, "User", cmd.UserId), ct);
        return Result<string>.Ok("تم تغيير كلمة المرور. سجّل دخولك مجدداً");
    }
}

public sealed class MfaSetupHandler : IRequestHandler<SetupMfaCommand, Result<MfaSetupResponse>>
{
    private readonly IUnitOfWork   _uow;
    private readonly ITotpService  _totp;
    private readonly IConfiguration _cfg;

    public MfaSetupHandler(IUnitOfWork uow, ITotpService totp,
        Microsoft.Extensions.Configuration.IConfiguration cfg)
    { _uow = uow; _totp = totp; _cfg = cfg; }

    public async Task<Result<MfaSetupResponse>> Handle(SetupMfaCommand cmd, CancellationToken ct)
    {
        var user = await _uow.Users.Query()
            .FirstOrDefaultAsync(u => u.Id == cmd.UserId && u.TenantId == cmd.TenantId, ct);
        if (user is null) return Result<MfaSetupResponse>.Fail("المستخدم غير موجود");
        if (user.TwoFactorEnabled)
            return Result<MfaSetupResponse>.Fail("التحقق الثنائي مفعّل بالفعل");

        var issuer = _cfg["Mfa:Issuer"] ?? "MesterX";
        var (secret, qrUrl) = _totp.GenerateSecret(user.Email, issuer);
        var backupCodes      = Enumerable.Range(0, 8).Select(_ => _totp.GenerateBackupCode()).ToList();

        user.TotpSecret       = secret;
        user.BackupCodes      = System.Text.Json.JsonSerializer.Serialize(
            backupCodes.Select(SecurityHelper.HashSha256).ToList());
        user.TwoFactorEnabled = false; // confirm via VerifyMfaCommand

        await _uow.SaveChangesAsync(ct);
        return Result<MfaSetupResponse>.Ok(new MfaSetupResponse(secret, qrUrl, backupCodes));
    }
}

public sealed class VerifyMfaHandler : IRequestHandler<VerifyMfaCommand, Result<string>>
{
    private readonly IUnitOfWork  _uow;
    private readonly ITotpService _totp;
    private readonly IAuditService _audit;

    public VerifyMfaHandler(IUnitOfWork uow, ITotpService totp, IAuditService audit)
    { _uow = uow; _totp = totp; _audit = audit; }

    public async Task<Result<string>> Handle(VerifyMfaCommand cmd, CancellationToken ct)
    {
        var user = await _uow.Users.Query()
            .FirstOrDefaultAsync(u => u.Id == cmd.UserId && u.TenantId == cmd.TenantId, ct);
        if (user is null) return Result<string>.Fail("المستخدم غير موجود");
        if (user.TotpSecret is null) return Result<string>.Fail("لم يتم إعداد MFA");

        if (!_totp.ValidateCode(user.TotpSecret, cmd.Code))
            return Result<string>.Fail("الكود غير صحيح", "INVALID_MFA_CODE");

        if (cmd.Disable)
        {
            user.TwoFactorEnabled = false; user.TotpSecret = null; user.BackupCodes = null;
            await _uow.SaveChangesAsync(ct);
            await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId, AuditAction.MfaDisabled, "User", cmd.UserId), ct);
            return Result<string>.Ok("تم تعطيل التحقق الثنائي");
        }

        user.TwoFactorEnabled = true;
        await _uow.SaveChangesAsync(ct);
        await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId, AuditAction.MfaEnabled, "User", cmd.UserId), ct);
        return Result<string>.Ok("تم تفعيل التحقق الثنائي");
    }
}

public sealed class AddLoyaltyHandler : IRequestHandler<AddLoyaltyCommand, Result<string>>
{
    private readonly IUnitOfWork _uow;
    public AddLoyaltyHandler(IUnitOfWork uow) => _uow = uow;

    public async Task<Result<string>> Handle(AddLoyaltyCommand cmd, CancellationToken ct)
    {
        var c = await _uow.Customers.FirstOrDefaultAsync(
            x => x.Id == cmd.CustomerId && x.TenantId == cmd.TenantId && !x.IsDeleted, ct);
        if (c is null) return Result<string>.Fail("العميل غير موجود", "NOT_FOUND");
        c.LoyaltyPoints += cmd.Request.Points;
        await _uow.SaveChangesAsync(ct);
        return Result<string>.Ok($"تم إضافة {cmd.Request.Points} نقطة");
    }
}

public sealed class DeleteProductHandler : IRequestHandler<DeleteProductCommand, Result<string>>
{
    private readonly IUnitOfWork  _uow;
    private readonly IAuditService _audit;
    public DeleteProductHandler(IUnitOfWork uow, IAuditService audit) { _uow = uow; _audit = audit; }

    public async Task<Result<string>> Handle(DeleteProductCommand cmd, CancellationToken ct)
    {
        var p = await _uow.Products.FirstOrDefaultAsync(
            x => x.Id == cmd.Id && x.TenantId == cmd.TenantId && !x.IsDeleted, ct);
        if (p is null) return Result<string>.Fail("المنتج غير موجود", "NOT_FOUND");
        p.IsDeleted = true; p.DeletedAt = DateTime.UtcNow; p.DeletedBy = cmd.UserId;
        await _uow.SaveChangesAsync(ct);
        await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId, AuditAction.Delete, "Product", cmd.Id), ct);
        return Result<string>.Ok("تم حذف المنتج");
    }
}
