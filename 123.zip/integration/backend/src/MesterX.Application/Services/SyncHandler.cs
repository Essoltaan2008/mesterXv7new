using System.Text.Json;
using MediatR;
using MesterX.Application.Common;
using MesterX.Application.Features.Sync;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public sealed class SyncHandler :
    IRequestHandler<PushSyncCommand, Result<SyncPushResult>>,
    IRequestHandler<PullSyncQuery,   Result<SyncPullResult>>
{
    private readonly IUnitOfWork        _uow;
    private readonly IAuditService      _audit;
    private readonly ICacheService      _cache;
    private readonly ILogger<SyncHandler>_log;
    private const int BATCH = 100;

    public SyncHandler(IUnitOfWork uow, IAuditService audit, ICacheService cache, ILogger<SyncHandler> log)
    { _uow = uow; _audit = audit; _cache = cache; _log = log; }

    public async Task<Result<SyncPushResult>> Handle(PushSyncCommand cmd, CancellationToken ct)
    {
        // Verify license allows sync
        var lic = await _uow.Licenses.FirstOrDefaultAsync(
            l => l.TenantId == cmd.TenantId && !l.IsDeleted, ct);
        if (lic is null || (!lic.SyncAddonActive &&
            lic.PlanType != PlanType.Enterprise && lic.PlanType != PlanType.ProMonthly))
            return Result<SyncPushResult>.Fail(
                "المزامنة غير متاحة في خطتك الحالية. يرجى الترقية", "SYNC_NOT_AVAILABLE");

        var results   = new List<SyncItemResult>();
        int processed = 0, conflicts = 0, failed = 0;

        // Process in batches to avoid timeout
        foreach (var batch in cmd.Request.Items
            .Select((item, i) => (item, i))
            .GroupBy(x => x.i / BATCH, x => x.item))
        {
            await _uow.BeginTransactionAsync(ct);
            try
            {
                foreach (var item in batch)
                {
                    // Idempotency check
                    var existing = await _uow.SyncQueue.FirstOrDefaultAsync(
                        q => q.IdempotencyKey == item.IdempotencyKey && q.TenantId == cmd.TenantId, ct);
                    if (existing?.Status == SyncStatus.Completed)
                    {
                        results.Add(new SyncItemResult(item.IdempotencyKey, SyncStatus.Completed, "تم معالجته مسبقاً"));
                        processed++;
                        continue;
                    }

                    var (status, message, serverData) = item.EntityType switch
                    {
                        SyncEntityType.Customer => await SyncCustomerAsync(cmd.TenantId, cmd.UserId, item, ct),
                        SyncEntityType.SaleOrder=> await SyncSaleOrderAsync(cmd.TenantId, cmd.UserId, item, ct),
                        SyncEntityType.StockAdjustment => await SyncStockAsync(cmd.TenantId, cmd.UserId, item, ct),
                        _ => (SyncStatus.Failed, $"نوع كيان غير مدعوم: {item.EntityType}", (object?)null)
                    };

                    if (existing is null)
                    {
                        await _uow.SyncQueue.AddAsync(new Domain.Entities.Sync.SyncQueue
                        {
                            Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                            IdempotencyKey = item.IdempotencyKey,
                            EntityType = item.EntityType, Operation = item.Operation,
                            Payload = JsonSerializer.Serialize(item.Payload),
                            ClientVersion = item.ClientVersion, ConflictStrategy = item.Strategy,
                            Status = status, HasConflict = status == SyncStatus.Conflict,
                            ProcessedAt = DateTime.UtcNow, CreatedBy = cmd.UserId,
                        }, ct);
                    }

                    results.Add(new SyncItemResult(item.IdempotencyKey, status, message, serverData));
                    if (status == SyncStatus.Completed) processed++;
                    else if (status == SyncStatus.Conflict) conflicts++;
                    else failed++;
                }
                await _uow.SaveChangesAsync(ct);
                await _uow.CommitTransactionAsync(ct);
            }
            catch (Exception ex)
            {
                await _uow.RollbackTransactionAsync(ct);
                _log.LogError(ex, "Sync batch failed");
                failed += batch.Count();
            }
        }

        await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId, AuditAction.SyncPush,
            "Sync", NewValues: new { Total = cmd.Request.Items.Count, processed, conflicts, failed }), ct);

        return Result<SyncPushResult>.Ok(
            new SyncPushResult(cmd.Request.Items.Count, processed, conflicts, failed, results));
    }

    public async Task<Result<SyncPullResult>> Handle(PullSyncQuery q, CancellationToken ct)
    {
        var products = await _uow.Products.Query()
            .Where(p => p.TenantId == q.TenantId && p.UpdatedAt > q.Since && !p.IsDeleted)
            .Take(q.MaxItems)
            .Select(p => (object)new { p.Id, p.Name, p.NameAr, p.Barcode, p.SKU, p.SalePrice, p.HasVat, p.VatRate })
            .ToListAsync(ct);

        var customers = await _uow.Customers.Query()
            .Where(c => c.TenantId == q.TenantId && c.UpdatedAt > q.Since && !c.IsDeleted)
            .Take(q.MaxItems)
            .Select(c => (object)new { c.Id, c.Name, c.Phone, c.LoyaltyPoints })
            .ToListAsync(ct);

        var orders = await _uow.SaleOrders.Query()
            .Where(o => o.TenantId == q.TenantId && o.BranchId == q.BranchId
                     && o.UpdatedAt > q.Since && !o.IsDeleted)
            .Take(100)
            .Select(o => (object)new { o.Id, o.OrderNumber, o.TotalAmount, o.Status, o.CreatedAt })
            .ToListAsync(ct);

        await _audit.LogAsync(new AuditEntry(q.TenantId, null, AuditAction.SyncPull, "Sync",
            NewValues: new { since = q.Since, products = products.Count, customers = customers.Count }), ct);

        return Result<SyncPullResult>.Ok(new SyncPullResult(
            products, customers, orders,
            DateTime.UtcNow,
            products.Count == q.MaxItems || customers.Count == q.MaxItems,
            null));
    }

    private async Task<(SyncStatus, string, object?)> SyncCustomerAsync(
        Guid tenantId, Guid userId, SyncItemRequest item, CancellationToken ct)
    {
        try
        {
            var data = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(
                JsonSerializer.Serialize(item.Payload));
            if (data is null) return (SyncStatus.Failed, "Payload غير صالح", null);

            var phone = data.TryGetValue("phone", out var ph) ? ph.GetString() : null;
            if (phone is not null)
            {
                var dup = await _uow.Customers.FirstOrDefaultAsync(
                    c => c.Phone == phone && c.TenantId == tenantId && !c.IsDeleted, ct);

                if (dup is not null)
                {
                    if (item.Strategy == ConflictStrategy.ServerWins)
                        return (SyncStatus.Conflict, "عميل بنفس الرقم موجود", dup);
                    if (item.Strategy == ConflictStrategy.ClientWins && data.TryGetValue("name", out var n))
                        dup.Name = n.GetString() ?? dup.Name;
                    return (SyncStatus.Completed, "تم دمج العميل", null);
                }
            }

            var name = data.TryGetValue("name", out var nm) ? nm.GetString() ?? "عميل" : "عميل";
            await _uow.Customers.AddAsync(new Domain.Entities.Core.Customer
            {
                Id = Guid.NewGuid(), TenantId = tenantId,
                Name = name, Phone = phone, Segment = Domain.Enums.CustomerSegment.New, IsActive = true,
            }, ct);
            return (SyncStatus.Completed, "تم إضافة العميل", null);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "SyncCustomer failed");
            return (SyncStatus.Failed, ex.Message, null);
        }
    }

    private async Task<(SyncStatus, string, object?)> SyncSaleOrderAsync(
        Guid tenantId, Guid userId, SyncItemRequest item, CancellationToken ct)
    {
        try
        {
            var data = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(
                JsonSerializer.Serialize(item.Payload));
            if (data is null) return (SyncStatus.Failed, "Payload غير صالح", null);

            var dup = await _uow.SaleOrders.FirstOrDefaultAsync(
                o => o.ClientIdempotencyKey == item.IdempotencyKey && o.TenantId == tenantId, ct);
            if (dup is not null) return (SyncStatus.Completed, "فاتورة مكررة", dup.Id);

            var branchId = data.TryGetValue("branchId", out var b) && Guid.TryParse(b.GetString(), out var bid)
                ? bid : (await _uow.Branches.FirstOrDefaultAsync(br => br.TenantId == tenantId && br.IsMain, ct))?.Id ?? Guid.Empty;
            var total = data.TryGetValue("totalAmount", out var t) ? t.GetDecimal() : 0;

            await _uow.SaleOrders.AddAsync(new Domain.Entities.POS.SaleOrder
            {
                Id = Guid.NewGuid(), TenantId = tenantId,
                OrderNumber = $"SYNC-{DateTime.UtcNow:yyyyMMddHHmmss}-{Random.Shared.Next(1000,9999)}",
                BranchId = branchId, CashierId = userId,
                Status = Domain.Enums.SaleStatus.Completed,
                PaymentMethod = Domain.Enums.PaymentMethod.Cash,
                TotalAmount = total, AmountPaid = total,
                SubTotal = Math.Round(total / 1.14m, 2),
                VatAmount = Math.Round(total - total / 1.14m, 2),
                IsOffline = true, ClientIdempotencyKey = item.IdempotencyKey,
                SyncedAt = DateTime.UtcNow,
            }, ct);
            return (SyncStatus.Completed, "تم حفظ الفاتورة", null);
        }
        catch (Exception ex) { return (SyncStatus.Failed, ex.Message, null); }
    }

    private async Task<(SyncStatus, string, object?)> SyncStockAsync(
        Guid tenantId, Guid userId, SyncItemRequest item, CancellationToken ct)
    {
        try
        {
            var data = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(
                JsonSerializer.Serialize(item.Payload));
            if (data is null) return (SyncStatus.Failed, "Payload غير صالح", null);

            if (!data.TryGetValue("productId", out var pid) || !Guid.TryParse(pid.GetString(), out var productId))
                return (SyncStatus.Failed, "productId مطلوب", null);
            if (!data.TryGetValue("branchId", out var bid) || !Guid.TryParse(bid.GetString(), out var branchId))
                return (SyncStatus.Failed, "branchId مطلوب", null);
            var qty = data.TryGetValue("quantity", out var q) ? q.GetDecimal() : 0;

            var stock = await _uow.StockItems.FirstOrDefaultAsync(
                s => s.ProductId == productId && s.BranchId == branchId && s.TenantId == tenantId, ct);
            if (stock is null)
            {
                await _uow.StockItems.AddAsync(new Domain.Entities.POS.StockItem
                {
                    Id = Guid.NewGuid(), TenantId = tenantId,
                    ProductId = productId, BranchId = branchId, Quantity = qty,
                }, ct);
            }
            else { stock.Quantity = Math.Max(0, stock.Quantity + qty); }

            return (SyncStatus.Completed, "تم تحديث المخزون", null);
        }
        catch (Exception ex) { return (SyncStatus.Failed, ex.Message, null); }
    }
}
