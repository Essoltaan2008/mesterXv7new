using MesterX.Domain.Enums;

namespace MesterX.Application.DTOs;

// ── Generic Wrappers ─────────────────────────────────────────────────────────
public sealed record ApiResponse<T>(bool Success, T? Data = default, string? Message = null, IList<string>? Errors = null)
{
    public static ApiResponse<T> Ok(T data, string? msg = null) => new(true, data, msg);
    public static ApiResponse<T> Fail(string msg, IList<string>? errs = null) => new(false, default, msg, errs);
}
public sealed record ApiResponse(bool Success, string? Message = null)
{
    public static ApiResponse Ok(string? msg = null) => new(true, msg);
    public static ApiResponse Fail(string msg) => new(false, msg);
}
public sealed record PagedResult<T>(IList<T> Items, int TotalCount, int Page, int PageSize)
{
    public int  TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
    public bool HasNext    => Page < TotalPages;
    public bool HasPrev    => Page > 1;
}

// ── Auth ─────────────────────────────────────────────────────────────────────
public record LoginRequest(string? Username, string? Email, string Password, string? MfaCode = null);
public record RegisterRequest(string FirstName, string LastName, string Username, string Email,
    string Password, string? Phone = null, string? CompanyName = null, UserRole Role = UserRole.CompanyOwner);
public record AuthResponse(string AccessToken, string RefreshToken, int ExpiresInSeconds,
    UserDto User, bool RequiresMfa = false);
public record RefreshTokenRequest(string RefreshToken);
public record ChangePasswordRequest(string OldPassword, string NewPassword, string ConfirmPassword);
public record MfaSetupResponse(string Secret, string QrCodeUrl, IList<string> BackupCodes);
public record MfaVerifyRequest(string Code);

// ── User ─────────────────────────────────────────────────────────────────────
public record UserDto(Guid Id, string Username, string Email, string FirstName, string LastName,
    string FullName, string? Phone, string? AvatarUrl, UserRole Role, Guid? BranchId,
    string? BranchName, bool IsActive, bool TwoFactorEnabled, DateTime? LastLoginAt, DateTime CreatedAt);

public record CreateUserRequest(string FirstName, string LastName, string Username, string Email,
    string Password, string? Phone, UserRole Role, Guid? BranchId);
public record UpdateUserRequest(string FirstName, string LastName, string? Phone,
    UserRole Role, Guid? BranchId, bool IsActive, bool MustChangePassword);

// ── Tenant ───────────────────────────────────────────────────────────────────
public record TenantDto(Guid Id, string Name, string Slug, string? LogoUrl, BusinessType BusinessType,
    string? City, string? ContactEmail, string? ContactPhone, TenantStatus Status,
    PlanType Plan, bool IsActive, DateTime CreatedAt, int BranchCount, int UserCount);

public record CreateTenantRequest(string Name, BusinessType BusinessType, string? ContactEmail,
    string? ContactPhone, string? City, string? TaxNumber,
    string AdminFirstName, string AdminLastName, string AdminEmail, string AdminPassword);

// ── Branch ───────────────────────────────────────────────────────────────────
public record BranchDto(Guid Id, string Name, string? Code, string? City, string? Phone,
    bool IsMain, bool IsActive, string? ManagerName, int UserCount);
public record CreateBranchRequest(string Name, string? NameAr, string? Code, string? Address,
    string? City, string? PhoneNumber, string? Email, double? Latitude, double? Longitude,
    bool IsMain, Guid? ManagerId);
public record UpdateBranchRequest(string Name, string? NameAr, string? Code, string? Address,
    string? City, string? PhoneNumber, bool IsActive, Guid? ManagerId,
    TimeOnly? OpenTime, TimeOnly? CloseTime);

// ── Product ───────────────────────────────────────────────────────────────────
public record ProductDto(Guid Id, string Name, string? NameAr, string? Description,
    string? Barcode, string? SKU, ProductType Type, ProductUnit Unit,
    decimal CostPrice, decimal SalePrice, bool HasVat, decimal VatRate,
    string? ImageUrl, bool IsActive, bool IsAvailableOnline, bool TrackInventory,
    int LowStockThreshold, string? CategoryName, Guid? CategoryId, decimal? CurrentStock);

public record CreateProductRequest(string Name, string? NameAr, string? Description,
    string? Barcode, string? SKU, Guid? CategoryId,
    ProductType Type = ProductType.Physical, ProductUnit Unit = ProductUnit.Piece,
    decimal CostPrice = 0, decimal SalePrice = 0,
    decimal? WholesalePrice = null, decimal? MinSalePrice = null,
    bool HasVat = true, string? ImageUrl = null,
    bool TrackInventory = true, int LowStockThreshold = 5,
    decimal? InitialStock = null, Guid? BranchId = null);

public record UpdateProductRequest(string Name, string? NameAr, string? Description,
    string? Barcode, string? SKU, Guid? CategoryId,
    decimal CostPrice, decimal SalePrice, decimal? WholesalePrice, decimal? MinSalePrice,
    bool HasVat, string? ImageUrl, bool IsActive, bool IsAvailableOnline,
    bool TrackInventory, int LowStockThreshold,
    decimal? ReorderPoint = null, decimal? ReorderQuantity = null);

public record ProductWithStockDto(Guid Id, string Name, string? NameAr, string? Barcode, string? SKU,
    decimal SalePrice, bool HasVat, decimal VatRate, string? ImageUrl,
    decimal CurrentStock, decimal ReservedStock, decimal AvailableStock, bool IsLowStock);

// ── Stock ─────────────────────────────────────────────────────────────────────
public record StockItemDto(Guid ProductId, string ProductName, string? Barcode, string? SKU,
    Guid BranchId, string BranchName, decimal Quantity, decimal Reserved, decimal Available,
    decimal? LastCostPrice, bool IsLowStock, DateTime? LastCountedAt);

public record StockAdjustRequest(Guid ProductId, Guid BranchId, decimal Quantity,
    StockMovementType Type, string? Notes, string? Reference);
public record StockTransferRequest(Guid ProductId, Guid FromBranchId, Guid ToBranchId,
    decimal Quantity, string? Notes);

// ── Sales ─────────────────────────────────────────────────────────────────────
public record CreateSaleRequest(
    Guid BranchId, Guid? CustomerId, PaymentMethod PaymentMethod,
    IList<SaleLineRequest> Items,
    decimal AmountPaid = 0, decimal DiscountAmount = 0,
    DiscountType DiscountType = DiscountType.Amount,
    decimal LoyaltyPointsToRedeem = 0,
    string? ClientIdempotencyKey = null, bool IsOffline = false, string? Notes = null);

public record SaleLineRequest(Guid ProductId, decimal Quantity,
    decimal UnitPrice = 0, decimal DiscountAmount = 0);

public record SaleOrderDto(Guid Id, string OrderNumber, Guid BranchId, string BranchName,
    Guid? CustomerId, string? CustomerName, string CashierName,
    SaleStatus Status, PaymentMethod PaymentMethod,
    decimal SubTotal, decimal VatAmount, decimal DiscountAmount,
    decimal TotalAmount, decimal AmountPaid, decimal ChangeGiven,
    decimal LoyaltyPointsEarned, bool IsOffline, DateTime CreatedAt,
    IList<SaleOrderItemDto> Items, IList<PaymentDto> Payments);

public record SaleOrderItemDto(Guid ProductId, string ProductName, string? Barcode,
    decimal Quantity, decimal UnitPrice, decimal VatRate,
    decimal VatAmount, decimal DiscountAmount, decimal LineTotal);

public record PaymentDto(Guid Id, PaymentMethod Method, decimal Amount,
    PaymentStatus Status, string? Reference, DateTime? PaidAt);

public record RefundRequest(decimal RefundAmount, string? Reason,
    PaymentMethod RefundMethod = PaymentMethod.Cash);

// ── Customer ──────────────────────────────────────────────────────────────────
public record CustomerDto(Guid Id, string Name, string? Phone, string? Email, string? City,
    CustomerSegment Segment, decimal LoyaltyPoints, decimal TotalPurchases,
    int TotalOrders, DateTime? LastPurchaseAt, bool IsActive, DateTime CreatedAt);

public record CreateCustomerRequest(string Name, string? Phone, string? Email,
    string? Address, string? City, Gender Gender = Gender.Unknown, DateOnly? DateOfBirth = null);
public record UpdateCustomerRequest(string Name, string? Phone, string? Email,
    string? Address, string? City, bool IsActive, string? Notes);
public record AddLoyaltyPointsRequest(int Points, string? Reason);

// ── Category ──────────────────────────────────────────────────────────────────
public record CategoryDto(Guid Id, string Name, string? NameAr, string? ImageUrl,
    Guid? ParentId, string? ParentName, int SortOrder, bool IsActive, int ProductCount);
public record CreateCategoryRequest(string Name, string? NameAr, string? Description,
    string? ImageUrl, Guid? ParentId, int SortOrder = 0);

// ── Supplier ──────────────────────────────────────────────────────────────────
public record SupplierDto(Guid Id, string Name, string? ContactPerson,
    string? Phone, string? Email, string? City, SupplierStatus Status,
    decimal OutstandingBalance, int TotalPurchaseOrders);
public record CreateSupplierRequest(string Name, string? ContactPerson, string? Phone,
    string? Email, string? Address, string? City, string? TaxNumber,
    decimal CreditLimit = 0, int PaymentTermsDays = 30);

// ── Purchase Order ─────────────────────────────────────────────────────────────
public record PurchaseOrderDto(Guid Id, string PONumber, string SupplierName, string BranchName,
    PurchaseOrderStatus Status, decimal TotalAmount, decimal AmountPaid,
    decimal AmountDue, DateTime? OrderDate, DateTime? ExpectedDate, DateTime? ReceivedDate,
    IList<PurchaseOrderItemDto> Items);
public record PurchaseOrderItemDto(Guid ProductId, string ProductName, decimal QuantityOrdered,
    decimal QuantityReceived, decimal UnitCost, decimal LineTotal);
public record CreatePurchaseOrderRequest(Guid SupplierId, Guid BranchId, DateTime? ExpectedDate,
    PaymentMethod PaymentMethod, int PaymentTermsDays, string? Notes,
    IList<PurchaseOrderLineRequest> Items);
public record PurchaseOrderLineRequest(Guid ProductId, decimal Quantity, decimal UnitCost);

// ── Expense ───────────────────────────────────────────────────────────────────
public record ExpenseDto(Guid Id, string Description, string? BranchName, ExpenseCategory Category,
    decimal Amount, DateTime ExpenseDate, PaymentMethod PaymentMethod,
    string? Reference, string? AttachmentUrl, string? Notes, string? ApprovedByName);
public record CreateExpenseRequest(string Description, Guid? BranchId, ExpenseCategory Category,
    decimal Amount, DateTime ExpenseDate, PaymentMethod PaymentMethod = PaymentMethod.Cash,
    string? Reference = null, string? AttachmentUrl = null, string? Notes = null);

// ── License ───────────────────────────────────────────────────────────────────
public record LicenseStatusDto(PlanType PlanType, LicenseStatus Status, DateTime ActivatedAt,
    DateTime? ExpiresAt, bool SyncAddonActive, DateTime? SyncAddonExpiresAt,
    int MaxBranches, int MaxUsers, int MaxProducts,
    int CurrentBranches, int CurrentUsers, int CurrentProducts,
    string? DowngradeReason, bool IsExpired, int? DaysUntilExpiry);
public record ActivateLicenseRequest(string LicenseKey, string DeviceFingerprint);
public record ActivateSyncAddonRequest(string SyncKey);
public record ValidateDeviceRequest(string DeviceFingerprint);

public record PlanDto(Guid Id, string Name, string NameEn, PlanType Type,
    decimal MonthlyPrice, decimal AnnualPrice, int MaxBranches, int MaxUsers, int MaxProducts,
    bool HasSyncEngine, bool HasAdvancedReports, bool HasApiAccess, bool HasWhiteLabel,
    bool HasRestaurantModule, bool HasRentalModule);

// ── Dashboard ─────────────────────────────────────────────────────────────────
public record DashboardStatsDto(
    decimal TodayRevenue, int TodayOrders,
    decimal MonthRevenue, int MonthOrders,
    int TotalCustomers, int NewCustomersThisMonth,
    int TotalProducts, int LowStockCount,
    int ActiveBranches, decimal AvgOrderValue, decimal GrossProfitToday,
    IList<DailySaleDto> WeekSales,
    IList<TopProductDto> TopProducts,
    IList<SaleOrderDto> RecentOrders);

public record DailySaleDto(DateOnly Date, decimal Revenue, int Orders, decimal Profit);
public record TopProductDto(Guid ProductId, string ProductName, int QuantitySold, decimal Revenue);

public record SalesReportRequest(DateTime FromDate, DateTime ToDate,
    Guid? BranchId = null, string? GroupBy = "day");
public record SalesReportDto(DateTime FromDate, DateTime ToDate,
    decimal TotalRevenue, decimal TotalVat, decimal TotalDiscount, decimal NetRevenue,
    int TotalOrders, decimal AvgOrderValue,
    IList<DailySaleDto> ByPeriod,
    IList<TopProductDto> TopProducts,
    IDictionary<string,decimal> ByPaymentMethod);

// ── Sync ──────────────────────────────────────────────────────────────────────
public record SyncPushRequest(IList<SyncItemRequest> Items, string ClientVersion, string DeviceFingerprint);
public record SyncItemRequest(string IdempotencyKey, SyncEntityType EntityType, SyncOperation Operation,
    object Payload, int ClientVersion, ConflictStrategy ConflictStrategy = ConflictStrategy.ServerWins);
public record SyncPushResult(int TotalItems, int Processed, int Conflicts, int Failed,
    IList<SyncItemResult> Results);
public record SyncItemResult(string IdempotencyKey, SyncStatus Status, string? Message, object? ServerData);
public record SyncPullResult(IList<ProductWithStockDto> Products, IList<CustomerDto> Customers,
    IList<SaleOrderDto> SaleOrders, DateTime ServerTime, bool HasMore, string? NextCursor);

// ── Platform ──────────────────────────────────────────────────────────────────
public record PlatformStatsDto(int TotalTenants, int ActiveTenants, int TrialTenants,
    int SuspendedTenants, decimal MonthlyRevenue, decimal AnnualRevenue,
    int TotalUsers, int TotalProducts,
    IDictionary<string,int> TenantsByPlan,
    IDictionary<string,int> TenantsByBusiness,
    IList<TenantDto> RecentTenants);

public record SuspendTenantRequest(string Reason);
