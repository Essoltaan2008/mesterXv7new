using MediatR;
using FluentValidation;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Common;

// ════════════════════════════════════════════════════════════════════════════
// Result<T> — typed result that forces error handling at compile time
// Never throws for expected failures; exceptions only for unexpected errors
// ════════════════════════════════════════════════════════════════════════════
public sealed class Result<T>
{
    public bool     IsSuccess  { get; }
    public T?       Value      { get; }
    public string?  Error      { get; }
    public string?  ErrorCode  { get; }
    public string?  Message    { get; }
    public bool     IsFailure  => !IsSuccess;

    private Result(T value, string? message) { IsSuccess = true;  Value = value; Message = message; }
    private Result(string e, string? c)      { IsSuccess = false; Error = e; ErrorCode = c; }

    public static Result<T> Ok(T value, string? message = null) => new(value, message);
    public static Result<T> Fail(string err, string? code = null) => new(err, code);

    // Map to ApiResponse for controllers
    public ApiResponse<T> ToResponse(string? successMessage = null) =>
        IsSuccess
            ? ApiResponse<T>.Ok(Value!, successMessage ?? Message)
            : ApiResponse<T>.Fail(Error!, errorCode: ErrorCode);
}

public sealed class Result
{
    public bool    IsSuccess { get; }
    public string? Error     { get; }
    public string? ErrorCode { get; }
    public bool    IsFailure => !IsSuccess;

    private Result(bool ok, string? e, string? c){ IsSuccess = ok; Error = e; ErrorCode = c; }

    public static Result Ok()                                       => new(true,  null, null);
    public static Result Fail(string err, string? code = null)      => new(false, err,  code);

    public ApiResponse ToResponse(string? msg = null) =>
        IsSuccess ? ApiResponse.Ok(msg) : ApiResponse.Fail(Error!);
}

// ════════════════════════════════════════════════════════════════════════════
// ApiResponse — uniform HTTP response envelope
// ════════════════════════════════════════════════════════════════════════════
public sealed record ApiResponse<T>(
    bool      Success,
    T?        Data      = default,
    string?   Message   = null,
    string?   ErrorCode = null,
    IDictionary<string,string[]>? ValidationErrors = null)
{
    public static ApiResponse<T> Ok(T data, string? msg = null)
        => new(true,  data,    msg);
    public static ApiResponse<T> Fail(string err, string? errorCode = null,
        IDictionary<string,string[]>? valErrors = null)
        => new(false, default, err, errorCode, valErrors);
}

public sealed record ApiResponse(
    bool    Success,
    string? Message   = null,
    string? ErrorCode = null,
    IDictionary<string,string[]>? ValidationErrors = null)
{
    public static ApiResponse Ok(string? msg = null)    => new(true,  msg);
    public static ApiResponse Fail(string err, string? code = null,
        IDictionary<string,string[]>? v = null) => new(false, err, code, v);
}

public sealed record PagedResult<T>(
    IReadOnlyList<T> Items,
    int  TotalCount,
    int  Page,
    int  PageSize)
{
    public int  TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
    public bool HasNext    => Page < TotalPages;
    public bool HasPrev    => Page > 1;
}

// ════════════════════════════════════════════════════════════════════════════
// MediatR pipeline: ValidationBehavior
// Runs FluentValidation before every Command/Query handler
// ════════════════════════════════════════════════════════════════════════════
public class ValidationBehavior<TRequest, TResponse>
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly IEnumerable<IValidator<TRequest>> _validators;

    public ValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
        => _validators = validators;

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        if (!_validators.Any()) return await next();

        var ctx     = new ValidationContext<TRequest>(request);
        var results = await Task.WhenAll(
            _validators.Select(v => v.ValidateAsync(ctx, ct)));

        var failures = results
            .SelectMany(r => r.Errors)
            .Where(e => e != null)
            .ToList();

        if (failures.Count == 0) return await next();

        // Group by field name for structured validation errors
        var errors = failures
            .GroupBy(f => f.PropertyName)
            .ToDictionary(
                g => g.Key,
                g => g.Select(f => f.ErrorMessage).ToArray());

        throw new ValidationException(failures);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// MediatR pipeline: LoggingBehavior
// Logs every request with duration and outcome
// ════════════════════════════════════════════════════════════════════════════
public sealed class LoggingBehavior<TRequest, TResponse>
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly ILogger<LoggingBehavior<TRequest, TResponse>> _log;
    public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> log) => _log = log;

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken ct)
    {
        var name  = typeof(TRequest).Name;
        var sw    = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            var response = await next();
            sw.Stop();
            _log.LogInformation("[{Name}] completed in {Ms}ms", name, sw.ElapsedMilliseconds);
            return response;
        }
        catch (Exception ex)
        {
            sw.Stop();
            _log.LogError(ex, "[{Name}] failed after {Ms}ms", name, sw.ElapsedMilliseconds);
            throw;
        }
    }
}
