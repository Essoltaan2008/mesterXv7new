# MesterX v7 Core MVP

النسخة دي مخصصة لإطلاق `Core MVP` فقط على baseline `integration/v7`.

## Launch Scope

- `Login`
- `Dashboard`
- `Customers`
- `Inventory`
- `POS`

الموديولات الموجودة في الكود لكن خارج نطاق الإطلاق الحالي:

- `Reports`
- `Suppliers`
- `Expenses`
- `Admin`
- `Settings`
- `License`
- `Sync`

## Stack

- Backend: `ASP.NET Core 8` + `MediatR` + `EF Core`
- Database: `PostgreSQL`
- Frontend: `Next.js 14`
- Local orchestration: `docker-compose`

## Local Run

1. انسخ ملف البيئة:

```bash
cp .env.example .env
```

2. عدّل المتغيرات المطلوبة داخل `.env`:

- `DB_PASSWORD`
- `JWT_SECRET`

3. شغّل الخدمات:

```bash
docker compose up -d --build
```

4. افتح الروابط:

- Frontend: `http://localhost:3000`
- API: `http://localhost:5000/swagger`
- Health: `http://localhost:5000/health/live`

## Non-Docker Run

Backend:

```bash
cd backend
dotnet test MesterX.sln
dotnet run --project src/MesterX.API
```

Frontend:

```bash
cd frontend
npm install
npm run type-check
npm run build
npm run start
```

## Validation Status

- `dotnet test backend/MesterX.sln` ✅
- `npm run type-check` ✅
- `npm run build` ✅

## Notes

- الـ sidebar والـ launch navigation مضيّقين على صفحات الـ MVP فقط.
- باقي الصفحات ما زالت موجودة داخليًا لتقليل المخاطر، لكنها ليست جزءًا من الإطلاق الأول.
- يوجد warning أمني من `npm` على `next@14.2.5` ويحتاج upgrade مستقل بعد تثبيت الإطلاق.
