using MediatR;
using MesterX.Application.Common;
using MesterX.Application.Features.Customers;
using MesterX.Application.Features.Dashboard;
using MesterX.Application.Features.Inventory;
using MesterX.Application.Features.License;
using MesterX.Application.Features.Pos;
using MesterX.Application.Features.Sync;
using MesterX.Domain.Entities.Core;
using MesterX.Domain.Entities.POS;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

// ════════════════════════════════════════════════════════════════════════════
// PosHandler
// ════════════════════════════════════════════════════════════════════════════
public sealed class PosHandler :
    IRequestHandler<GetPosProductsQuery,    Result<IReadOnlyList<ProductPosDto>>>,
    IRequestHandler<GetByBarcodeQuery,       Result<ProductPosDto>>,
    IRequestHandler<CreateSaleCommand,       Result<SaleOrderDto>>,
    IRequestHandler<GetSalesQuery,           Result<PagedResult<SaleOrderDto>>>,
    IRequestHandler<GetSaleByIdQuery,        Result<SaleOrderDto>>,
    IRequestHandler<RefundSaleCommand,       Result<SaleOrderDto>>
{
    private readonly IUnitOfWork         _uow;
    private readonly IAuditService       _audit;
    private readonly ICacheService       _cache;
    private readonly ILogger<PosHandler> _log;

    public PosHandler(IUnitOfWork uow, IAuditService audit, ICacheService cache, ILogger<PosHandler> log)
    { _uow = uow; _audit = audit; _cache = cache; _log = log; }

    public async Task<Result<IReadOnlyList<ProductPosDto>>> Handle(GetPosProductsQuery q, CancellationToken ct)
    {
        if (q.Search is null)
        {
            var cached = await _cache.GetAsync<IReadOnlyList<ProductPosDto>>(
                CacheKeys.ProductsByBranch(q.BranchId), ct);
            if (cached is not null) return Result<IReadOnlyList<ProductPosDto>>.Ok(cached);
        }

        var products = await _uow.Products.Query()
            .Where(p => p.TenantId == q.TenantId && p.IsActive && !p.IsDeleted)
            .Where(p => q.Search == null
                     || p.Name.Contains(q.Search)
                     || (p.NameAr != null && p.NameAr.Contains(q.Search))
                     || p.Barcode == q.Search || p.SKU == q.Search)
            .OrderBy(p => p.Name)
            .ToListAsync(ct);

        var stocks = await _uow.StockItems.Query()
            .Where(s => s.BranchId == q.BranchId && !s.IsDeleted)
            .ToDictionaryAsync(s => s.ProductId, ct);

        var dtos = products.Select(p => {
            stocks.TryGetValue(p.Id, out var s);
            var avail = s?.AvailableQuantity ?? 0;
            return new ProductPosDto(
                p.Id, p.Name, p.NameAr, p.Barcode, p.SKU,
                p.SalePrice, p.HasVat, p.VatRate, p.ImageUrl, null,
                s?.Quantity ?? 0, s?.ReservedQuantity ?? 0, avail,
                p.TrackInventory && avail <= p.LowStockThreshold);
        }).ToList();

        if (q.Search is null)
            await _cache.SetAsync(CacheKeys.ProductsByBranch(q.BranchId), (IReadOnlyList<ProductPosDto>)dtos,
                TimeSpan.FromMinutes(10), ct);

        return Result<IReadOnlyList<ProductPosDto>>.Ok(dtos);
    }

    public async Task<Result<ProductPosDto>> Handle(GetByBarcodeQuery q, CancellationToken ct)
    {
        var p = await _uow.Products.Query()
            .FirstOrDefaultAsync(x =>
                x.TenantId == q.TenantId && !x.IsDeleted &&
                (x.Barcode == q.Barcode || x.SKU == q.Barcode), ct);
        if (p is null) return Result<ProductPosDto>.Fail("المنتج غير موجود", "NOT_FOUND");
        var s = await _uow.StockItems.FirstOrDefaultAsync(
            x => x.ProductId == p.Id && x.BranchId == q.BranchId, ct);
        var avail = s?.AvailableQuantity ?? 0;
        return Result<ProductPosDto>.Ok(new ProductPosDto(
            p.Id, p.Name, p.NameAr, p.Barcode, p.SKU,
            p.SalePrice, p.HasVat, p.VatRate, p.ImageUrl, null,
            s?.Quantity ?? 0, s?.ReservedQuantity ?? 0, avail,
            p.TrackInventory && avail <= p.LowStockThreshold));
    }

    public async Task<Result<SaleOrderDto>> Handle(CreateSaleCommand cmd, CancellationToken ct)
    {
        var req = cmd.Request;

        // Idempotency check
        if (req.ClientIdempotencyKey is not null)
        {
            var ex = await _uow.SaleOrders.FirstOrDefaultAsync(
                o => o.ClientIdempotencyKey == req.ClientIdempotencyKey, ct);
            if (ex is not null)
                return Result<SaleOrderDto>.Ok(await MapSaleDto(ex, ct), "تم معالجة هذا الطلب مسبقاً");
        }

        var tenant = await _uow.Tenants.FirstOrDefaultAsync(t => t.Id == cmd.TenantId, ct);
        var vatRate = tenant?.VatRate ?? 0.14m;

        await _uow.BeginTransactionAsync(ct);
        try
        {
            decimal subTotal = 0, vatTotal = 0;
            var items     = new List<SaleOrderItem>();
            var movements = new List<StockMovement>();

            foreach (var line in req.Items)
            {
                var product = await _uow.Products.Query()
                    .FirstOrDefaultAsync(p =>
                        p.TenantId == cmd.TenantId && p.Id == line.ProductId && !p.IsDeleted, ct);
                if (product is null)
                {
                    await _uow.RollbackTransactionAsync(ct);
                    return Result<SaleOrderDto>.Fail($"المنتج غير موجود: {line.ProductId}", "PRODUCT_NOT_FOUND");
                }

                var unitPrice  = line.UnitPrice > 0 ? line.UnitPrice : product.SalePrice;
                if (product.MinSalePrice.HasValue && unitPrice < product.MinSalePrice.Value)
                    unitPrice = product.MinSalePrice.Value;

                var lineBase   = unitPrice * line.Quantity - line.DiscountAmount;
                var lineVat    = product.HasVat ? Math.Round(lineBase * vatRate, 2) : 0;
                var lineTotal  = lineBase + lineVat;
                subTotal      += lineBase;
                vatTotal      += lineVat;

                items.Add(new SaleOrderItem
                {
                    Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                    ProductId = product.Id, ProductName = product.Name,
                    ProductBarcode = product.Barcode, ProductSku = product.SKU,
                    Quantity = line.Quantity, UnitPrice = unitPrice,
                    CostPrice = product.CostPrice, VatRate = product.HasVat ? vatRate : 0,
                    VatAmount = lineVat, DiscountAmount = line.DiscountAmount, LineTotal = lineTotal,
                });

                if (product.TrackInventory && !req.IsOffline)
                {
                    var stock = await _uow.StockItems.FirstOrDefaultAsync(
                        s => s.ProductId == product.Id && s.BranchId == req.BranchId, ct);
                    if (stock is null || stock.AvailableQuantity < line.Quantity)
                    {
                        await _uow.RollbackTransactionAsync(ct);
                        return Result<SaleOrderDto>.Fail(
                            $"المخزون غير كافٍ: {product.Name} (متوفر: {stock?.AvailableQuantity ?? 0})",
                            "INSUFFICIENT_STOCK");
                    }
                    var before = stock.Quantity;
                    stock.Quantity -= line.Quantity;
                    movements.Add(new StockMovement
                    {
                        Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                        ProductId = product.Id, BranchId = req.BranchId, UserId = cmd.CashierId,
                        Type = StockMovementType.Sale, QuantityBefore = before,
                        QuantityChange = -line.Quantity, QuantityAfter = stock.Quantity,
                        UnitCost = product.CostPrice,
                    });
                }
            }

            var orderDiscount = req.DiscountType == DiscountType.Percentage
                ? Math.Round(subTotal * req.DiscountAmount / 100, 2)
                : req.DiscountAmount;

            var total  = subTotal + vatTotal - orderDiscount;
            var change = Math.Max(0, req.AmountPaid - total);

            var order = new SaleOrder
            {
                Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                OrderNumber = $"INV-{DateTime.UtcNow:yyyyMMdd}-{Random.Shared.Next(10000,99999)}",
                BranchId = req.BranchId, CustomerId = req.CustomerId,
                CashierId = cmd.CashierId,
                Status = SaleStatus.Completed, PaymentMethod = req.PaymentMethod,
                SubTotal = subTotal, VatAmount = vatTotal, DiscountAmount = orderDiscount,
                TotalAmount = total, AmountPaid = req.AmountPaid, ChangeGiven = change,
                IsOffline = req.IsOffline, ClientIdempotencyKey = req.ClientIdempotencyKey,
                Notes = req.Notes, SyncedAt = req.IsOffline ? null : DateTime.UtcNow,
            };

            await _uow.SaleOrders.AddAsync(order, ct);
            foreach (var item in items) { item.SaleOrderId = order.Id; await _uow.SaleOrderItems.AddAsync(item, ct); }
            foreach (var mv in movements) { mv.SaleOrderId = order.Id; await _uow.StockMovements.AddAsync(mv, ct); }

            await _uow.Payments.AddAsync(new Payment
            {
                Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                SaleOrderId = order.Id, ProcessedById = cmd.CashierId,
                Method = req.PaymentMethod, Amount = req.AmountPaid,
                Status = PaymentStatus.Completed, PaidAt = DateTime.UtcNow,
            }, ct);

            // Loyalty update
            if (req.CustomerId.HasValue)
            {
                var cust = await _uow.Customers.FirstOrDefaultAsync(
                    c => c.Id == req.CustomerId.Value && c.TenantId == cmd.TenantId, ct);
                if (cust is not null)
                {
                    cust.TotalPurchases += total;
                    cust.TotalOrders++;
                    cust.LoyaltyPoints  += Math.Floor(total / 10);
                    cust.LastPurchaseAt = DateTime.UtcNow;
                    cust.Segment        = cust.TotalPurchases > 10000 ? CustomerSegment.VIP
                                        : cust.TotalPurchases > 2000  ? CustomerSegment.Regular
                                        : CustomerSegment.New;
                }
            }

            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);

            await _cache.RemoveAsync(CacheKeys.ProductsByBranch(req.BranchId), ct);
            await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.CashierId,
                AuditAction.Create, "SaleOrder", order.Id,
                NewValues: new { order.OrderNumber, order.TotalAmount }), ct);

            return Result<SaleOrderDto>.Ok(await MapSaleDto(order, ct, items), "تمت عملية البيع");
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync(ct);
            _log.LogError(ex, "Sale failed for tenant {TenantId}", cmd.TenantId);
            return Result<SaleOrderDto>.Fail("فشلت عملية البيع", "SALE_FAILED");
        }
    }

    public async Task<Result<PagedResult<SaleOrderDto>>> Handle(GetSalesQuery q, CancellationToken ct)
    {
        var from = q.From ?? DateTime.UtcNow.Date;
        var to   = q.To   ?? DateTime.UtcNow.Date.AddDays(1);
        var qry  = _uow.SaleOrders.Query()
            .Where(o => o.TenantId == q.TenantId && o.BranchId == q.BranchId
                     && !o.IsDeleted && o.CreatedAt >= from && o.CreatedAt < to)
            .OrderByDescending(o => o.CreatedAt);

        var total  = await qry.CountAsync(ct);
        var orders = await qry.Skip((q.Page - 1) * q.PageSize).Take(q.PageSize).ToListAsync(ct);
        var dtos   = new List<SaleOrderDto>();
        foreach (var o in orders) dtos.Add(await MapSaleDto(o, ct));
        return Result<PagedResult<SaleOrderDto>>.Ok(new PagedResult<SaleOrderDto>(dtos, total, q.Page, q.PageSize));
    }

    public async Task<Result<SaleOrderDto>> Handle(GetSaleByIdQuery q, CancellationToken ct)
    {
        var o = await _uow.SaleOrders.Query()
            .FirstOrDefaultAsync(x => x.Id == q.SaleId && x.TenantId == q.TenantId, ct);
        return o is null
            ? Result<SaleOrderDto>.Fail("الفاتورة غير موجودة", "NOT_FOUND")
            : Result<SaleOrderDto>.Ok(await MapSaleDto(o, ct));
    }

    public async Task<Result<SaleOrderDto>> Handle(RefundSaleCommand cmd, CancellationToken ct)
    {
        var order = await _uow.SaleOrders.Query()
            .FirstOrDefaultAsync(o => o.Id == cmd.SaleId && o.TenantId == cmd.TenantId, ct);
        if (order is null)       return Result<SaleOrderDto>.Fail("الفاتورة غير موجودة", "NOT_FOUND");
        if (order.Status == SaleStatus.Refunded) return Result<SaleOrderDto>.Fail("مُسترجع بالكامل", "ALREADY_REFUNDED");
        if (cmd.Request.RefundAmount > order.TotalAmount) return Result<SaleOrderDto>.Fail("مبلغ الاسترجاع أكبر من قيمة الفاتورة", "INVALID_AMOUNT");

        await _uow.SaleRefunds.AddAsync(new SaleRefund
        {
            Id = Guid.NewGuid(), TenantId = cmd.TenantId,
            SaleOrderId = cmd.SaleId, ProcessedById = cmd.UserId,
            RefundAmount = cmd.Request.RefundAmount, RefundMethod = cmd.Request.RefundMethod,
            Reason = cmd.Request.Reason, IsFullRefund = cmd.Request.RefundAmount >= order.TotalAmount,
            RefundedAt = DateTime.UtcNow,
        }, ct);

        order.Status = cmd.Request.RefundAmount >= order.TotalAmount
            ? SaleStatus.Refunded : SaleStatus.PartialRefund;

        await _uow.SaveChangesAsync(ct);
        return Result<SaleOrderDto>.Ok(await MapSaleDto(order, ct), "تم الاسترجاع");
    }

    private async Task<SaleOrderDto> MapSaleDto(SaleOrder o, CancellationToken ct,
        List<SaleOrderItem>? preItems = null)
    {
        var branch   = await _uow.Branches.FirstOrDefaultAsync(b => b.Id == o.BranchId, ct);
        var cashier  = await _uow.Users.FirstOrDefaultAsync(u => u.Id == o.CashierId, ct);
        var customer = o.CustomerId.HasValue
            ? await _uow.Customers.FirstOrDefaultAsync(c => c.Id == o.CustomerId.Value, ct) : null;
        var items    = preItems ?? (await _uow.SaleOrderItems.FindAsync(i => i.SaleOrderId == o.Id, ct)).ToList();
        var payments = (await _uow.Payments.FindAsync(p => p.SaleOrderId == o.Id, ct)).ToList();

        return new SaleOrderDto(
            o.Id, o.OrderNumber, o.BranchId, branch?.Name ?? "",
            o.CustomerId, customer?.Name, cashier?.FullName ?? "",
            o.Status, o.PaymentMethod,
            o.SubTotal, o.VatAmount, o.DiscountAmount,
            o.TotalAmount, o.AmountPaid, o.ChangeGiven,
            o.LoyaltyPointsEarned, o.IsOffline, o.CreatedAt,
            items.Select(i => new SaleLineDto(
                i.ProductId, i.ProductName, i.ProductBarcode,
                i.Quantity, i.UnitPrice, i.VatRate, i.VatAmount, i.DiscountAmount, i.LineTotal)).ToList(),
            payments.Select(p => new PaymentDto(
                p.Id, p.Method, p.Amount, p.Status, p.Reference, p.PaidAt)).ToList());
    }
}

// ════════════════════════════════════════════════════════════════════════════
// InventoryHandler
// ════════════════════════════════════════════════════════════════════════════
public sealed class InventoryHandler :
    IRequestHandler<GetProductsQuery,      Result<PagedResult<ProductDto>>>,
    IRequestHandler<GetProductQuery,        Result<ProductDto>>,
    IRequestHandler<CreateProductCommand,   Result<ProductDto>>,
    IRequestHandler<UpdateProductCommand,   Result<ProductDto>>,
    IRequestHandler<GetStockQuery,          Result<IReadOnlyList<StockItemDto>>>,
    IRequestHandler<AdjustStockCommand,     Result<StockItemDto>>,
    IRequestHandler<TransferStockCommand,   Result<StockItemDto>>
{
    private readonly IUnitOfWork              _uow;
    private readonly IAuditService            _audit;
    private readonly ICacheService            _cache;
    private readonly ILogger<InventoryHandler>_log;

    public InventoryHandler(IUnitOfWork uow, IAuditService audit, ICacheService cache, ILogger<InventoryHandler> log)
    { _uow = uow; _audit = audit; _cache = cache; _log = log; }

    public async Task<Result<PagedResult<ProductDto>>> Handle(GetProductsQuery q, CancellationToken ct)
    {
        var qry = _uow.Products.Query()
            .Where(p => p.TenantId == q.TenantId && !p.IsDeleted)
            .Where(p => q.CategoryId == null || p.CategoryId == q.CategoryId)
            .Where(p => q.Search == null
                     || p.Name.Contains(q.Search) || (p.NameAr != null && p.NameAr.Contains(q.Search))
                     || p.Barcode == q.Search || p.SKU == q.Search)
            .OrderBy(p => p.Name);

        var total = await qry.CountAsync(ct);
        var items = await qry.Skip((q.Page - 1) * q.PageSize).Take(q.PageSize)
            .Include(p => p.Category).ToListAsync(ct);

        var ids    = items.Select(p => p.Id).ToList();
        var stocks = await _uow.StockItems.Query()
            .Where(s => ids.Contains(s.ProductId) && !s.IsDeleted)
            .GroupBy(s => s.ProductId)
            .Select(g => new { Id = g.Key, Total = g.Sum(s => s.AvailableQuantity) })
            .ToDictionaryAsync(x => x.Id, x => x.Total, ct);

        var dtos = items.Select(p => ToProductDto(p, stocks.GetValueOrDefault(p.Id))).ToList();
        return Result<PagedResult<ProductDto>>.Ok(new PagedResult<ProductDto>(dtos, total, q.Page, q.PageSize));
    }

    public async Task<Result<ProductDto>> Handle(GetProductQuery q, CancellationToken ct)
    {
        var p = await _uow.Products.Query().Include(x => x.Category)
            .FirstOrDefaultAsync(x => x.Id == q.Id && x.TenantId == q.TenantId && !x.IsDeleted, ct);
        return p is null
            ? Result<ProductDto>.Fail("المنتج غير موجود", "NOT_FOUND")
            : Result<ProductDto>.Ok(ToProductDto(p, null));
    }

    public async Task<Result<ProductDto>> Handle(CreateProductCommand cmd, CancellationToken ct)
    {
        var req = cmd.Request;
        if (req.Barcode is not null && await _uow.Products.AnyAsync(
                p => p.Barcode == req.Barcode && p.TenantId == cmd.TenantId && !p.IsDeleted, ct))
            return Result<ProductDto>.Fail("الباركود موجود بالفعل", "DUPLICATE_BARCODE");

        if (req.SKU is not null && await _uow.Products.AnyAsync(
                p => p.SKU == req.SKU && p.TenantId == cmd.TenantId && !p.IsDeleted, ct))
            return Result<ProductDto>.Fail("رمز SKU موجود بالفعل", "DUPLICATE_SKU");

        await _uow.BeginTransactionAsync(ct);
        try
        {
            var product = new Domain.Entities.Core.Product
            {
                Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                CategoryId = req.CategoryId, BranchId = req.BranchId,
                Name = req.Name, NameAr = req.NameAr, Description = req.Description,
                Barcode = req.Barcode, SKU = req.SKU, Type = req.Type, Unit = req.Unit,
                CostPrice = req.CostPrice, SalePrice = req.SalePrice,
                WholesalePrice = req.WholesalePrice, MinSalePrice = req.MinSalePrice,
                HasVat = req.HasVat, VatRate = req.HasVat ? 0.14m : 0,
                ImageUrl = req.ImageUrl, IsActive = true, IsAvailableOnline = true,
                TrackInventory = req.TrackInventory, LowStockThreshold = req.LowStockThreshold,
            };
            await _uow.Products.AddAsync(product, ct);

            if (req.InitialStock.HasValue && req.InitialStock.Value > 0)
            {
                var branchId = req.BranchId
                    ?? (await _uow.Branches.FirstOrDefaultAsync(b => b.TenantId == cmd.TenantId && b.IsMain, ct))?.Id;
                if (branchId.HasValue)
                {
                    await _uow.StockItems.AddAsync(new StockItem
                    {
                        Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                        ProductId = product.Id, BranchId = branchId.Value,
                        Quantity = req.InitialStock.Value,
                    }, ct);
                    await _uow.StockMovements.AddAsync(new StockMovement
                    {
                        Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                        ProductId = product.Id, BranchId = branchId.Value, UserId = cmd.UserId,
                        Type = StockMovementType.Opening,
                        QuantityBefore = 0, QuantityChange = req.InitialStock.Value,
                        QuantityAfter = req.InitialStock.Value, Notes = "مخزون افتتاحي",
                    }, ct);
                }
            }

            await _uow.SaveChangesAsync(ct);
            await _uow.CommitTransactionAsync(ct);
            await InvalidateProductCaches(cmd.TenantId, ct);
            await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId,
                AuditAction.Create, "Product", product.Id,
                NewValues: new { product.Name, product.SalePrice }), ct);

            return Result<ProductDto>.Ok(ToProductDto(product, req.InitialStock), "تم إضافة المنتج");
        }
        catch (Exception ex)
        {
            await _uow.RollbackTransactionAsync(ct);
            _log.LogError(ex, "Create product failed");
            return Result<ProductDto>.Fail("فشل إضافة المنتج", "CREATE_FAILED");
        }
    }

    public async Task<Result<ProductDto>> Handle(UpdateProductCommand cmd, CancellationToken ct)
    {
        var p = await _uow.Products.FirstOrDefaultAsync(
            x => x.Id == cmd.Id && x.TenantId == cmd.TenantId && !x.IsDeleted, ct);
        if (p is null) return Result<ProductDto>.Fail("المنتج غير موجود", "NOT_FOUND");

        var req = cmd.Request;
        p.Name = req.Name; p.NameAr = req.NameAr; p.Description = req.Description;
        p.Barcode = req.Barcode; p.SKU = req.SKU; p.CategoryId = req.CategoryId;
        p.CostPrice = req.CostPrice; p.SalePrice = req.SalePrice;
        p.WholesalePrice = req.WholesalePrice; p.MinSalePrice = req.MinSalePrice;
        p.HasVat = req.HasVat; p.ImageUrl = req.ImageUrl;
        p.IsActive = req.IsActive; p.IsAvailableOnline = req.IsAvailableOnline;
        p.TrackInventory = req.TrackInventory; p.LowStockThreshold = req.LowStockThreshold;
        p.ReorderPoint = req.ReorderPoint; p.ReorderQuantity = req.ReorderQuantity;

        await _uow.SaveChangesAsync(ct);
        await InvalidateProductCaches(cmd.TenantId, ct);
        return Result<ProductDto>.Ok(ToProductDto(p, null), "تم التحديث");
    }

    public async Task<Result<IReadOnlyList<StockItemDto>>> Handle(GetStockQuery q, CancellationToken ct)
    {
        var items = await _uow.StockItems.Query()
            .Where(s => s.TenantId == q.TenantId && !s.IsDeleted)
            .Where(s => q.BranchId == null || s.BranchId == q.BranchId)
            .Include(s => s.Product).Include(s => s.Branch)
            .ToListAsync(ct);
        if (q.LowOnly) items = items.Where(s =>
            s.Product.TrackInventory && s.AvailableQuantity <= s.Product.LowStockThreshold).ToList();

        return Result<IReadOnlyList<StockItemDto>>.Ok(items.Select(s => new StockItemDto(
            s.ProductId, s.Product.Name, s.Product.Barcode, s.Product.SKU,
            s.BranchId, s.Branch?.Name ?? "",
            s.Quantity, s.ReservedQuantity, s.AvailableQuantity,
            s.LastCostPrice, s.AvailableQuantity <= s.Product.LowStockThreshold,
            s.LastCountedAt)).ToList());
    }

    public async Task<Result<StockItemDto>> Handle(AdjustStockCommand cmd, CancellationToken ct)
    {
        var req   = cmd.Request;
        var stock = await _uow.StockItems.Query()
            .Include(s => s.Product).Include(s => s.Branch)
            .FirstOrDefaultAsync(s =>
                s.ProductId == req.ProductId && s.BranchId == req.BranchId
                && s.TenantId == cmd.TenantId, ct);

        if (stock is null)
        {
            stock = new StockItem
            {
                Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                ProductId = req.ProductId, BranchId = req.BranchId, Quantity = 0,
            };
            await _uow.StockItems.AddAsync(stock, ct);
        }

        var before = stock.Quantity;
        stock.Quantity = req.Type == StockMovementType.PhysicalCount
            ? req.Quantity : Math.Max(0, stock.Quantity + req.Quantity);
        if (req.Type == StockMovementType.PhysicalCount) stock.LastCountedAt = DateTime.UtcNow;

        await _uow.StockMovements.AddAsync(new StockMovement
        {
            Id = Guid.NewGuid(), TenantId = cmd.TenantId,
            ProductId = req.ProductId, BranchId = req.BranchId, UserId = cmd.UserId,
            Type = req.Type, QuantityBefore = before,
            QuantityChange = stock.Quantity - before, QuantityAfter = stock.Quantity,
            Notes = req.Notes, Reference = req.Reference,
        }, ct);

        await _uow.SaveChangesAsync(ct);
        await _cache.RemoveAsync(CacheKeys.ProductsByBranch(req.BranchId), ct);

        var p = stock.Product ?? await _uow.Products.GetByIdAsync(req.ProductId, ct)!;
        var b = stock.Branch  ?? await _uow.Branches.GetByIdAsync(req.BranchId, ct)!;
        return Result<StockItemDto>.Ok(new StockItemDto(
            stock.ProductId, p?.Name ?? "", p?.Barcode, p?.SKU,
            stock.BranchId, b?.Name ?? "",
            stock.Quantity, stock.ReservedQuantity, stock.AvailableQuantity,
            stock.LastCostPrice, stock.AvailableQuantity <= (p?.LowStockThreshold ?? 5),
            stock.LastCountedAt));
    }

    public async Task<Result<StockItemDto>> Handle(TransferStockCommand cmd, CancellationToken ct)
    {
        var req  = cmd.Request;
        var from = await _uow.StockItems.FirstOrDefaultAsync(
            s => s.ProductId == req.ProductId && s.BranchId == req.FromBranchId && s.TenantId == cmd.TenantId, ct);
        if (from is null || from.AvailableQuantity < req.Quantity)
            return Result<StockItemDto>.Fail("المخزون غير كافٍ للتحويل", "INSUFFICIENT_STOCK");

        var to = await _uow.StockItems.FirstOrDefaultAsync(
            s => s.ProductId == req.ProductId && s.BranchId == req.ToBranchId && s.TenantId == cmd.TenantId, ct)
            ?? new StockItem { Id = Guid.NewGuid(), TenantId = cmd.TenantId, ProductId = req.ProductId, BranchId = req.ToBranchId };

        from.Quantity -= req.Quantity;
        to.Quantity   += req.Quantity;
        if (to.Id == Guid.Empty || !await _uow.StockItems.AnyAsync(
            s => s.ProductId == req.ProductId && s.BranchId == req.ToBranchId && s.TenantId == cmd.TenantId, ct))
            await _uow.StockItems.AddAsync(to, ct);

        await _uow.StockMovements.AddAsync(new StockMovement
        {
            Id = Guid.NewGuid(), TenantId = cmd.TenantId,
            ProductId = req.ProductId, BranchId = req.FromBranchId, UserId = cmd.UserId,
            Type = StockMovementType.Transfer, TransferToId = req.ToBranchId,
            QuantityBefore = from.Quantity + req.Quantity, QuantityChange = -req.Quantity,
            QuantityAfter = from.Quantity, Notes = req.Notes,
        }, ct);

        await _uow.SaveChangesAsync(ct);
        await _cache.RemoveAsync(CacheKeys.ProductsByBranch(req.FromBranchId), ct);
        await _cache.RemoveAsync(CacheKeys.ProductsByBranch(req.ToBranchId), ct);

        var branch = await _uow.Branches.GetByIdAsync(req.ToBranchId, ct);
        var prod   = await _uow.Products.GetByIdAsync(req.ProductId, ct);
        return Result<StockItemDto>.Ok(new StockItemDto(
            to.ProductId, prod?.Name ?? "", null, null,
            to.BranchId, branch?.Name ?? "",
            to.Quantity, to.ReservedQuantity, to.AvailableQuantity,
            null, false, null));
    }

    private async Task InvalidateProductCaches(Guid tenantId, CancellationToken ct)
    {
        var branches = await _uow.Branches.FindAsync(b => b.TenantId == tenantId && b.IsActive, ct);
        foreach (var b in branches)
            await _cache.RemoveAsync(CacheKeys.ProductsByBranch(b.Id), ct);
    }

    private static ProductDto ToProductDto(Domain.Entities.Core.Product p, decimal? stock) => new(
        p.Id, p.Name, p.NameAr, p.Description, p.Barcode, p.SKU,
        p.Type, p.Unit, p.CostPrice, p.SalePrice, p.WholesalePrice, p.MinSalePrice,
        p.HasVat, p.VatRate, p.ImageUrl, p.IsActive, p.IsAvailableOnline, p.TrackInventory,
        p.LowStockThreshold, p.Category?.Name, p.CategoryId, stock);
}

// ════════════════════════════════════════════════════════════════════════════
// DashboardHandler
// ════════════════════════════════════════════════════════════════════════════
public sealed class DashboardHandler :
    IRequestHandler<GetDashboardQuery,    Result<DashboardStatsDto>>,
    IRequestHandler<GetSalesReportQuery,  Result<SalesReportDto>>
{
    private readonly IUnitOfWork             _uow;
    private readonly ICacheService           _cache;

    public DashboardHandler(IUnitOfWork uow, ICacheService cache)
    { _uow = uow; _cache = cache; }

    public async Task<Result<DashboardStatsDto>> Handle(GetDashboardQuery q, CancellationToken ct)
    {
        var key    = CacheKeys.DashboardStats(q.TenantId, DateOnly.FromDateTime(DateTime.UtcNow));
        var cached = await _cache.GetAsync<DashboardStatsDto>(key, ct);
        if (cached is not null) return Result<DashboardStatsDto>.Ok(cached);

        var today  = DateTime.UtcNow.Date;
        var month  = new DateTime(today.Year, today.Month, 1);
        var week   = today.AddDays(-6);

        var baseQ = _uow.SaleOrders.Query()
            .Where(o => o.TenantId == q.TenantId && !o.IsDeleted && o.Status != SaleStatus.Voided);
        if (q.BranchId.HasValue) baseQ = baseQ.Where(o => o.BranchId == q.BranchId.Value);

        var todayOrders = await baseQ.Where(o => o.CreatedAt >= today && o.CreatedAt < today.AddDays(1)).ToListAsync(ct);
        var monthOrders = await baseQ.Where(o => o.CreatedAt >= month).ToListAsync(ct);
        var weekOrders  = await baseQ.Where(o => o.CreatedAt >= week).Include(o => o.Items).ToListAsync(ct);

        var weekSales = Enumerable.Range(0, 7).Select(d => {
            var day = week.AddDays(d);
            var dd  = weekOrders.Where(o => o.CreatedAt.Date == day).ToList();
            return new DailySaleDto(DateOnly.FromDateTime(day),
                dd.Sum(o => o.TotalAmount), dd.Count,
                dd.Sum(o => o.Items?.Sum(i => (i.UnitPrice - i.CostPrice) * i.Quantity) ?? 0));
        }).ToList();

        var topProducts = weekOrders.Where(o => o.Items != null)
            .SelectMany(o => o.Items!)
            .GroupBy(i => new { i.ProductId, i.ProductName })
            .Select(g => new TopProductDto(
                g.Key.ProductId, g.Key.ProductName,
                (int)g.Sum(i => i.Quantity), g.Sum(i => i.LineTotal)))
            .OrderByDescending(x => x.Revenue).Take(5).ToList();

        var totalCustomers = await _uow.Customers.CountAsync(c => c.TenantId == q.TenantId && !c.IsDeleted, ct);
        var newThisMonth   = await _uow.Customers.CountAsync(c => c.TenantId == q.TenantId && c.CreatedAt >= month, ct);
        var totalProducts  = await _uow.Products.CountAsync(p => p.TenantId == q.TenantId && p.IsActive && !p.IsDeleted, ct);
        var lowStock       = await _uow.StockItems.Query()
            .Where(s => s.TenantId == q.TenantId && !s.IsDeleted)
            .Include(s => s.Product)
            .CountAsync(s => s.Product.TrackInventory && s.AvailableQuantity <= s.Product.LowStockThreshold, ct);
        var branches       = await _uow.Branches.CountAsync(b => b.TenantId == q.TenantId && b.IsActive && !b.IsDeleted, ct);

        var todayRevenue   = todayOrders.Sum(o => o.TotalAmount);
        var todayProfit    = weekOrders.Where(o => o.CreatedAt >= today && o.Items != null)
            .Sum(o => o.Items!.Sum(i => (i.UnitPrice - i.CostPrice) * i.Quantity));
        var avgOrder       = todayOrders.Count > 0 ? Math.Round(todayRevenue / todayOrders.Count, 2) : 0;

        var recent = await baseQ.OrderByDescending(o => o.CreatedAt).Take(5).ToListAsync(ct);
        var recentDtos = new List<RecentOrderDto>();
        foreach (var o in recent)
        {
            var cname = o.CustomerId.HasValue
                ? (await _uow.Customers.GetByIdAsync(o.CustomerId.Value, ct))?.Name : null;
            recentDtos.Add(new RecentOrderDto(o.Id, o.OrderNumber, cname, o.TotalAmount,
                o.PaymentMethod.ToString(), o.CreatedAt));
        }

        var dto = new DashboardStatsDto(
            todayRevenue, todayOrders.Count,
            monthOrders.Sum(o => o.TotalAmount), monthOrders.Count,
            totalCustomers, newThisMonth, totalProducts, lowStock, branches,
            avgOrder, todayProfit, weekSales, topProducts, recentDtos);

        await _cache.SetAsync(key, dto, TimeSpan.FromMinutes(2), ct);
        return Result<DashboardStatsDto>.Ok(dto);
    }

    public async Task<Result<SalesReportDto>> Handle(GetSalesReportQuery q, CancellationToken ct)
    {
        var req    = q.Request;
        var orders = await _uow.SaleOrders.Query()
            .Where(o => o.TenantId == q.TenantId && !o.IsDeleted
                     && o.Status != SaleStatus.Voided
                     && o.CreatedAt >= req.FromDate && o.CreatedAt < req.ToDate.AddDays(1))
            .Where(o => req.BranchId == null || o.BranchId == req.BranchId)
            .Include(o => o.Items).ToListAsync(ct);

        var byPeriod = req.GroupBy switch
        {
            "month" => orders.GroupBy(o => new DateTime(o.CreatedAt.Year, o.CreatedAt.Month, 1))
                .Select(g => new DailySaleDto(DateOnly.FromDateTime(g.Key),
                    g.Sum(o => o.TotalAmount), g.Count(),
                    g.Sum(o => o.Items?.Sum(i => (i.UnitPrice-i.CostPrice)*i.Quantity) ?? 0))).ToList(),
            "week"  => orders.GroupBy(o => o.CreatedAt.Date.AddDays(-(int)o.CreatedAt.DayOfWeek))
                .Select(g => new DailySaleDto(DateOnly.FromDateTime(g.Key),
                    g.Sum(o => o.TotalAmount), g.Count(),
                    g.Sum(o => o.Items?.Sum(i => (i.UnitPrice-i.CostPrice)*i.Quantity) ?? 0))).ToList(),
            _ => orders.GroupBy(o => o.CreatedAt.Date)
                .Select(g => new DailySaleDto(DateOnly.FromDateTime(g.Key),
                    g.Sum(o => o.TotalAmount), g.Count(),
                    g.Sum(o => o.Items?.Sum(i => (i.UnitPrice-i.CostPrice)*i.Quantity) ?? 0))).ToList(),
        };

        return Result<SalesReportDto>.Ok(new SalesReportDto(
            req.FromDate, req.ToDate,
            orders.Sum(o => o.TotalAmount), orders.Sum(o => o.VatAmount),
            orders.Sum(o => o.DiscountAmount),
            orders.Sum(o => o.TotalAmount - o.VatAmount),
            orders.Count,
            orders.Count > 0 ? Math.Round(orders.Sum(o => o.TotalAmount) / orders.Count, 2) : 0,
            byPeriod,
            orders.Where(o => o.Items != null).SelectMany(o => o.Items!)
                .GroupBy(i => new { i.ProductId, i.ProductName })
                .Select(g => new TopProductDto(g.Key.ProductId, g.Key.ProductName,
                    (int)g.Sum(i => i.Quantity), g.Sum(i => i.LineTotal)))
                .OrderByDescending(x => x.Revenue).Take(10).ToList(),
            orders.GroupBy(o => o.PaymentMethod.ToString())
                .ToDictionary(g => g.Key, g => g.Sum(o => o.TotalAmount))));
    }
}

// ════════════════════════════════════════════════════════════════════════════
// CustomerHandler
// ════════════════════════════════════════════════════════════════════════════
public sealed class CustomerHandler :
    IRequestHandler<GetCustomersQuery,     Result<PagedResult<CustomerDto>>>,
    IRequestHandler<GetCustomerQuery,       Result<CustomerDto>>,
    IRequestHandler<FindByPhoneQuery,       Result<CustomerDto>>,
    IRequestHandler<CreateCustomerCommand,  Result<CustomerDto>>,
    IRequestHandler<UpdateCustomerCommand,  Result<CustomerDto>>
{
    private readonly IUnitOfWork _uow;
    private readonly IAuditService _audit;
    public CustomerHandler(IUnitOfWork uow, IAuditService audit) { _uow = uow; _audit = audit; }

    public async Task<Result<PagedResult<CustomerDto>>> Handle(GetCustomersQuery q, CancellationToken ct)
    {
        var qry = _uow.Customers.Query()
            .Where(c => c.TenantId == q.TenantId && !c.IsDeleted)
            .Where(c => q.Search == null
                     || c.Name.Contains(q.Search)
                     || (c.Phone != null && c.Phone.Contains(q.Search))
                     || (c.Email != null && c.Email.Contains(q.Search)))
            .OrderByDescending(c => c.TotalPurchases);

        var total = await qry.CountAsync(ct);
        var items = await qry.Skip((q.Page - 1) * q.PageSize).Take(q.PageSize).ToListAsync(ct);
        return Result<PagedResult<CustomerDto>>.Ok(
            new PagedResult<CustomerDto>(items.Select(ToDto).ToList(), total, q.Page, q.PageSize));
    }

    public async Task<Result<CustomerDto>> Handle(GetCustomerQuery q, CancellationToken ct)
    {
        var c = await _uow.Customers.FirstOrDefaultAsync(
            x => x.Id == q.Id && x.TenantId == q.TenantId && !x.IsDeleted, ct);
        return c is null
            ? Result<CustomerDto>.Fail("العميل غير موجود", "NOT_FOUND")
            : Result<CustomerDto>.Ok(ToDto(c));
    }

    public async Task<Result<CustomerDto>> Handle(FindByPhoneQuery q, CancellationToken ct)
    {
        var c = await _uow.Customers.FirstOrDefaultAsync(
            x => x.Phone == q.Phone && x.TenantId == q.TenantId && !x.IsDeleted, ct);
        return c is null
            ? Result<CustomerDto>.Fail("لا يوجد عميل بهذا الرقم", "NOT_FOUND")
            : Result<CustomerDto>.Ok(ToDto(c));
    }

    public async Task<Result<CustomerDto>> Handle(CreateCustomerCommand cmd, CancellationToken ct)
    {
        if (cmd.Request.Phone is not null && await _uow.Customers.AnyAsync(
                c => c.Phone == cmd.Request.Phone && c.TenantId == cmd.TenantId && !c.IsDeleted, ct))
            return Result<CustomerDto>.Fail("رقم الهاتف مسجّل بالفعل", "DUPLICATE_PHONE");

        var c = new Customer
        {
            Id = Guid.NewGuid(), TenantId = cmd.TenantId,
            Name = cmd.Request.Name, Phone = cmd.Request.Phone,
            Email = cmd.Request.Email, Address = cmd.Request.Address,
            City = cmd.Request.City, Gender = cmd.Request.Gender,
            DateOfBirth = cmd.Request.DateOfBirth,
            Segment = CustomerSegment.New, IsActive = true,
        };
        await _uow.Customers.AddAsync(c, ct);
        await _uow.SaveChangesAsync(ct);
        await _audit.LogAsync(new AuditEntry(cmd.TenantId, cmd.UserId,
            AuditAction.Create, "Customer", c.Id,
            NewValues: new { c.Name, c.Phone }), ct);
        return Result<CustomerDto>.Ok(ToDto(c), "تم إضافة العميل");
    }

    public async Task<Result<CustomerDto>> Handle(UpdateCustomerCommand cmd, CancellationToken ct)
    {
        var c = await _uow.Customers.FirstOrDefaultAsync(
            x => x.Id == cmd.Id && x.TenantId == cmd.TenantId && !x.IsDeleted, ct);
        if (c is null) return Result<CustomerDto>.Fail("العميل غير موجود", "NOT_FOUND");

        c.Name = cmd.Request.Name; c.Phone = cmd.Request.Phone;
        c.Email = cmd.Request.Email; c.Address = cmd.Request.Address;
        c.City = cmd.Request.City; c.IsActive = cmd.Request.IsActive;
        c.Notes = cmd.Request.Notes;

        await _uow.SaveChangesAsync(ct);
        return Result<CustomerDto>.Ok(ToDto(c), "تم التحديث");
    }

    private static CustomerDto ToDto(Customer c) => new(
        c.Id, c.Name, c.Phone, c.Email, c.City,
        c.Segment, c.LoyaltyPoints, c.TotalPurchases,
        c.TotalOrders, c.LastPurchaseAt, c.IsActive, c.CreatedAt);
}
