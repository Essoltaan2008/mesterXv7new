'use client'
import { useEffect, useState, useCallback } from 'react'
import DashboardLayout from '../layout'
import { dashboardAPI } from '@/lib/api'
import { useAuth } from '@/store'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  AreaChart, Area,
} from 'recharts'
import toast from 'react-hot-toast'

// ── Helpers ──────────────────────────────────────────────────────────────────
const EGP = (n: number = 0) =>
  n.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' ج.م'

interface Stats {
  todayRevenue: number; todayOrders: number
  monthRevenue: number; monthOrders: number
  totalCustomers: number; newThisMonth: number
  totalProducts: number; lowStockCount: number
  activeBranches: number; avgOrderValue: number
  grossProfitToday: number
  weekSales: { date: string; revenue: number; orders: number; profit: number }[]
  topProducts: { productId: string; name: string; quantitySold: number; revenue: number }[]
  recentOrders: { id: string; orderNumber: string; customerName?: string; amount: number; paymentMethod: string; at: string }[]
}

function StatCard({ icon, label, value, sub, accent }: {
  icon: string; label: string; value: string; sub?: string; accent: string
}) {
  return (
    <div className={`card p-5 border-r-2 ${accent}`}>
      <span className="text-2xl block mb-3">{icon}</span>
      <p className="text-2xl font-bold text-slate-100 font-mono tabular-nums">{value}</p>
      <p className="text-xs text-slate-400 mt-1">{label}</p>
      {sub && <p className="text-xs text-slate-600 mt-0.5">{sub}</p>}
    </div>
  )
}

export default function DashboardPage() {
  const { user }    = useAuth()
  const [stats, setStats]   = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      const { data } = await dashboardAPI.stats()
      if (data.success) setStats(data.data)
    } catch { toast.error('فشل تحميل الإحصائيات') }
    finally { setLoading(false) }
  }, [])

  // Initial load + auto-refresh every 60 s
  useEffect(() => {
    load()
    const t = setInterval(load, 60_000)
    return () => clearInterval(t)
  }, [load])

  if (loading) return (
    <DashboardLayout title="الرئيسية">
      <div className="flex items-center justify-center h-80">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
          <p className="mt-3 text-sm text-slate-400">جاري التحميل...</p>
        </div>
      </div>
    </DashboardLayout>
  )

  const s = stats

  return (
    <DashboardLayout title="لوحة التحكم">
      <div className="p-6 space-y-6 animate-fade-up">

        {/* KPIs — row 1 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon="💰" label="مبيعات اليوم"   value={EGP(s?.todayRevenue)}  sub={`${s?.todayOrders ?? 0} طلب`}        accent="border-amber-500" />
          <StatCard icon="📅" label="مبيعات الشهر"   value={EGP(s?.monthRevenue)}  sub={`${s?.monthOrders ?? 0} طلب`}        accent="border-teal-500" />
          <StatCard icon="👥" label="إجمالي العملاء" value={(s?.totalCustomers ?? 0).toLocaleString()} sub={`+${s?.newThisMonth ?? 0} هذا الشهر`} accent="border-blue-500" />
          <StatCard icon="⚠️" label="نفذ مخزونها"    value={String(s?.lowStockCount ?? 0)} sub={`من ${s?.totalProducts ?? 0} منتج`} accent="border-red-500" />
        </div>

        {/* KPIs — row 2 */}
        <div className="grid grid-cols-3 gap-4">
          <StatCard icon="📊" label="متوسط الطلب"    value={EGP(s?.avgOrderValue)}     sub="لكل فاتورة"      accent="border-purple-500" />
          <StatCard icon="💹" label="أرباح اليوم"    value={EGP(s?.grossProfitToday)}  sub="هامش ربح صافٍ"   accent="border-green-500" />
          <StatCard icon="🏢" label="الفروع النشطة"  value={String(s?.activeBranches ?? 0)} sub="فرع مفعّل"  accent="border-slate-500" />
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Revenue Area Chart */}
          <div className="lg:col-span-2 card p-5">
            <h3 className="font-semibold text-sm text-slate-200 mb-4">المبيعات — آخر 7 أيام</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={s?.weekSales ?? []}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#d97706" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false}
                       tickFormatter={v => (v / 1000) + 'K'} />
                <Tooltip
                  contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                  labelStyle={{ color: '#94a3b8', fontSize: 11 }}
                  formatter={(v: any) => [EGP(v), 'المبيعات']}
                />
                <Area type="monotone" dataKey="revenue" stroke="#d97706" fill="url(#rev)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Top Products */}
          <div className="card p-5">
            <h3 className="font-semibold text-sm text-slate-200 mb-4">🏆 أكثر مبيعاً</h3>
            <div className="space-y-3">
              {(s?.topProducts ?? []).slice(0, 5).map((p, i) => (
                <div key={p.productId} className="flex items-center gap-3">
                  <span className="text-xs text-slate-500 w-4 flex-shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-slate-200 truncate">{p.name}</p>
                    <div className="h-1 bg-slate-700 rounded-full mt-1 overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all"
                        style={{ width: `${Math.min(100, (p.revenue / ((s?.topProducts[0]?.revenue ?? 1))) * 100)}%` }}
                      />
                    </div>
                  </div>
                  <span className="text-xs text-amber-400 font-mono flex-shrink-0">{EGP(p.revenue)}</span>
                </div>
              ))}
              {!s?.topProducts?.length && (
                <p className="text-xs text-slate-500 text-center py-6">لا توجد مبيعات بعد</p>
              )}
            </div>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="card overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-700/50 flex items-center justify-between">
            <h3 className="font-semibold text-sm text-slate-200">آخر الفواتير</h3>
            <a href="/reports" className="text-xs text-amber-400 hover:underline">عرض الكل ←</a>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  {['رقم الفاتورة', 'العميل', 'المبلغ', 'الدفع', 'الوقت'].map(h => (
                    <th key={h} className="table-hd">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(s?.recentOrders ?? []).map(o => (
                  <tr key={o.id} className="table-tr">
                    <td className="table-td font-mono text-amber-400 text-xs">{o.orderNumber}</td>
                    <td className="table-td">{o.customerName ?? <span className="text-slate-500">زائر</span>}</td>
                    <td className="table-td font-semibold">{EGP(o.amount)}</td>
                    <td className="table-td">
                      <span className="badge-slate">{o.paymentMethod}</span>
                    </td>
                    <td className="table-td text-slate-400 text-xs">
                      {new Date(o.at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
                {!s?.recentOrders?.length && (
                  <tr>
                    <td colSpan={5} className="table-td text-center text-slate-500 py-10">
                      لا توجد فواتير اليوم
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </DashboardLayout>
  )
}
