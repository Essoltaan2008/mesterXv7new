using FluentAssertions;
using MesterX.Infrastructure.Services;
using Xunit;

namespace MesterX.Tests.Unit;

/// <summary>
/// Tests for SecurityHelper — the most security-critical class in the system.
/// These tests verify BCrypt hashing, password policy enforcement, and the
/// salted refresh-token scheme that replaced the previous plain-SHA256 approach.
/// </summary>
public sealed class SecurityHelperTests
{
    // ── BCrypt password hashing ───────────────────────────────────────────────

    [Fact]
    public void HashPassword_ProducesBCryptHash()
    {
        var hash = SecurityHelper.HashPassword("Test@12345!");
        // BCrypt always starts with $2a$12$ or $2b$12$ for work factor 12
        hash.Should().MatchRegex(@"^\$2[ab]\$12\$.+");
    }

    [Fact]
    public void VerifyPassword_CorrectPassword_ReturnsTrue()
    {
        var hash = SecurityHelper.HashPassword("Test@12345!");
        SecurityHelper.VerifyPassword("Test@12345!", hash).Should().BeTrue();
    }

    [Fact]
    public void VerifyPassword_WrongPassword_ReturnsFalse()
    {
        var hash = SecurityHelper.HashPassword("Test@12345!");
        SecurityHelper.VerifyPassword("WrongPassword!", hash).Should().BeFalse();
    }

    [Fact]
    public void VerifyPassword_EmptyInput_ReturnsFalse()
    {
        var hash = SecurityHelper.HashPassword("Test@12345!");
        SecurityHelper.VerifyPassword("", hash).Should().BeFalse();
    }

    [Fact]
    public void HashPassword_SameInput_ProducesDifferentHashes()
    {
        // BCrypt generates a unique salt for each call — this is critical
        var h1 = SecurityHelper.HashPassword("Same@Pass1!");
        var h2 = SecurityHelper.HashPassword("Same@Pass1!");
        h1.Should().NotBe(h2, "BCrypt must use a unique salt on every call");
    }

    // ── Password policy ───────────────────────────────────────────────────────

    [Theory]
    [InlineData("short1!",   false, "8 أحرف")]
    [InlineData("alllower1!", false, "حرف كبير")]
    [InlineData("ALLUPPER1!", false, "رمز خاص")]
    [InlineData("NoNumber@",  false, "رقم")]
    [InlineData("Valid@12345!",true, null)]
    public void ValidatePolicy_EnforcesAllRules(string pwd, bool expected, string? errorHint)
    {
        var (ok, err) = SecurityHelper.ValidatePolicy(pwd);
        ok.Should().Be(expected);
        if (!expected) err.Should().NotBeNullOrEmpty();
    }

    // ── Salted refresh tokens ─────────────────────────────────────────────────

    [Fact]
    public void GenerateRefreshToken_ReturnsThreeDistinctValues()
    {
        var (raw, hash, salt) = SecurityHelper.GenerateRefreshToken();
        raw.Should().NotBeNullOrWhiteSpace();
        hash.Should().NotBeNullOrWhiteSpace();
        salt.Should().NotBeNullOrWhiteSpace();
        // All three must be distinct
        new[] { raw, hash, salt }.Distinct().Should().HaveCount(3);
    }

    [Fact]
    public void VerifyRefreshToken_CorrectToken_ReturnsTrue()
    {
        var (raw, hash, salt) = SecurityHelper.GenerateRefreshToken();
        SecurityHelper.VerifyRefreshToken(raw, hash, salt).Should().BeTrue();
    }

    [Fact]
    public void VerifyRefreshToken_TamperedToken_ReturnsFalse()
    {
        var (_, hash, salt) = SecurityHelper.GenerateRefreshToken();
        // Attacker cannot forge a valid token without the correct raw value
        SecurityHelper.VerifyRefreshToken("tampered_token_by_attacker", hash, salt).Should().BeFalse();
    }

    [Fact]
    public void VerifyRefreshToken_WrongSalt_ReturnsFalse()
    {
        var (raw, hash, _) = SecurityHelper.GenerateRefreshToken();
        var (_, _, otherSalt) = SecurityHelper.GenerateRefreshToken();
        // Verifying the same token with a different salt must fail
        SecurityHelper.VerifyRefreshToken(raw, hash, otherSalt).Should().BeFalse();
    }

    [Fact]
    public void GenerateRefreshToken_TwoCalls_ProduceDifferentTokens()
    {
        var (r1, _, _) = SecurityHelper.GenerateRefreshToken();
        var (r2, _, _) = SecurityHelper.GenerateRefreshToken();
        r1.Should().NotBe(r2);
    }

    // ── Hash helpers ──────────────────────────────────────────────────────────

    [Fact]
    public void HashSha256_SameInput_SameOutput_Always()
    {
        SecurityHelper.HashSha256("test_input").Should()
            .Be(SecurityHelper.HashSha256("test_input"))
            .And.HaveLength(64); // 256 bits / 4 bits per hex char
    }

    [Fact]
    public void HashSha512_SameInput_SameOutput_Always()
    {
        SecurityHelper.HashSha512("test_input").Should()
            .Be(SecurityHelper.HashSha512("test_input"))
            .And.HaveLength(128); // 512 bits / 4 bits per hex char
    }
}
