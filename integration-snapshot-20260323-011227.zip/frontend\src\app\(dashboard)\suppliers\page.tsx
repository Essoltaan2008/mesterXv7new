'use client'
import { useState, useEffect, useCallback } from 'react'
import DashboardLayout from '../../layout'
import { api } from '@/lib/api'
import toast from 'react-hot-toast'

// Suppliers page — manages vendors and purchase orders
// Egyptian businesses typically track suppliers by credit limit and outstanding balance

const EGP = (n = 0) => n.toLocaleString('ar-EG', { minimumFractionDigits: 2 }) + ' ج.م'

const STATUS_LABEL: Record<number, string> = { 0: 'نشط', 1: 'غير نشط', 2: 'محظور' }
const STATUS_COLOR: Record<number, string> = {
  0: 'badge-green', 1: 'badge-slate', 2: 'badge-red'
}

export default function SuppliersPage() {
  const [suppliers, setSuppliers]   = useState<any[]>([])
  const [search, setSearch]         = useState('')
  const [loading, setLoading]       = useState(false)
  const [page, setPage]             = useState(1)
  const [total, setTotal]           = useState(0)
  const [showForm, setShowForm]     = useState(false)
  const [saving, setSaving]         = useState(false)
  const [form, setForm]             = useState({
    name: '', contactPerson: '', phone: '', email: '',
    address: '', city: '', taxNumber: '', creditLimit: '', paymentTermsDays: '30'
  })

  const PAGE_SIZE = 20

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.get(
        `/suppliers?page=${page}&pageSize=${PAGE_SIZE}${search ? `&search=${encodeURIComponent(search)}` : ''}`
      )
      setSuppliers(data.data?.items ?? [])
      setTotal(data.data?.totalCount ?? 0)
    } catch { toast.error('فشل تحميل الموردين') }
    finally { setLoading(false) }
  }, [page, search])

  useEffect(() => { load() }, [load])

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim()) { toast.error('اسم المورد مطلوب'); return }
    setSaving(true)
    try {
      const payload = {
        ...form,
        creditLimit: parseFloat(form.creditLimit) || 0,
        paymentTermsDays: parseInt(form.paymentTermsDays) || 30,
      }
      const { data } = await api.post('/suppliers', payload)
      if (data.success) {
        toast.success('تم إضافة المورد')
        setShowForm(false)
        resetForm()
        load()
      } else toast.error(data.message || 'فشل الإضافة')
    } catch (e: any) { toast.error(e?.response?.data?.message ?? 'فشل الإضافة') }
    finally { setSaving(false) }
  }

  const resetForm = () => setForm({
    name: '', contactPerson: '', phone: '', email: '',
    address: '', city: '', taxNumber: '', creditLimit: '', paymentTermsDays: '30'
  })

  const totalPages = Math.ceil(total / PAGE_SIZE)

  return (
    <DashboardLayout title="الموردون">
      <div className="p-6 space-y-6 animate-fade-up">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100">إدارة الموردين</h2>
            <p className="text-sm text-slate-400 mt-0.5">{total.toLocaleString()} مورد مسجّل</p>
          </div>
          <div className="flex gap-2">
            <input
              className="input w-52"
              placeholder="🔍 بحث باسم أو هاتف..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }}
            />
            <button onClick={() => setShowForm(true)} className="btn-primary">
              + إضافة مورد
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr>
                {['المورد', 'جهة الاتصال', 'الهاتف', 'المدينة', 'حد الائتمان', 'الرصيد المعلق', 'أيام السداد', 'الحالة'].map(h => (
                  <th key={h} className="table-hd">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="table-td text-center py-12">
                  <div className="w-8 h-8 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin mx-auto" />
                </td></tr>
              ) : suppliers.length === 0 ? (
                <tr><td colSpan={8} className="table-td text-center py-12">
                  <p className="text-3xl mb-2">🏭</p>
                  <p className="text-sm text-slate-500">{search ? 'لا توجد نتائج' : 'لم يُضف أي مورد بعد'}</p>
                </td></tr>
              ) : suppliers.map((s: any) => (
                <tr key={s.id} className="table-tr">
                  <td className="table-td">
                    <p className="font-medium text-slate-100">{s.name}</p>
                    {s.taxNumber && <p className="text-xs text-slate-500 mt-0.5">رقم ضريبي: {s.taxNumber}</p>}
                  </td>
                  <td className="table-td text-slate-400">{s.contactPerson ?? '—'}</td>
                  <td className="table-td font-mono text-sm">{s.phone ?? '—'}</td>
                  <td className="table-td text-slate-400">{s.city ?? '—'}</td>
                  <td className="table-td text-amber-400 font-semibold font-mono">{EGP(s.creditLimit)}</td>
                  <td className="table-td">
                    <span className={s.outstandingBalance > 0 ? 'text-red-400 font-semibold' : 'text-green-400'}>
                      {EGP(s.outstandingBalance)}
                    </span>
                  </td>
                  <td className="table-td text-slate-400">{s.paymentTermsDays} يوم</td>
                  <td className="table-td">
                    <span className={STATUS_COLOR[s.status] ?? 'badge-slate'}>
                      {STATUS_LABEL[s.status] ?? '—'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="px-4 py-3 border-t border-slate-700/50 flex items-center justify-between text-xs text-slate-400">
              <span>{total} مورد</span>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-sm btn-ghost">السابق</button>
                <span className="px-3 py-1.5 bg-slate-700/50 rounded-lg">{page} / {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="btn-sm btn-ghost">التالي</button>
              </div>
            </div>
          )}
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'إجمالي الموردين', value: total, icon: '🏭', color: 'border-amber-500' },
            { label: 'موردون نشطون',   value: suppliers.filter(s => s.status === 0).length, icon: '✅', color: 'border-green-500' },
            { label: 'إجمالي مستحق',   value: EGP(suppliers.reduce((a, s) => a + (s.outstandingBalance ?? 0), 0)), icon: '💳', color: 'border-red-500' },
            { label: 'متوسط أيام السداد', value: suppliers.length ? Math.round(suppliers.reduce((a, s) => a + (s.paymentTermsDays ?? 30), 0) / suppliers.length) + ' يوم' : '—', icon: '📅', color: 'border-blue-500' },
          ].map(c => (
            <div key={c.label} className={`card p-4 border-r-2 ${c.color}`}>
              <span className="text-xl block mb-2">{c.icon}</span>
              <p className="text-lg font-bold text-slate-100 font-mono">{typeof c.value === 'number' ? c.value.toLocaleString() : c.value}</p>
              <p className="text-xs text-slate-400 mt-1">{c.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Add Supplier Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="card max-w-lg w-full p-6 animate-fade-up" dir="rtl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-slate-100 text-base">إضافة مورد جديد</h3>
              <button onClick={() => { setShowForm(false); resetForm() }} className="text-slate-500 hover:text-slate-200 transition text-xl leading-none">&times;</button>
            </div>
            <form onSubmit={save} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="label">اسم المورد *</label>
                  <input className="input" placeholder="شركة..." required
                    value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                </div>
                <div>
                  <label className="label">جهة الاتصال</label>
                  <input className="input" placeholder="اسم المسؤول..."
                    value={form.contactPerson} onChange={e => setForm(f => ({ ...f, contactPerson: e.target.value }))} />
                </div>
                <div>
                  <label className="label">رقم الهاتف</label>
                  <input className="input" placeholder="01xxxxxxxxx" type="tel"
                    value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                </div>
                <div>
                  <label className="label">البريد الإلكتروني</label>
                  <input className="input" placeholder="email@..." type="email"
                    value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
                <div>
                  <label className="label">المدينة</label>
                  <input className="input" placeholder="القاهرة..."
                    value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
                </div>
                <div>
                  <label className="label">حد الائتمان (ج.م)</label>
                  <input className="input" placeholder="0" type="number" min="0"
                    value={form.creditLimit} onChange={e => setForm(f => ({ ...f, creditLimit: e.target.value }))} />
                </div>
                <div>
                  <label className="label">أيام السداد</label>
                  <select className="select"
                    value={form.paymentTermsDays} onChange={e => setForm(f => ({ ...f, paymentTermsDays: e.target.value }))}>
                    {[7, 14, 30, 45, 60, 90].map(d => (
                      <option key={d} value={d}>{d} يوم</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">الرقم الضريبي</label>
                  <input className="input" placeholder="اختياري"
                    value={form.taxNumber} onChange={e => setForm(f => ({ ...f, taxNumber: e.target.value }))} />
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? '⏳ جاري الحفظ...' : '✅ حفظ المورد'}
                </button>
                <button type="button" onClick={() => { setShowForm(false); resetForm() }} className="btn-ghost">
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
