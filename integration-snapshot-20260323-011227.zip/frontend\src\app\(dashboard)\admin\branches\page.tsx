'use client'
import { useState, useEffect, useCallback } from 'react'
import DashboardLayout from '../../../layout'
import { api } from '@/lib/api'
import { useAuth } from '@/store'
import toast from 'react-hot-toast'

export default function AdminBranchesPage() {
  const { user: currentUser } = useAuth()
  const [branches, setBranches]   = useState<any[]>([])
  const [loading, setLoading]     = useState(false)
  const [showForm, setShowForm]   = useState(false)
  const [editBranch, setEditBranch] = useState<any>(null)
  const [saving, setSaving]       = useState(false)
  const [form, setForm] = useState({
    name: '', nameAr: '', code: '', address: '', city: '',
    phoneNumber: '', email: '', isMain: false,
    openTime: '08:00', closeTime: '22:00',
  })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.get('/admin/branches')
      setBranches(data.data ?? [])
    } catch { toast.error('فشل تحميل الفروع') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openCreate = () => {
    setEditBranch(null)
    setForm({ name: '', nameAr: '', code: '', address: '', city: '', phoneNumber: '', email: '', isMain: false, openTime: '08:00', closeTime: '22:00' })
    setShowForm(true)
  }

  const openEdit = (b: any) => {
    setEditBranch(b)
    setForm({
      name: b.name, nameAr: b.nameAr ?? '', code: b.code ?? '',
      address: b.address ?? '', city: b.city ?? '',
      phoneNumber: b.phoneNumber ?? '', email: b.email ?? '',
      isMain: b.isMain, openTime: b.openTime ?? '08:00', closeTime: b.closeTime ?? '22:00',
    })
    setShowForm(true)
  }

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim()) { toast.error('اسم الفرع مطلوب'); return }
    setSaving(true)
    try {
      const { data } = editBranch
        ? await api.put(`/admin/branches/${editBranch.id}`, form)
        : await api.post('/admin/branches', form)
      if (data.success) { toast.success(editBranch ? 'تم تحديث الفرع' : 'تم إضافة الفرع'); setShowForm(false); load() }
      else toast.error(data.message ?? 'فشل الحفظ')
    } catch (e: any) { toast.error(e?.response?.data?.message ?? 'فشل الحفظ') }
    finally { setSaving(false) }
  }

  const toggleActive = async (b: any) => {
    try {
      const { data } = await api.patch(`/admin/branches/${b.id}/toggle-active`)
      if (data.success) { toast.success(`تم ${b.isActive ? 'تعطيل' : 'تفعيل'} الفرع`); load() }
    } catch { toast.error('فشل التغيير') }
  }

  if (currentUser && currentUser.role > 3) {
    return (
      <DashboardLayout title="إدارة الفروع">
        <div className="flex flex-col items-center justify-center h-64 text-slate-500">
          <p className="text-4xl mb-3">🔒</p>
          <p className="text-sm">ليس لديك صلاحية للوصول إلى هذه الصفحة</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout title="إدارة الفروع">
      <div className="p-6 space-y-6 animate-fade-up">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-100">الفروع</h2>
            <p className="text-sm text-slate-400 mt-0.5">{branches.length} فرع مسجّل</p>
          </div>
          <button onClick={openCreate} className="btn-primary">+ إضافة فرع</button>
        </div>

        {/* Branch cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="card p-5 animate-pulse">
                <div className="h-4 bg-slate-700 rounded w-3/4 mb-3" />
                <div className="h-3 bg-slate-700/60 rounded w-1/2" />
              </div>
            ))
          ) : branches.length === 0 ? (
            <div className="col-span-3 card p-12 text-center text-slate-500">
              <p className="text-4xl mb-3">🏢</p>
              <p className="text-sm">لم يُضف أي فرع بعد</p>
            </div>
          ) : branches.map((b: any) => (
            <div key={b.id} className={`card p-5 ${b.isMain ? 'border-amber-500/40' : ''}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-slate-100 truncate">{b.name}</h3>
                    {b.isMain && <span className="badge-gold text-xs">رئيسي</span>}
                    <span className={b.isActive ? 'badge-green' : 'badge-red'}>
                      {b.isActive ? 'نشط' : 'معطّل'}
                    </span>
                  </div>
                  {b.code && <p className="text-xs text-slate-500 font-mono mt-0.5">#{b.code}</p>}
                </div>
              </div>

              <div className="space-y-1.5 text-sm text-slate-400 mb-4">
                {b.city    && <p className="flex items-center gap-2"><span>📍</span>{b.address ? `${b.city} — ${b.address}` : b.city}</p>}
                {b.phoneNumber && <p className="flex items-center gap-2"><span>📞</span><span className="font-mono">{b.phoneNumber}</span></p>}
                {b.email   && <p className="flex items-center gap-2"><span>📧</span>{b.email}</p>}
                {(b.openTime || b.closeTime) && (
                  <p className="flex items-center gap-2">
                    <span>🕐</span>
                    <span className="font-mono">{b.openTime ?? '--:--'} — {b.closeTime ?? '--:--'}</span>
                  </p>
                )}
                {b.managerName && <p className="flex items-center gap-2"><span>👤</span>المدير: {b.managerName}</p>}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="bg-slate-700/40 rounded-lg p-2.5 text-center">
                  <p className="text-lg font-bold text-slate-100">{b.userCount ?? 0}</p>
                  <p className="text-xs text-slate-500">مستخدم</p>
                </div>
                <div className="bg-slate-700/40 rounded-lg p-2.5 text-center">
                  <p className="text-lg font-bold text-slate-100">{b.productCount ?? 0}</p>
                  <p className="text-xs text-slate-500">منتج</p>
                </div>
              </div>

              <div className="flex gap-2">
                <button onClick={() => openEdit(b)} className="btn-ghost btn-sm flex-1">تعديل</button>
                {!b.isMain && (
                  <button onClick={() => toggleActive(b)}
                    className={`btn-sm ${b.isActive ? 'btn-danger' : 'btn-teal'}`}>
                    {b.isActive ? 'تعطيل' : 'تفعيل'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Branch Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="card max-w-lg w-full p-6 animate-fade-up max-h-[90vh] overflow-y-auto" dir="rtl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-slate-100 text-base">
                {editBranch ? 'تعديل الفرع' : 'إضافة فرع جديد'}
              </h3>
              <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-slate-200 transition text-xl leading-none">&times;</button>
            </div>
            <form onSubmit={save} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">اسم الفرع بالعربي *</label>
                  <input className="input" required value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                </div>
                <div>
                  <label className="label">الاسم بالإنجليزي</label>
                  <input className="input" dir="ltr" value={form.nameAr}
                    onChange={e => setForm(f => ({ ...f, nameAr: e.target.value }))} />
                </div>
                <div>
                  <label className="label">كود الفرع</label>
                  <input className="input" placeholder="مثال: BR01" dir="ltr" value={form.code}
                    onChange={e => setForm(f => ({ ...f, code: e.target.value }))} />
                </div>
                <div>
                  <label className="label">المدينة</label>
                  <input className="input" placeholder="القاهرة..." value={form.city}
                    onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
                </div>
                <div className="col-span-2">
                  <label className="label">العنوان التفصيلي</label>
                  <input className="input" placeholder="الشارع، الحي..." value={form.address}
                    onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
                </div>
                <div>
                  <label className="label">رقم الهاتف</label>
                  <input className="input" type="tel" value={form.phoneNumber}
                    onChange={e => setForm(f => ({ ...f, phoneNumber: e.target.value }))} />
                </div>
                <div>
                  <label className="label">البريد الإلكتروني</label>
                  <input className="input" type="email" dir="ltr" value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                </div>
                <div>
                  <label className="label">وقت الفتح</label>
                  <input className="input" type="time" value={form.openTime}
                    onChange={e => setForm(f => ({ ...f, openTime: e.target.value }))} />
                </div>
                <div>
                  <label className="label">وقت الإغلاق</label>
                  <input className="input" type="time" value={form.closeTime}
                    onChange={e => setForm(f => ({ ...f, closeTime: e.target.value }))} />
                </div>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={form.isMain} onChange={e => setForm(f => ({ ...f, isMain: e.target.checked }))} className="w-4 h-4 accent-amber-500" />
                <span className="text-sm text-slate-300">هذا هو الفرع الرئيسي</span>
              </label>
              <div className="flex gap-3 pt-1">
                <button type="submit" disabled={saving} className="btn-primary flex-1">
                  {saving ? '⏳ جاري الحفظ...' : editBranch ? '💾 حفظ التغييرات' : '✅ إضافة الفرع'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-ghost">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
