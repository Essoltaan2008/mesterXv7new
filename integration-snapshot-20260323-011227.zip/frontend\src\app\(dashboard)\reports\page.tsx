'use client'
import { useState } from 'react'
import DashboardLayout from '../../layout'
import { dashboardAPI } from '@/lib/api'
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from 'recharts'
import toast from 'react-hot-toast'

const EGP  = (n = 0) => n.toLocaleString('ar-EG', { minimumFractionDigits: 2 }) + ' ج.م'
const CLRS = ['#d97706','#0d9488','#3b82f6','#8b5cf6','#ec4899']

export default function ReportsPage() {
  const today      = new Date().toISOString().split('T')[0]
  const monthStart = today.slice(0, 8) + '01'

  const [from,    setFrom]    = useState(monthStart)
  const [to,      setTo]      = useState(today)
  const [groupBy, setGroupBy] = useState<'day'|'week'|'month'>('day')
  const [report,  setReport]  = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const { data } = await dashboardAPI.report({ fromDate: from, toDate: to, groupBy })
      if (data.success) setReport(data.data)
      else toast.error('فشل تحميل التقرير')
    } catch { toast.error('خطأ في الاتصال') }
    finally { setLoading(false) }
  }

  const payData = report
    ? Object.entries(report.byPaymentMethod ?? {}).map(([name, value]) => ({ name, value }))
    : []

  return (
    <DashboardLayout title="تقارير المبيعات">
      <div className="p-6 animate-fade-up space-y-6">

        {/* Filters */}
        <div className="card p-4 flex flex-wrap items-end gap-4">
          {[['من', from, setFrom], ['إلى', to, setTo]].map(([label, val, setter]: any) => (
            <div key={label}>
              <label className="label">{label} تاريخ</label>
              <input type="date" className="input" value={val} onChange={e => setter(e.target.value)} />
            </div>
          ))}
          <div>
            <label className="label">تجميع</label>
            <select className="select" value={groupBy} onChange={e => setGroupBy(e.target.value as any)}>
              <option value="day">يومي</option>
              <option value="week">أسبوعي</option>
              <option value="month">شهري</option>
            </select>
          </div>
          <button onClick={load} disabled={loading} className="btn-primary">
            {loading ? '⏳ ...' : '📊 عرض التقرير'}
          </button>
          {report && <button onClick={() => window.print()} className="btn-ghost">🖨️ طباعة</button>}
        </div>

        {/* KPIs */}
        {report && <>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              ['💰', 'إجمالي المبيعات',   EGP(report.totalRevenue),  'border-amber-500'],
              ['📈', 'صافي المبيعات',      EGP(report.netRevenue),    'border-teal-500'],
              ['🏦', 'إجمالي الضريبة',    EGP(report.totalVat),      'border-blue-500'],
              ['🎁', 'إجمالي الخصومات',  EGP(report.totalDiscount), 'border-purple-500'],
              ['📊', 'متوسط قيمة الطلب', EGP(report.avgOrderValue), 'border-slate-500'],
            ].map(([icon, label, value, border]: any) => (
              <div key={label} className={`card p-5 border-r-2 ${border}`}>
                <span className="text-xl block mb-2">{icon}</span>
                <p className="text-lg font-bold font-mono text-slate-100">{value}</p>
                <p className="text-xs text-slate-400 mt-1">{label}</p>
              </div>
            ))}
          </div>

          {/* Revenue Chart */}
          <div className="card p-5">
            <h3 className="font-semibold text-sm text-slate-200 mb-4">📈 المبيعات عبر الزمن</h3>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={report.byPeriod ?? []}>
                <defs>
                  <linearGradient id="rev2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => (v/1000)+'K'} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                  formatter={(v: any) => [EGP(v), 'المبيعات']} />
                <Area type="monotone" dataKey="revenue" stroke="#d97706" fill="url(#rev2)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Bottom row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card p-5">
              <h3 className="font-semibold text-sm text-slate-200 mb-4">🏆 أكثر المنتجات مبيعاً</h3>
              <table className="w-full text-xs">
                <thead><tr>{['المنتج','الكمية','الإيرادات'].map(h=><th key={h} className="table-hd pb-2 text-right">{h}</th>)}</tr></thead>
                <tbody>
                  {(report.topProducts ?? []).map((p: any, i: number) => (
                    <tr key={i} className="border-t border-slate-700/40">
                      <td className="py-2 text-slate-200">{p.name}</td>
                      <td className="py-2 text-slate-400">{p.quantitySold}</td>
                      <td className="py-2 text-amber-400 font-mono">{EGP(p.revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="card p-5">
              <h3 className="font-semibold text-sm text-slate-200 mb-4">💳 طرق الدفع</h3>
              {payData.length > 0 ? (
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={payData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                      {payData.map((_, i) => <Cell key={i} fill={CLRS[i % CLRS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v: any) => EGP(v)} contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <p className="text-center text-slate-500 text-sm py-10">لا توجد بيانات</p>}
            </div>
          </div>
        </>}

        {!report && !loading && (
          <div className="card p-16 text-center text-slate-500">
            <p className="text-5xl mb-4">📊</p>
            <p className="text-sm">اختر الفترة الزمنية واضغط "عرض التقرير"</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
