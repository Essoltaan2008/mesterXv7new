using MediatR;
using MesterX.Application.Common;
using MesterX.Application.Features.License;
using MesterX.Domain.Enums;
using MesterX.Domain.Interfaces;
using MesterX.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace MesterX.Application.Services;

public sealed class LicenseHandler :
    IRequestHandler<GetLicenseStatusQuery, Result<LicenseStatusDto>>,
    IRequestHandler<GetPlansQuery,         Result<IReadOnlyList<PlanDto>>>,
    IRequestHandler<ActivateLicenseCommand,Result<LicenseStatusDto>>,
    IRequestHandler<ActivateSyncCommand,   Result<LicenseStatusDto>>,
    IRequestHandler<ValidateDeviceCommand, Result<bool>>
{
    private readonly IUnitOfWork             _uow;
    private readonly ICacheService           _cache;
    private readonly ILogger<LicenseHandler> _log;

    public LicenseHandler(IUnitOfWork uow, ICacheService cache, ILogger<LicenseHandler> log)
    { _uow = uow; _cache = cache; _log = log; }

    public async Task<Result<LicenseStatusDto>> Handle(GetLicenseStatusQuery q, CancellationToken ct)
    {
        var cacheKey = CacheKeys.TenantLicense(q.TenantId);
        var cached   = await _cache.GetAsync<LicenseStatusDto>(cacheKey, ct);
        if (cached is not null) return Result<LicenseStatusDto>.Ok(cached);

        var lic = await _uow.Licenses.FirstOrDefaultAsync(
            l => l.TenantId == q.TenantId && !l.IsDeleted, ct);
        if (lic is null)
            return Result<LicenseStatusDto>.Fail("لم يتم العثور على ترخيص", "NOT_FOUND");

        var currentBranches  = await _uow.Branches.CountAsync(b => b.TenantId == q.TenantId && !b.IsDeleted, ct);
        var currentUsers     = await _uow.Users.CountAsync(u => u.TenantId == q.TenantId && u.IsActive && !u.IsDeleted, ct);
        var currentProducts  = await _uow.Products.CountAsync(p => p.TenantId == q.TenantId && p.IsActive && !p.IsDeleted, ct);

        var now      = DateTime.UtcNow;
        var isExp    = lic.ExpiresAt.HasValue && lic.ExpiresAt.Value < now;
        var daysLeft = lic.ExpiresAt.HasValue && lic.ExpiresAt.Value > now
            ? (int)(lic.ExpiresAt.Value - now).TotalDays : (int?)null;

        var dto = new LicenseStatusDto(
            lic.PlanType, lic.Status,
            lic.ActivatedAt, lic.ExpiresAt,
            lic.SyncAddonActive, lic.SyncAddonExpiresAt,
            lic.MaxBranches, lic.MaxUsers, lic.MaxProducts,
            currentBranches, currentUsers, currentProducts,
            lic.DowngradeReason, isExp, daysLeft);

        await _cache.SetAsync(cacheKey, dto, TimeSpan.FromMinutes(5), ct);
        return Result<LicenseStatusDto>.Ok(dto);
    }

    public async Task<Result<IReadOnlyList<PlanDto>>> Handle(GetPlansQuery _, CancellationToken ct)
    {
        var cached = await _cache.GetAsync<IReadOnlyList<PlanDto>>(CacheKeys.Plans, ct);
        if (cached is not null) return Result<IReadOnlyList<PlanDto>>.Ok(cached);

        var plans = await _uow.Plans.Query()
            .Where(p => p.IsActive && !p.IsDeleted)
            .OrderBy(p => p.SortOrder)
            .ToListAsync(ct);

        var dtos = plans.Select(p => new PlanDto(
            p.Id, p.Name, p.NameEn, p.Type,
            p.MonthlyPrice, p.AnnualPrice,
            p.MaxBranches, p.MaxUsers, p.MaxProducts,
            p.HasSyncEngine, p.HasAdvancedReports,
            p.HasApiAccess, p.HasWhiteLabel,
            p.HasRestaurantModule, p.HasRentalModule, p.HasAi))
            .ToList();

        await _cache.SetAsync(CacheKeys.Plans, (IReadOnlyList<PlanDto>)dtos,
            TimeSpan.FromHours(1), ct);
        return Result<IReadOnlyList<PlanDto>>.Ok(dtos);
    }

    public async Task<Result<LicenseStatusDto>> Handle(ActivateLicenseCommand cmd, CancellationToken ct)
    {
        var keyHash = SecurityHelper.HashSha512(cmd.Request.LicenseKey);
        var fpHash  = SecurityHelper.HashSha256(cmd.Request.DeviceFingerprint);

        // In production: verify against your license issuing system
        // For now: create/update the license record
        var existing = await _uow.Licenses.FirstOrDefaultAsync(
            l => l.TenantId == cmd.TenantId && !l.IsDeleted, ct);

        if (existing is not null)
        {
            existing.LicenseKeyHash       = keyHash;
            existing.DeviceFingerprintHash= fpHash;
            existing.Status               = LicenseStatus.Active;
            existing.ActivatedAt          = DateTime.UtcNow;
        }
        else
        {
            await _uow.Licenses.AddAsync(new Domain.Entities.Billing.License
            {
                Id = Guid.NewGuid(), TenantId = cmd.TenantId,
                LicenseKeyHash        = keyHash,
                DeviceFingerprintHash = fpHash,
                PlanType   = PlanType.ProMonthly,
                Status     = LicenseStatus.Active,
                ActivatedAt= DateTime.UtcNow,
                ExpiresAt  = DateTime.UtcNow.AddMonths(1),
                MaxBranches= 5, MaxUsers = 20, MaxProducts = 5000,
            }, ct);
        }

        await _uow.SaveChangesAsync(ct);
        await _cache.RemoveAsync(CacheKeys.TenantLicense(cmd.TenantId), ct);
        return await Handle(new GetLicenseStatusQuery(cmd.TenantId), ct);
    }

    public async Task<Result<LicenseStatusDto>> Handle(ActivateSyncCommand cmd, CancellationToken ct)
    {
        var lic = await _uow.Licenses.FirstOrDefaultAsync(
            l => l.TenantId == cmd.TenantId && !l.IsDeleted, ct);
        if (lic is null) return Result<LicenseStatusDto>.Fail("لا يوجد ترخيص نشط", "NOT_FOUND");

        lic.SyncAddonActive    = true;
        lic.SyncAddonExpiresAt = DateTime.UtcNow.AddYears(1);
        await _uow.SaveChangesAsync(ct);
        await _cache.RemoveAsync(CacheKeys.TenantLicense(cmd.TenantId), ct);
        return await Handle(new GetLicenseStatusQuery(cmd.TenantId), ct);
    }

    public async Task<Result<bool>> Handle(ValidateDeviceCommand cmd, CancellationToken ct)
    {
        var fpHash = SecurityHelper.HashSha256(cmd.Request.DeviceFingerprint);
        var lic    = await _uow.Licenses.FirstOrDefaultAsync(
            l => l.TenantId == cmd.TenantId && !l.IsDeleted, ct);
        if (lic is null) return Result<bool>.Ok(false);
        var valid = lic.DeviceFingerprintHash == fpHash || lic.DeviceFingerprintHash is null;
        return Result<bool>.Ok(valid);
    }
}
