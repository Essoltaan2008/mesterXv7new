'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useAuth, useUI } from '@/store'
import { authAPI } from '@/lib/api'
import toast from 'react-hot-toast'

// ── Navigation ───────────────────────────────────────────────────────────────
const NAV = [
  { href: '/',          icon: '📊', label: 'الرئيسية'     },
  { href: '/pos',       icon: '🛒', label: 'نقطة البيع'   },
  { href: '/inventory', icon: '📦', label: 'المخزون'      },
  { href: '/customers', icon: '👥', label: 'العملاء'      },
  { href: '/reports',   icon: '📈', label: 'التقارير'     },
  { href: '/suppliers', icon: '🏭', label: 'الموردون'     },
  { href: '/expenses',  icon: '💸', label: 'المصروفات'    },
]

// Only shown when user role ≤ 4 (Manager and above)
const ADMIN_NAV = [
  { href: '/admin/users',    icon: '👤', label: 'المستخدمون' },
  { href: '/admin/branches', icon: '🏢', label: 'الفروع'     },
  { href: '/settings',       icon: '⚙️', label: 'الإعدادات'  },
]

const PLAN_LABELS: Record<number, string> = {
  0: 'تجريبية', 1: 'أساسية', 2: 'محترفة', 3: 'دائمة', 4: 'مؤسسية'
}
const PLAN_COLORS: Record<number, string> = {
  0: 'text-yellow-400', 1: 'text-slate-400', 2: 'text-teal-400', 3: 'text-amber-400', 4: 'text-purple-400'
}
const ROLE_LABELS: Record<number, string> = {
  0: 'مالك المنصة', 1: 'مدير عام', 2: 'صاحب شركة',
  3: 'مدير نظام', 4: 'مدير فرع', 5: 'كاشير', 6: 'مشاهد'
}

export default function Sidebar() {
  const pathname = usePathname()
  const router   = useRouter()
  const { user, logout }    = useAuth()
  const { sidebar, toggle } = useUI()

  // A link is "active" when the pathname matches exactly (for '/') or starts with the href
  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname.startsWith(href)

  const handleLogout = async () => {
    const refresh = typeof window !== 'undefined' ? localStorage.getItem('mx:refresh') : null
    if (refresh) {
      try { await authAPI.logout(refresh) } catch { /* ignore — we logout locally anyway */ }
    }
    logout()
    toast.success('تم تسجيل الخروج')
    router.push('/login')
  }

  const isManager = (user?.role ?? 99) <= 4

  return (
    <aside
      className={`
        ${sidebar ? 'w-56' : 'w-16'}
        flex flex-col bg-slate-800 border-l border-slate-700/50
        transition-all duration-200 flex-shrink-0 h-full
      `}
    >
      {/* ── Logo ──────────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-slate-700/50 min-h-[64px]">
        <span className="text-2xl flex-shrink-0">⚡</span>
        {sidebar && (
          <div className="overflow-hidden">
            <p className="font-bold text-amber-400 text-sm leading-tight">MesterX</p>
            <p className="text-slate-500 text-xs leading-tight">Enterprise v7</p>
          </div>
        )}
      </div>

      {/* ── Main Navigation ───────────────────────────────────────────────── */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5">
        {NAV.map(n => (
          <Link
            key={n.href}
            href={n.href}
            className={`nav-link ${isActive(n.href) ? 'active' : ''}`}
            title={!sidebar ? n.label : undefined}
          >
            <span className="text-base flex-shrink-0">{n.icon}</span>
            {sidebar && <span className="truncate">{n.label}</span>}
          </Link>
        ))}

        {/* Admin section — only for Manager+ roles */}
        {isManager && (
          <>
            <div className="my-2 border-t border-slate-700/40" />
            {sidebar && (
              <p className="px-3 text-xs text-slate-600 uppercase tracking-widest font-semibold mb-1">
                الإدارة
              </p>
            )}
            {ADMIN_NAV.map(n => (
              <Link
                key={n.href}
                href={n.href}
                className={`nav-link ${isActive(n.href) ? 'active' : ''}`}
                title={!sidebar ? n.label : undefined}
              >
                <span className="text-base flex-shrink-0">{n.icon}</span>
                {sidebar && <span className="truncate">{n.label}</span>}
              </Link>
            ))}
          </>
        )}
      </nav>

      {/* ── User card ─────────────────────────────────────────────────────── */}
      <div className="border-t border-slate-700/50 p-3">
        {sidebar ? (
          <>
            <div className="flex items-center gap-2.5 mb-2.5">
              {/* Avatar */}
              <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm flex-shrink-0">
                {user?.firstName?.[0] ?? '?'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-slate-200 truncate">
                  {user ? `${user.firstName} ${user.lastName}` : '...'}
                </p>
                <p className="text-xs text-slate-500 truncate">
                  {ROLE_LABELS[user?.role ?? 5] ?? 'مستخدم'}
                </p>
              </div>
            </div>

            {/* Branch + Plan badges */}
            <div className="flex gap-1.5 mb-2.5 flex-wrap">
              {user?.branchName && (
                <span className="badge-slate text-xs truncate max-w-full">
                  🏢 {user.branchName}
                </span>
              )}
            </div>
          </>
        ) : (
          <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-sm mx-auto mb-2.5">
            {user?.firstName?.[0] ?? '?'}
          </div>
        )}

        {/* Toggle sidebar button */}
        <button
          onClick={toggle}
          className="w-full text-xs text-slate-500 hover:text-slate-300 transition-colors flex items-center gap-1.5 justify-center py-1.5 rounded-lg hover:bg-slate-700/40 mb-1"
          title="طيّ / فتح القائمة"
        >
          <span>{sidebar ? '◀' : '▶'}</span>
          {sidebar && <span>طيّ</span>}
        </button>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full text-xs text-slate-500 hover:text-red-400 transition-colors flex items-center gap-1.5 justify-center py-1.5 rounded-lg hover:bg-red-500/10"
        >
          <span>🚪</span>
          {sidebar && <span>تسجيل الخروج</span>}
        </button>
      </div>
    </aside>
  )
}
